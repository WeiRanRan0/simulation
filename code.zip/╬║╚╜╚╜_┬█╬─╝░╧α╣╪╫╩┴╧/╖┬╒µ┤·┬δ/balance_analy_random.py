# import json
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# from scipy import stats
# import numpy as np
# from Parameter import REQUEST_NUM, SERVICE_RECORD_NUM, large_request_num, medium_request_num, edge_request_num
# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)
# pd.set_option('display.max_colwidth', 500)
# pd.set_option('display.expand_frame_repr', False)
# folder_path = './resource/'
# # 读取 JSON 文件并解析数据
# with open(
#         folder_path + f'resource_utilizations_with_random_{large_request_num}_{medium_request_num}_{edge_request_num}.json',
#         'r') as file:
#     data = json.load(file)
#
#
# # 将数据转换为 DataFrame
# # dfs = []
# # for algo, node_data in data.items():
# #     for node_id, tasks_data in node_data.items():
# #         df = pd.DataFrame(tasks_data)
# #         df['algorithm'] = algo
# #         df['node_id'] = node_id
# #         dfs.append(df)
# # df = pd.concat(dfs)
# #
# # mean_values = df.groupby(['node_id', 'algorithm']).mean()
# # variance_values = df.groupby(['node_id', 'algorithm']).var()
# # std_values = df.groupby(['node_id', 'algorithm']).std()
# # min_values = df.groupby(['node_id', 'algorithm']).min()
# # max_values = df.groupby(['node_id', 'algorithm']).max()
# # count_values = df.groupby(['node_id', 'algorithm']).size()
# #
# # # 创建 Excel Writer 对象
# # writer = pd.ExcelWriter('statistics.xlsx')
# #
# # # 写入统计结果到 Excel 文件
# # mean_values.to_excel(writer, sheet_name='Mean Values')
# # variance_values.to_excel(writer, sheet_name='Variance Values')
# # std_values.to_excel(writer, sheet_name='Standard Deviation Values')
# # min_values.to_excel(writer, sheet_name='Min Values')
# # max_values.to_excel(writer, sheet_name='Max Values')
# # count_values.to_excel(writer, sheet_name='Count Values')
# #
# # # 保存 Excel 文件
# # writer.close()
# #
# # print("Statistics saved to 'statistics.xlsx'.")
# #
# #
# # # 绘制 CPU 利用率的箱线图
# # grouped = df.groupby(['algorithm', 'node_id'])
# #
# # mean_values = grouped.mean()
# # variance_values = grouped.var()
# # std_values = grouped.std()
# # min_values = grouped.min()
# # max_values = grouped.max()
# # count_values = grouped.size()
# #
# # # 创建 Excel Writer 对象
# # writer = pd.ExcelWriter('statistics_by_algorithm_and_node.xlsx', engine='openpyxl')
# #
# # # 将统计结果写入 Excel 文件
# # mean_values.to_excel(writer, sheet_name='Mean Values')
# # variance_values.to_excel(writer, sheet_name='Variance Values')
# # std_values.to_excel(writer, sheet_name='Standard Deviation Values')
# # min_values.to_excel(writer, sheet_name='Min Values')
# # max_values.to_excel(writer, sheet_name='Max Values')
# # count_values.to_excel(writer, sheet_name='Count Values')
# #
# # # 保存 Excel 文件
# # writer.close()
# #
# # print("Statistics saved to 'statistics_by_algorithm_and_node.xlsx'.")
# # 获取节点和算法的列表
# node_summary = {}
#
# node_ids_set = set()  # 创建一个集合来存储不同的节点ID
# # 遍历节点和算法
# for algorithms, node_tsk in data.items():
#     if algorithms not in node_summary:
#         node_summary[algorithms] = {}
#
#     for node_id, tasks_data in node_tsk.items():
#         all_num = len(tasks_data)
#         print('all_num', all_num)
#         # 计算每个算法的 cpu_count 和 mem_count
#         cpu_count = sum(1 for entry in tasks_data if entry['cpu_utilization'] < 0.1)
#         mem_count = sum(1 for entry in tasks_data if entry['mem_utilization'] < 0.1)
#         disk_count = sum(1 for entry in tasks_data if entry['disk_utilization'] < 0.1)
#         cpu_over_rate = cpu_count / all_num
#         mem_over_rate = mem_count / all_num
#         disk_over_rate = disk_count / all_num
#         if node_id not in node_summary[algorithms]:
#             node_summary[algorithms][node_id] = {'cpu_count': cpu_count, 'mem_count': mem_count,
#                                                  'disk_count': disk_count,
#                                                  'cpu_over_rate': cpu_over_rate,
#                                                  'mem_over_rate': mem_over_rate,
#                                                  'disk_over_rate': disk_over_rate}
#
# # 打印每个节点的统计结果
# for algos, node_ids in node_summary.items():
#     print(f'algo: {algos}')
#
#     for node_id, counts in node_ids.items():
#         print(f'Node {node_id}:')
#         print(f'CPU Count: {counts["cpu_count"]}')
#         print(f'Memory Count: {counts["mem_count"]}')
#         print(f'disk Count: {counts["disk_count"]}')
#         print(f'cpu_over_rate :{counts["cpu_over_rate"]}')
#         print(f'mem_over_rate :{counts["mem_over_rate"]}')
#         print(f'disk_over_rate :{counts["disk_over_rate"]}')
#         print()  # 空行用于分隔每个节点的输出
#
# algorithm_zero_counts = {}
# for algorithms, node_ids in node_summary.items():
#     if algorithms not in algorithm_zero_counts:
#         algorithm_zero_counts[algorithms] = {}
#     for node_id, counts in node_ids.items():
#         if counts['cpu_count'] == 0 and counts['mem_count'] == 0 and counts['disk_count'] == 0:
#
#             if node_id not in algorithm_zero_counts[algorithms]:
#                 algorithm_zero_counts[algorithms][node_id] = 1
#             else:
#                 algorithm_zero_counts[algorithms][node_id] = 0
#
# # 打印每个算法中 cpu_count 和 mem_count 等于 0 的节点个数
# for algo, node_ids in algorithm_zero_counts.items():
#     print(f'Algorithm: {algo}')
#     temp = 0
#     for node_id, num in node_ids.items():
#         temp += num
#     print('      ', f'CPU Count and Memory Count Zero Nodes: {temp}')
# algorithm_zero_counts = {}
#
# # 计算每个算法中 CPU、内存和磁盘计数都为零的节点数量占该算法总节点数量的比例
# for algorithms, node_ids in node_summary.items():
#     total_nodes = len(node_ids)
#     zero_counts = sum(1 for counts in node_ids.values() if
#                       counts['cpu_count'] == 0 and counts['mem_count'] == 0 and counts['disk_count'] == 0)
#
#     if total_nodes != 0:
#         zero_ratio = zero_counts / total_nodes
#     else:
#         zero_ratio = 0
#
#     algorithm_zero_counts[algorithms] = zero_ratio
#
# # 打印每个算法中 CPU、内存和磁盘计数都为零的节点数量占该算法总节点数量的比例
# for algo, zero_ratio in algorithm_zero_counts.items():
#     print(f'Algorithm: {algo}, Zero Ratio: {zero_ratio}')
#
# for algorithms, node_ids in node_summary.items():
#     total_nodes = len(node_ids)
#     zero_counts = sum(1 for counts in node_ids.values() if
#                       counts['cpu_count'] == 0 and counts['mem_count'] == 0 and counts['disk_count'] == 0)
#
#     if total_nodes != 0:
#         zero_ratio = zero_counts / total_nodes
#     else:
#         zero_ratio = 0
#
#     algorithm_zero_counts[algorithms] = zero_ratio
#
# # 提取算法名称和对应的 zero ratio
# algorithms = list(algorithm_zero_counts.keys())
# zero_ratios = list(algorithm_zero_counts.values())
#
# # 创建一个柱状图
# plt.figure(figsize=(10, 6))
# plt.bar(algorithms, zero_ratios, color='skyblue')
#
# # 添加标题和标签
# plt.title('Zero Ratio of Nodes for Each Algorithm', fontsize=14)
# plt.xlabel('Algorithm', fontsize=12)
# plt.ylabel('Zero Ratio', fontsize=12)
#
# # 显示图表
# plt.xticks(rotation=45)
# plt.tight_layout()
# plt.show()
# total_overload_counts = {}
# for algorithms, node_ids in node_summary.items():
#     if algorithms not in total_overload_counts:
#         total_overload_counts[algorithms] = {'cpu': 0, 'mem': 0, 'disk': 0}
#     for node_id, counts in node_ids.items():
#         total_overload_counts[algorithms]['cpu'] += counts['cpu_count']
#         total_overload_counts[algorithms]['mem'] += counts['mem_count']
#         total_overload_counts[algorithms]['disk'] += counts['disk_count']
#
# # 打印每个算法的总超载量
# for algo, counts in total_overload_counts.items():
#     print(f'Algorithm: {algo}')
#     print(f'Total CPU Overload Count: {counts["cpu"]}')
#     print(f'Total Memory Overload Count: {counts["mem"]}')
#     print(f'Total Disk Overload Count: {counts["disk"]}')
#     print()
# #
# num_algorithms = len(node_summary)
# fig, axes = plt.subplots(num_algorithms, 1, figsize=(12, 6 * num_algorithms))
#
# if num_algorithms == 1:
#     axes = [axes]
#
# for ax, (algos, node_ids) in zip(axes, node_summary.items()):
#     node_ids_sorted = sorted(node_ids.keys())
#     cpu_counts = [node_ids[node_id]['cpu_count'] for node_id in node_ids_sorted]
#     mem_counts = [node_ids[node_id]['mem_count'] for node_id in node_ids_sorted]
#     disk_counts = [node_ids[node_id]['disk_count'] for node_id in node_ids_sorted]
#
#     cpu_over_rates = [node_ids[node_id]['cpu_over_rate'] for node_id in node_ids_sorted]
#     mem_over_rates = [node_ids[node_id]['mem_over_rate'] for node_id in node_ids_sorted]
#     disk_over_rates = [node_ids[node_id]['disk_over_rate'] for node_id in node_ids_sorted]
#     x = np.arange(len(node_ids_sorted))
#
#     bar_width = 0.35
#     bar1 = ax.bar(x - bar_width / 2, cpu_over_rates, bar_width, label='CPU Count')
#     bar2 = ax.bar(x + bar_width / 2, mem_over_rates, bar_width, label='Memory Count')
#     bar3 = ax.bar(x + 3 * bar_width / 2, disk_over_rates, bar_width, label='Disk Count')
#     ax.set_xlabel('Node ID')
#     ax.set_ylabel('Count')
#     ax.set_title(f'Algorithm: {algos}')
#     ax.set_xticks(x)
#     ax.set_xticklabels(node_ids_sorted, fontsize=6.5)
#     ax.legend()
#
#     # 添加注释
#     for rect, rate in zip(bar1, cpu_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#
#     for rect, rate in zip(bar2, mem_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#     for rect, rate in zip(bar3, disk_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#
# plt.tight_layout()
# plt.show()
import json
import sys

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from Parameter import large_request_num, medium_request_num, edge_request_num

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
folder_path = './resource/'
file_to_save = './balance/'
default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values
# 读取 JSON 文件并解析数据
with open(
        folder_path + f'resource_utilizations_dns_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.json',
        'r') as file:
    data = json.load(file)

node_summary = {}
node_ids_set = set()  # 创建一个集合来存储不同的节点ID

# 遍历节点和算法
for algorithms, node_tsk in data.items():
    if algorithms not in node_summary:
        node_summary[algorithms] = {}

    for node_id, tasks_data in node_tsk.items():
        all_num = len(tasks_data)
        cpu_count = sum(1 for entry in tasks_data if entry['cpu_utilization'] < 0.1)
        mem_count = sum(1 for entry in tasks_data if entry['mem_utilization'] < 0.1)
        disk_count = sum(1 for entry in tasks_data if entry['disk_utilization'] < 0.1)
        cpu_over_rate = cpu_count / all_num
        mem_over_rate = mem_count / all_num
        disk_over_rate = disk_count / all_num
        if node_id not in node_summary[algorithms]:
            node_summary[algorithms][node_id] = {'cpu_count': cpu_count, 'mem_count': mem_count,
                                                 'disk_count': disk_count,
                                                 'cpu_over_rate': cpu_over_rate,
                                                 'mem_over_rate': mem_over_rate,
                                                 'disk_over_rate': disk_over_rate}
# for algos, node_ids in node_summary.items():
#     print(f'algo: {algos}')
#
#     for node_id, counts in node_ids.items():
#         print(f'Node {node_id}:')
#         print(f'CPU Count: {counts["cpu_count"]}')
#         print(f'Memory Count: {counts["mem_count"]}')
#         print(f'disk Count: {counts["disk_count"]}')
#         print(f'cpu_over_rate :{counts["cpu_over_rate"]}')
#         print(f'mem_over_rate :{counts["mem_over_rate"]}')
#         print(f'disk_over_rate :{counts["disk_over_rate"]}')
#         print()  # 空行用于分隔每个节点的输出

algorithm_zero_counts = {}
for algorithms, node_ids in node_summary.items():
    if algorithms not in algorithm_zero_counts:
        algorithm_zero_counts[algorithms] = {}
    for node_id, counts in node_ids.items():
        if counts['cpu_count'] == 0 and counts['mem_count'] == 0 and counts['disk_count'] == 0:
            algorithm_zero_counts[algorithms][node_id] = 1
        else:
            algorithm_zero_counts[algorithms][node_id] = 0
# for algo, node_ids in algorithm_zero_counts.items():
#     print(f'Algorithm: {algo}')
#     temp = 0
#     for node_id, num in node_ids.items():
#         temp += num
#     print('      ', f'CPU Count and Memory Count Zero Nodes: {temp}')
print('*************DNS Balance Rate********************************************************************************')

algorithm_zero_count = {}
for algorithms, node_ids in node_summary.items():
    total_nodes = len(node_ids)
    zero_counts = sum(1 for counts in node_ids.values() if
                      counts['cpu_count'] == 0 and counts['mem_count'] == 0 and counts['disk_count'] == 0)

    if total_nodes != 0:
        zero_ratio = zero_counts / total_nodes
    else:
        zero_ratio = 0

    algorithm_zero_count[algorithms] = zero_ratio
for algo, zero_ratio in algorithm_zero_count.items():
    print(f'Algorithm: {algo}, Zero Ratio: {zero_ratio}')

# algorithms = list(algorithm_zero_count.keys())
# zero_ratios = list(algorithm_zero_count.values())
#
# # 创建一个柱状图
# plt.figure(figsize=(10, 6))
# plt.bar(algorithms, zero_ratios, color='skyblue')
#
# # 添加标题和标签
# plt.title('Zero Ratio of Nodes for Each Algorithm', fontsize=14)
# plt.xlabel('Algorithm', fontsize=12)
# plt.ylabel('Zero Ratio', fontsize=12)
#
# # 显示图表
# plt.xticks(rotation=45)
# plt.tight_layout()
# plt.show()
total_overload_counts = {}
for algorithms, node_ids in node_summary.items():
    if algorithms not in total_overload_counts:
        total_overload_counts[algorithms] = {'cpu': 0, 'mem': 0, 'disk': 0}
    for node_id, counts in node_ids.items():
        total_overload_counts[algorithms]['cpu'] += counts['cpu_count']
        total_overload_counts[algorithms]['mem'] += counts['mem_count']
        total_overload_counts[algorithms]['disk'] += counts['disk_count']

# 打印每个算法的总超载量
for algo, counts in total_overload_counts.items():
    print(f'Algorithm: {algo}')
    print(f'Total CPU Overload Count: {counts["cpu"]}')
    print(f'Total Memory Overload Count: {counts["mem"]}')
    print(f'Total Disk Overload Count: {counts["disk"]}')
    print()
#
# num_algorithms = len(node_summary)
# fig, axes = plt.subplots(num_algorithms, 1, figsize=(12, 6 * num_algorithms))
#
# if num_algorithms == 1:
#     axes = [axes]
#
# for ax, (algos, node_ids) in zip(axes, node_summary.items()):
#     node_ids_sorted = sorted(node_ids.keys())
#     cpu_counts = [node_ids[node_id]['cpu_count'] for node_id in node_ids_sorted]
#     mem_counts = [node_ids[node_id]['mem_count'] for node_id in node_ids_sorted]
#     disk_counts = [node_ids[node_id]['disk_count'] for node_id in node_ids_sorted]
#
#     cpu_over_rates = [node_ids[node_id]['cpu_over_rate'] for node_id in node_ids_sorted]
#     mem_over_rates = [node_ids[node_id]['mem_over_rate'] for node_id in node_ids_sorted]
#     disk_over_rates = [node_ids[node_id]['disk_over_rate'] for node_id in node_ids_sorted]
#     x = np.arange(len(node_ids_sorted))
#
#     bar_width = 0.35
#     bar1 = ax.bar(x - bar_width / 2, cpu_over_rates, bar_width, label='CPU Count')
#     bar2 = ax.bar(x + bar_width / 2, mem_over_rates, bar_width, label='Memory Count')
#     bar3 = ax.bar(x + 3 * bar_width / 2, disk_over_rates, bar_width, label='Disk Count')
#     ax.set_xlabel('Node ID')
#     ax.set_ylabel('Count')
#     ax.set_title(f'Algorithm: {algos}')
#     ax.set_xticks(x)
#     ax.set_xticklabels(node_ids_sorted, fontsize=6.5)
#     ax.legend()
#
#     # 添加注释
#     for rect, rate in zip(bar1, cpu_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#
#     for rect, rate in zip(bar2, mem_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#     for rect, rate in zip(bar3, disk_over_rates):
#         height = rect.get_height()
#         ax.annotate(f'{rate:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom')
#
# plt.tight_layout()
# plt.show()





# 将 node_summary 转换为 DataFrame
node_summary_list = []
for algo, nodes in node_summary.items():
    for node_id, metrics in nodes.items():
        row = {'algorithm': algo, 'node_id': node_id}
        row.update(metrics)
        node_summary_list.append(row)
node_summary_df = pd.DataFrame(node_summary_list)

# 将 algorithm_zero_counts 转换为 DataFrame
algorithm_zero_counts_list = []
for algo, nodes in algorithm_zero_counts.items():
    for node_id, count in nodes.items():
        algorithm_zero_counts_list.append({'algorithm': algo, 'node_id': node_id, 'zero_count': count})
algorithm_zero_counts_df = pd.DataFrame(algorithm_zero_counts_list)

# 将 algorithm_zero_count 转换为 DataFrame
algorithm_zero_count_list = [{'algorithm': algo, 'zero_ratio': ratio} for algo, ratio in algorithm_zero_count.items()]
algorithm_zero_count_df = pd.DataFrame(algorithm_zero_count_list)

# 保存为 CSV 文件
node_summary_df.to_csv(
    file_to_save + f'dns_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}_node_summary.csv',
    index=False)
algorithm_zero_counts_df.to_csv(file_to_save + f'balance_dns_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}_node_details.csv', index=False)
algorithm_zero_count_df.to_csv(file_to_save + f'balance_dns_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv', index=False)

# 保存为 Excel 文件
with pd.ExcelWriter(file_to_save + f'balance_dns_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}_statistics.xlsx') as writer:
    node_summary_df.to_excel(writer, sheet_name='Node Summary', index=False)
    algorithm_zero_counts_df.to_excel(writer, sheet_name='Algorithm Zero Counts', index=False)
    algorithm_zero_count_df.to_excel(writer, sheet_name='Algorithm Zero Count', index=False)

print("Data saved to CSV and Excel files.")
print(f'balance_analy_dns.py@@@@@@@@@@@@@@{weight_type}_{iter_num} end--------------------------------------------------------------------------------')
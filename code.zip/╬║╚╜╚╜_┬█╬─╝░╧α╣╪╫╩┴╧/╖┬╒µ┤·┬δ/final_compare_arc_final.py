import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def extract_balance_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algorithm'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['zero_ratio'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_success_rate_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['success_rate'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_dy_success_rate_values(file_list):
    success_rates = []
    improvement_rates = []
    perfect_satisfaction_rates = []

    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            success_rates.append(topsis_row['avg_success_rate'].values[0])
            improvement_rates.append(topsis_row['avg_improvement_rate'].values[0])
            perfect_satisfaction_rates.append(topsis_row['avg_perfect_satisfaction_rate'].values[0])

    return success_rates, improvement_rates, perfect_satisfaction_rates


# 数字列表
rst_num = [10, 30, 60, 90, 120, 150]
algo_cfn = ['en', 'my_bwm']
algo_com = ['en', 'my_bwm']
# 创建两组文件名列表，使用 f-string 匹配数字部分


balance_list_cfn = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_cfn = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com = [f"./final_result/avg_balance_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_com = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                     rst_num]

balance_list_cfn_my = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy_my = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_cfn_my = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
balance_list_com_my = [f"./final_result/avg_balance_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy_my = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_com_my = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
balance_list_dns = [f"./final_result/avg_balance_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_dns_dy = [f"./final_result/success_rate_dy_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_dns = [f"./final_result/success_rate_sta_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                      rst_num]
balance_list_dns_my = [f"./final_result/avg_balance_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_dns_dy_my = [f"./final_result/success_rate_dy_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_dns_my = [f"./final_result/success_rate_sta_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
#                         rst_num]
# 提取两组文件的topsis行的zero_ratio值
balance_cfn = extract_balance_values(balance_list_cfn)
balance_com = extract_balance_values(balance_list_com)
balance_cfn_my = extract_balance_values(balance_list_cfn_my)
balance_com_my = extract_balance_values(balance_list_com_my)
balance_dns = extract_balance_values(balance_list_dns)
balance_dns_my = extract_balance_values(balance_list_dns_my)
success_dns_dy = extract_dy_success_rate_values(success_list_dns_dy)
success_dns_dy_my = extract_dy_success_rate_values(success_list_dns_dy_my)
# success_dns = extract_success_rate_values(success_list_dns)
# success_dns_my = extract_success_rate_values(success_list_dns_my)
success_cfn_dy = extract_dy_success_rate_values(success_list_cfn_dy)
success_com_dy = extract_dy_success_rate_values(success_list_com_dy)
success_cfn_dy_my = extract_dy_success_rate_values(success_list_cfn_dy_my)
success_com_dy_my = extract_dy_success_rate_values(success_list_com_dy_my)

# success_cfn = extract_success_rate_values(success_list_cfn)
# success_com = extract_success_rate_values(success_list_com)
# success_cfn_my = extract_success_rate_values(success_list_cfn_my)
# success_com_my = extract_success_rate_values(success_list_com_my)

# Extract the success rate, improvement rate, and perfect satisfaction rate
success_rate_cfn_dy, improvement_rate_cfn_dy, perfect_satisfaction_rate_cfn_dy = success_cfn_dy
success_rate_com_dy, improvement_rate_com_dy, perfect_satisfaction_rate_com_dy = success_com_dy
success_rate_dns_dy, improvement_rate_dns_dy, perfect_satisfaction_rate_dns_dy = success_dns_dy
success_rate_cfn_dy_my, improvement_rate_cfn_dy_my, perfect_satisfaction_rate_cfn_dy_my = success_cfn_dy_my
success_rate_com_dy_my, improvement_rate_com_dy_my, perfect_satisfaction_rate_com_dy_my = success_com_dy_my
success_rate_dns_dy_my, improvement_rate_dns_dy_my, perfect_satisfaction_rate_dns_dy_my = success_dns_dy_my
# Define the request numbers for the x-axis
x_labels = np.linspace(0, len(rst_num) - 1, len(rst_num))
# Plot for Balance CFN


# Create a new figure
plt.figure(figsize=(12, 8))
width = 0.1  # Width of bars
# Plot for Balance CFN
plt.plot(x_labels, balance_com, marker='o', markersize=3.5, color='steelblue', linestyle='-', linewidth=1.5,
         label='This Paper (EWM)')
plt.plot(x_labels, balance_com_my, marker='s', markersize=3.5, color='steelblue', linestyle='-', linewidth=1.5,
         label='This Paper (BWM)')
plt.plot(x_labels, balance_cfn, marker='o', markersize=3.5, color='darkorange', linestyle='-.', linewidth=1.5,
         label='CFN (EWM)')
plt.plot(x_labels, balance_cfn_my, marker='s', markersize=3.5, color='darkorange', linestyle='-.', linewidth=1.5,
         label='CFN (BWM)')
plt.plot(x_labels, balance_dns, marker='o', markersize=3.5, color='seagreen', linestyle=':', linewidth=1.5,
         label='DNS (EWM)')
plt.plot(x_labels, balance_dns_my, marker='s', markersize=3.5, color='seagreen', linestyle=':', linewidth=1.5,
         label='DNS (BWM)')
#
#
# # Adding bars for each dataset
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 2.5 * width, balance_com[i], width, color='steelblue', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] - 1.5 * width, balance_com_my[i], width, color='steelblue', alpha=1, hatch='////',
            edgecolor='darkgray')
    plt.bar(x_labels[i] - 0.5 * width, balance_cfn[i], width, color='darkorange', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, balance_cfn_my[i], width, color='darkorange', alpha=1, hatch='////',
            edgecolor='darkgray')

    plt.bar(x_labels[i] + 1.5 * width, balance_dns[i], width, color='seagreen', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] + 2.5 * width, balance_dns_my[i], width, color='seagreen', alpha=1, hatch='////',
            edgecolor='darkgray')
# Annotate bars
for i, txt in enumerate(balance_cfn):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(balance_cfn_my):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(balance_com):
    plt.text(x_labels[i] - 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(balance_com_my):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(balance_dns):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(balance_dns_my):
    plt.text(x_labels[i] + 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
# Adding titles and labels
plt.title('Load Balance Comparison: This Paper vs. CFN vs. DNS')
plt.xlabel('Number of Requests (unit time)')
plt.ylabel('Ratio')
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='-.', color='gray')
plt.ylim(0.3, 1.1)
plt.legend()
# plt.grid(True)

# Show plot
plt.show()

# Create figures for each indicator
# 1. Success Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, success_rate_com_dy, marker='o', markersize=3.5, color='steelblue', linestyle='-',linewidth=1.5,label='This Paper (EWM)')
plt.plot(x_labels, success_rate_com_dy_my, marker='s',markersize=3.5, color='steelblue', linestyle='-', linewidth=1.5,label='This Paper (BWM)')
plt.plot(x_labels, success_rate_cfn_dy, marker='o', markersize=3.5,color='darkorange', linestyle='-.', linewidth=1.5,label='CFN (EWM)')
plt.plot(x_labels, success_rate_cfn_dy_my, marker='s',markersize=3.5, color='darkorange', linestyle='-.',linewidth=1.5,label='CFN (BWM)')
plt.plot(x_labels, success_rate_dns_dy, marker='o',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5, label='DNS (EWM)')
plt.plot(x_labels, success_rate_dns_dy_my, marker='s',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5, label='DNS (BWM)')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 0.5 * width, success_rate_cfn_dy[i], width, color='darkorange', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, success_rate_cfn_dy_my[i], width, color='darkorange', alpha=1, hatch='////',
            edgecolor='darkgray')
    plt.bar(x_labels[i] - 2.5 * width, success_rate_com_dy[i], width, color='steelblue', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] - 1.5 * width, success_rate_com_dy_my[i], width, color='steelblue', alpha=1, hatch='////',
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, success_rate_dns_dy[i], width, color='seagreen', alpha=1, edgecolor='darkgray')
    plt.bar(x_labels[i] + 2.5 * width, success_rate_dns_dy_my[i], width, color='seagreen', alpha=1, hatch='////',
            edgecolor='darkgray')
for i, txt in enumerate(success_rate_cfn_dy):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(success_rate_cfn_dy_my):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(success_rate_com_dy):
    plt.text(x_labels[i] - 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(success_rate_com_dy_my):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(success_rate_dns_dy):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(success_rate_dns_dy_my):
    plt.text(x_labels[i] + 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
plt.title('Success Rate Comparison: This Paper vs. CFN vs. DNS')
plt.xlabel('Number of Requests (unit time)')
plt.ylabel('Success Rate')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.ylim(0.3, 1.1)
plt.grid(axis='x', linestyle='-.', color='gray')
plt.show()

# 2. Improvement Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, improvement_rate_com_dy, marker='o',markersize=3.5, color='steelblue', linestyle='-',linewidth=1.5, label='This Paper (EWM)')
plt.plot(x_labels, improvement_rate_com_dy_my, marker='s',markersize=3.5, color='steelblue', linestyle='-',linewidth=1.5,
         label='This Paper (BWM)')
plt.plot(x_labels, improvement_rate_cfn_dy, marker='o',markersize=3.5, color='darkorange', linestyle='-.',linewidth=1.5,
         label='CFN (EWM)')
plt.plot(x_labels, improvement_rate_cfn_dy_my, marker='s',markersize=3.5, color='darkorange', linestyle='-.',linewidth=1.5,
         label='CFN (BWM)')
plt.plot(x_labels, improvement_rate_dns_dy, marker='o',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5, label='DNS (EWM)')
plt.plot(x_labels, improvement_rate_dns_dy_my, marker='s',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5,
         label='DNS (BWM)')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 0.5 * width, improvement_rate_cfn_dy[i], width, color='darkorange', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, improvement_rate_cfn_dy_my[i], width, color='darkorange', alpha=1, hatch='////',
            edgecolor='darkgray')
    plt.bar(x_labels[i] - 2.5 * width, improvement_rate_com_dy[i], width, color='steelblue', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] - 1.5 * width, improvement_rate_com_dy_my[i], width, color='steelblue', alpha=1, hatch='////',
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, improvement_rate_dns_dy[i], width, color='seagreen', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 2.5 * width, improvement_rate_dns_dy_my[i], width, color='seagreen', alpha=1, hatch='////',
            edgecolor='darkgray')
for i, txt in enumerate(improvement_rate_cfn_dy):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_cfn_dy_my):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_com_dy):
    plt.text(x_labels[i] - 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_com_dy_my):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_dns_dy):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_dns_dy_my):
    plt.text(x_labels[i] + 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
plt.title('Delay Reduction Comparison: This Paper vs. CFN vs. DNS')
plt.xlabel('Number of Requests (unit time)')
plt.ylabel('Delay Reduction')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='-.', color='gray')
plt.show()

# 3. Perfect Satisfaction Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, perfect_satisfaction_rate_com_dy, marker='o', markersize=3.5,color='steelblue', linestyle='-',linewidth=1.5,
         label='Perfect Satisfaction Rate COM')
plt.plot(x_labels, perfect_satisfaction_rate_com_dy_my, marker='s', markersize=3.5,color='steelblue', linestyle='-',linewidth=1.5,
         label='Perfect Satisfaction Rate COM My')
plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy, marker='o',markersize=3.5, color='darkorange', linestyle='-.',linewidth=1.5,
         label='Perfect Satisfaction Rate CFN')
plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy_my, marker='s',markersize=3.5, color='darkorange', linestyle='-.',linewidth=1.5,
         label='Perfect Satisfaction Rate CFN My')
plt.plot(x_labels, perfect_satisfaction_rate_dns_dy, marker='o',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5,
         label='Perfect Satisfaction Rate dns')
plt.plot(x_labels, perfect_satisfaction_rate_dns_dy_my, marker='s',markersize=3.5, color='seagreen', linestyle=':',linewidth=1.5,
         label='Perfect Satisfaction Rate dns My')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 0.5 * width, perfect_satisfaction_rate_cfn_dy[i], width, color='darkorange', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, perfect_satisfaction_rate_cfn_dy_my[i], width, color='darkorange', alpha=1,
            hatch='////', edgecolor='darkgray')
    plt.bar(x_labels[i] - 2.5 * width, perfect_satisfaction_rate_com_dy[i], width, color='steelblue', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] - 1.5 * width, perfect_satisfaction_rate_com_dy_my[i], width, color='steelblue', alpha=1,
            hatch='////', edgecolor='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, perfect_satisfaction_rate_dns_dy[i], width, color='seagreen', alpha=1,
            edgecolor='darkgray')
    plt.bar(x_labels[i] + 2.5 * width, perfect_satisfaction_rate_dns_dy_my[i], width, color='seagreen', alpha=1,
            hatch='////', edgecolor='darkgray')
for i, txt in enumerate(perfect_satisfaction_rate_cfn_dy):
    plt.text(x_labels[i] - .5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_cfn_dy_my):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_com_dy):
    plt.text(x_labels[i] - 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_com_dy_my):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_dns_dy):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_dns_dy_my):
    plt.text(x_labels[i] + 2.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
plt.title('Perfect Satisfaction Rate Comparison: CFN vs. COM vs. dns')
plt.xlabel('Number of Requests (unit time)')
plt.ylabel('Perfect Satisfaction Rate')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='-.', color='gray')
plt.show()

# balance_dns = extract_balance_values(balance_list_dns)
# success_dns_dy = extract_dy_success_rate_values(success_list_dns_dy)
# success_dns = extract_success_rate_values(success_list_dns)


# print('dy',success_cfn_dy[2],len(success_cfn_dy[2]))
# fig, axes = plt.subplots(1, 4, figsize=(18, 5))
#
# # 平衡值可视化
# axes[0].plot(rst_num, balance_cfn, color='blue', marker='o', label='CFN')
# for i, txt in enumerate(balance_cfn):
#     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[0].plot(rst_num, balance_com, color='yellow', marker='o', label='COM')
# for i, txt in enumerate(balance_com):
#     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[0].plot(rst_num, balance_dns, color='green', marker='o', label='dns')
# # for i, txt in enumerate(balance_dns):
# #     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[0].set_title('Balance Values')
# axes[0].set_xlabel('Number of Requests')
# axes[0].set_ylabel('Balance Value')
# axes[0].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[0].legend()
# axes[0].grid(True)
#
# # 动态成功率可视化
# axes[1].plot(rst_num, success_cfn_dy[0], color='blue', marker='o', label='CFN Dynamic')
# for i, txt in enumerate(success_cfn_dy[0]):
#     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[1].plot(rst_num, success_com_dy[0], color='yellow', marker='o', label='COM Dynamic')
# for i, txt in enumerate(success_com_dy[0]):
#     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[1].plot(rst_num, success_dns_dy[0], color='green', marker='o', label='dns Dynamic')
# # for i, txt in enumerate(success_dns_dy[0]):
# #     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[1].set_title('Success Rate (Dynamic)')
# axes[1].set_xlabel('Number of Requests')
# axes[1].set_ylabel('Success Rate')
# axes[1].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[1].legend()
# axes[1].grid(True)
#
# axes[2].plot(rst_num, success_cfn_dy[1], color='blue', marker='o', label='CFN IMP')
# for i, txt in enumerate(success_cfn_dy[1]):
#     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[2].plot(rst_num, success_com_dy[1], color='yellow', marker='o', label='COM IMP')
# for i, txt in enumerate(success_com_dy[1]):
#     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[2].plot(rst_num, success_dns_dy[1], color='green', marker='o', label='dns IMP')
# # for i, txt in enumerate(success_dns_dy[1]):
# #     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[2].set_title('IMP Rate (Dynamic)')
# axes[2].set_xlabel('Number of Requests')
# axes[2].set_ylabel('IMP Rate')
# axes[2].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[2].legend()
# axes[2].grid(True)
#
# axes[3].plot(rst_num, success_cfn_dy[2], color='blue', marker='o', label='CFN PERFECT')
# for i, txt in enumerate(success_cfn_dy[2]):
#     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[3].plot(rst_num, success_com_dy[2], color='yellow', marker='o', label='COM PERFECT')
# for i, txt in enumerate(success_com_dy[2]):
#     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[3].plot(rst_num, success_dns_dy[2], color='green', marker='o', label='dns PERFECT')
# # for i, txt in enumerate(success_dns_dy[2]):
# #     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[3].set_title('PERFECT Rate (Dynamic)')
# axes[3].set_xlabel('Number of Requests')
# axes[3].set_ylabel('PERFECT Rate')
# axes[3].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[3].legend()
# axes[3].grid(True)
# 静态成功率可视化
# axes[4].plot(rst_num, success_cfn, marker='o', label='CFN Static')
# for i, txt in enumerate(success_cfn):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].plot(rst_num, success_com, marker='o', label='COM Static')
# for i, txt in enumerate(success_com):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].plot(rst_num, success_dns, marker='o', label='dns Static')
# for i, txt in enumerate(success_dns):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].set_title('Success Rate (Static)')
# axes[4].set_xlabel('Number of Requests')
# axes[4].set_ylabel('Success Rate')
# axes[4].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[4].legend()
# axes[4].grid(True)

# plt.tight_layout()
# plt.show()

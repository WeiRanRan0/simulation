import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def extract_balance_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algorithm'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['zero_ratio'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_success_rate_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['success_rate'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_dy_success_rate_values(file_list):
    success_rates = []
    improvement_rates = []
    perfect_satisfaction_rates = []

    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            success_rates.append(topsis_row['avg_success_rate'].values[0])
            improvement_rates.append(topsis_row['avg_improvement_rate'].values[0])
            perfect_satisfaction_rates.append(topsis_row['avg_perfect_satisfaction_rate'].values[0])

    return success_rates, improvement_rates, perfect_satisfaction_rates


# 数字列表
rst_num = [10, 30, 60, 90, 120, 150, 180]
algo_cfn = ['en', 'my_bwm']
algo_com = ['en', 'my_bwm']
# 创建两组文件名列表，使用 f-string 匹配数字部分


balance_list_cfn = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_cfn = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com = [f"./final_result/avg_balance_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_com = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                     rst_num]

balance_list_cfn_my = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy_my = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_cfn_my = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
balance_list_com_my = [f"./final_result/avg_balance_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy_my = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_com_my = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
balance_list_dns = [f"./final_result/avg_balance_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_dns_dy = [f"./final_result/success_rate_dy_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_dns = [f"./final_result/success_rate_sta_results_with_dns_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                      rst_num]
balance_list_dns_my = [f"./final_result/avg_balance_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_dns_dy_my = [f"./final_result/success_rate_dy_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_dns_my = [f"./final_result/success_rate_sta_results_with_dns_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
#                         rst_num]
# 提取两组文件的topsis行的zero_ratio值
balance_cfn = extract_balance_values(balance_list_cfn)
balance_com = extract_balance_values(balance_list_com)
balance_cfn_my = extract_balance_values(balance_list_cfn_my)
balance_com_my = extract_balance_values(balance_list_com_my)
balance_dns = extract_balance_values(balance_list_dns)
balance_dns_my = extract_balance_values(balance_list_dns_my)
success_dns_dy = extract_dy_success_rate_values(success_list_dns_dy)
success_dns_dy_my = extract_dy_success_rate_values(success_list_dns_dy_my)
# success_dns = extract_success_rate_values(success_list_dns)
# success_dns_my = extract_success_rate_values(success_list_dns_my)
success_cfn_dy = extract_dy_success_rate_values(success_list_cfn_dy)
success_com_dy = extract_dy_success_rate_values(success_list_com_dy)
success_cfn_dy_my = extract_dy_success_rate_values(success_list_cfn_dy_my)
success_com_dy_my = extract_dy_success_rate_values(success_list_com_dy_my)

# success_cfn = extract_success_rate_values(success_list_cfn)
# success_com = extract_success_rate_values(success_list_com)
# success_cfn_my = extract_success_rate_values(success_list_cfn_my)
# success_com_my = extract_success_rate_values(success_list_com_my)

# Extract the success rate, improvement rate, and perfect satisfaction rate
success_rate_cfn_dy, improvement_rate_cfn_dy, perfect_satisfaction_rate_cfn_dy = success_cfn_dy
success_rate_com_dy, improvement_rate_com_dy, perfect_satisfaction_rate_com_dy = success_com_dy
success_rate_dns_dy, improvement_rate_dns_dy, perfect_satisfaction_rate_dns_dy = success_dns_dy
success_rate_cfn_dy_my, improvement_rate_cfn_dy_my, perfect_satisfaction_rate_cfn_dy_my = success_cfn_dy_my
success_rate_com_dy_my, improvement_rate_com_dy_my, perfect_satisfaction_rate_com_dy_my = success_com_dy_my
success_rate_dns_dy_my, improvement_rate_dns_dy_my, perfect_satisfaction_rate_dns_dy_my = success_dns_dy_my
# Define the request numbers for the x-axis
x_labels = np.linspace(0, len(rst_num) - 1, len(rst_num))
# Plot for Balance CFN


# 均衡率的图
plt.figure(figsize=(9, 10), dpi=600)  # 正方形图形
# 绘制第一个图
plt.plot(x_labels, balance_com_my, marker='^', markersize=12, color='steelblue', linestyle='-', linewidth=4.5,
         label='This Paper(BWM)')
plt.plot(x_labels, balance_cfn_my, marker='s', markersize=12, color='darkorange', linestyle='-', linewidth=4.5,
         label='CFN(BWM)')
plt.plot(x_labels, balance_dns_my, marker='o', markersize=12, color='seagreen', linestyle='-', linewidth=4.5,
         label='DNS')
plt.xlabel('Number of Requests (unit time)', fontsize=22)
plt.ylabel('Load Balancing Rate', fontsize=22)
plt.xticks(x_labels, rst_num, fontsize=20)
plt.yticks(fontsize=20)
# 动态设置 y 轴范围
min_y = min(min(balance_com_my), min(balance_cfn_my), min(balance_dns_my)) - 0.05
max_y = max(max(balance_com_my), max(balance_cfn_my), max(balance_dns_my)) + 0.05
plt.ylim(min_y, max_y)

plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
plt.legend(fontsize=19, loc='lower left')

plt.gca().spines['top'].set_linewidth(4)
plt.gca().spines['right'].set_linewidth(4)
plt.gca().spines['left'].set_linewidth(4)
plt.gca().spines['bottom'].set_linewidth(4)

plt.savefig('figure12a.pdf', dpi=600)
plt.show()
# 设置背景色
# plt.gca().set_facecolor('lightgray')  # 设置淡色背景

# 设置边框线条粗细


plt.figure(figsize=(9, 10), dpi=600)  # 正方形图形
# 绘制第3个图
plt.plot(x_labels, balance_com, marker='^', markersize=12, color='steelblue', linestyle='-', linewidth=4.5,
         label='This Paper(EWM)')
plt.plot(x_labels, balance_com_my, marker='^', markersize=12, color='steelblue', linestyle='-.', linewidth=4,
         label='This Paper(BWM)', alpha=0.5)
plt.plot(x_labels, balance_cfn, marker='s', markersize=12, color='darkorange', linestyle='-', linewidth=4.5,
         label='CFN(EWM)')
plt.plot(x_labels, balance_cfn_my, marker='s', markersize=12, color='darkorange', linestyle='-.', linewidth=4,
         label='CFN(BWM)', alpha=0.5)
# plt.plot(x_labels, balance_dns, marker='o', markersize=8, color='seagreen', linestyle='-.', linewidth=1,
#          label='DNS(BWM)')
plt.xlabel('Number of Requests (unit time)', fontsize=22)
plt.ylabel('Load Balancing Rate', fontsize=22)
plt.xticks(x_labels, rst_num, fontsize=20)
plt.yticks(fontsize=20)

# 动态设置 y 轴范围
min_y = min(min(balance_com), min(balance_cfn), min(balance_cfn_my), min(balance_com_my)) - 0.05
max_y = max(max(balance_com), max(balance_cfn), max(balance_cfn_my), max(balance_com_my)) + 0.05
plt.ylim(min_y, max_y)

plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
plt.legend(fontsize=19, loc='lower left')

# 设置背景色
# plt.gca().set_facecolor('lightgray')  # 设置淡色背景

# 设置边框线条粗细
plt.gca().spines['top'].set_linewidth(4)
plt.gca().spines['right'].set_linewidth(4)
plt.gca().spines['left'].set_linewidth(4)
plt.gca().spines['bottom'].set_linewidth(4)
plt.savefig('figure12b.pdf', dpi=600)
# 显示图形
plt.show()

# 2. Improvement Rate
plt.figure(figsize=(10.8, 12), dpi=600)  # 正方形图形# 正方形图形
# 绘制第一个图
plt.plot(x_labels, improvement_rate_com_dy_my, marker='^', markersize=12, color='steelblue', linestyle='-',
         linewidth=4.5,
         label='This Paper(BWM)')
plt.plot(x_labels, improvement_rate_cfn_dy_my, marker='s', markersize=12, color='darkorange', linestyle='-',
         linewidth=4.5,
         label='CFN(BWM)')
plt.plot(x_labels, improvement_rate_dns_dy_my, marker='o', markersize=12, color='seagreen', linestyle='-',
         linewidth=4.5,
         label='DNS')
plt.xlabel('Number of Requests (unit time)', fontsize=22)
plt.ylabel('Delay Reduction Rate', fontsize=22)
plt.xticks(x_labels, rst_num, fontsize=20)
plt.yticks(fontsize=20)
# 动态设置 y 轴范围
min_y = min(min(improvement_rate_com_dy_my), min(improvement_rate_cfn_dy_my), min(improvement_rate_dns_dy_my)) - 0.05
max_y = max(max(improvement_rate_com_dy_my), max(improvement_rate_cfn_dy_my), max(improvement_rate_dns_dy_my)) + 0.05
plt.ylim(min_y, max_y)

plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
plt.legend(fontsize=19, loc='lower left')

# 设置背景色
# plt.gca().set_facecolor('lightgray')  # 设置淡色背景

# 设置边框线条粗细
plt.gca().spines['top'].set_linewidth(4)
plt.gca().spines['right'].set_linewidth(4)
plt.gca().spines['left'].set_linewidth(4)
plt.gca().spines['bottom'].set_linewidth(4)
plt.savefig('figure11a.pdf', dpi=600)
# 显示图形
plt.show()

#
# plt.figure(figsize=(9, 12)) # 正方形图形
#
# # 绘制第2个图
# plt.plot(x_labels, improvement_rate_com_dy_my, marker='^', markersize=7, color='steelblue', linestyle='-', linewidth=1,
#          label='This Paper(BWM)')
# plt.plot(x_labels, improvement_rate_com_dy, marker='^', markersize=7, color='steelblue', linestyle='-.', linewidth=1,
#          label='This Paper(EWM)')
#
# plt.xlabel('Number of Requests (unit time)')
# plt.ylabel('Delay Reduction Rate')
# plt.xticks(x_labels, rst_num)
#
# # 动态设置 y 轴范围
# min_y = min(min(improvement_rate_com_dy_my), min(improvement_rate_com_dy)) - 0.05
# max_y = max(max(improvement_rate_com_dy_my), max(improvement_rate_com_dy)) + 0.05
# plt.ylim(min_y, max_y)
#
# plt.grid(axis='x', linestyle='-.', color='lightgray')
# plt.grid(axis='y', linestyle='-.', color='lightgray')
# plt.legend()
#
# # 设置背景色
# # plt.gca().set_facecolor('lightgray')  # 设置淡色背景
#
# # 设置边框线条粗细
# plt.gca().spines['top'].set_linewidth(1.5)
# plt.gca().spines['right'].set_linewidth(1.5)
# plt.gca().spines['left'].set_linewidth(1.5)
# plt.gca().spines['bottom'].set_linewidth(1.5)
#
# # 显示图形
# plt.show()
#
plt.figure(figsize=(10.8, 12), dpi=600)  # 正方形图形

# 绘制第3个图
plt.plot(x_labels, improvement_rate_com_dy, marker='^', markersize=12, color='steelblue', linestyle='-', linewidth=4.5,
         label='This Paper(EWM)')
plt.plot(x_labels, improvement_rate_com_dy_my, marker='^', markersize=12, color='steelblue', linestyle='-.',
         linewidth=4,
         label='This Paper(BWM)', alpha=0.5)
plt.plot(x_labels, improvement_rate_cfn_dy, marker='s', markersize=12, color='darkorange', linestyle='-', linewidth=4.5,
         label='CFN(EWM)')
plt.plot(x_labels, improvement_rate_cfn_dy_my, marker='s', markersize=12, color='darkorange', linestyle='-.',
         linewidth=4,
         label='CFN(BWM)', alpha=0.5)
# plt.plot(x_labels, balance_dns, marker='o', markersize=8, color='seagreen', linestyle='-.', linewidth=1,
#          label='DNS(BWM)')
plt.xlabel('Number of Requests (unit time)', fontsize=22)
plt.ylabel('Delay Reduction Rate', fontsize=22)
plt.xticks(x_labels, rst_num, fontsize=20)
plt.yticks(fontsize=20)
# 动态设置 y 轴范围
min_y = min(min(improvement_rate_com_dy), min(improvement_rate_com_dy_my), min(improvement_rate_cfn_dy),
            min(improvement_rate_cfn_dy_my)) - 0.05
max_y = max(max(improvement_rate_com_dy), max(improvement_rate_com_dy_my), max(improvement_rate_cfn_dy),
            max(improvement_rate_cfn_dy_my)) + 0.05
plt.ylim(min_y, max_y)

plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
plt.legend(fontsize=19, loc='lower left')

# 设置背景色
# plt.gca().set_facecolor('lightgray')  # 设置淡色背景
# 设置边框线条粗细
plt.gca().spines['top'].set_linewidth(4)
plt.gca().spines['right'].set_linewidth(4)
plt.gca().spines['left'].set_linewidth(4)
plt.gca().spines['bottom'].set_linewidth(4)
plt.savefig('figure11b.pdf', dpi=600)
plt.show()
# #
# # # 3. Perfect Satisfaction Rate
# plt.figure(figsize=(9, 10), dpi=600)  # 正方形图形
# # 绘制第一个图
# plt.plot(x_labels, perfect_satisfaction_rate_com_dy_my, marker='^', markersize=12, color='steelblue', linestyle='-',
#          linewidth=4.5,
#          label='This Paper(BWM)')
# plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy_my, marker='s', markersize=12, color='darkorange', linestyle='-',
#          linewidth=4.5,
#          label='CFN(BWM)')
# plt.plot(x_labels, perfect_satisfaction_rate_dns_dy_my, marker='o', markersize=12, color='seagreen', linestyle='-',
#          linewidth=4.5, label='DNS')
# plt.xlabel('Number of Requests (unit time)', fontsize=22)
# plt.ylabel('Scheduling Success Rate', fontsize=22)
# plt.xticks(x_labels, rst_num, fontsize=20)
# plt.yticks(fontsize=20)
# # 动态设置 y 轴范围
# min_y = min(min(perfect_satisfaction_rate_com_dy_my), min(perfect_satisfaction_rate_cfn_dy_my),
#             min(perfect_satisfaction_rate_dns_dy_my)) - 0.05
# max_y = max(max(perfect_satisfaction_rate_com_dy_my), max(perfect_satisfaction_rate_cfn_dy_my),
#             max(perfect_satisfaction_rate_dns_dy_my)) + 0.05
# plt.ylim(min_y, max_y)
#
# plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
# plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
# plt.legend(fontsize=19, loc='lower left')
#
# # 设置背景色
# # plt.gca().set_facecolor('lightgray')  # 设置淡色背景
#
# # 设置边框线条粗细
# plt.gca().spines['top'].set_linewidth(4)
# plt.gca().spines['right'].set_linewidth(4)
# plt.gca().spines['left'].set_linewidth(4)
# plt.gca().spines['bottom'].set_linewidth(4)
# plt.savefig('figure10a.pdf', dpi=600)
# # 显示图形
# plt.show()
#
# plt.figure(figsize=(9, 12)) # 正方形图形
#
# # 绘制第2个图
# plt.plot(x_labels, perfect_satisfaction_rate_com_dy_my, marker='^', markersize=7, color='steelblue', linestyle='-',
#          linewidth=1,
#          label='This Paper(BWM)')
# plt.plot(x_labels, perfect_satisfaction_rate_com_dy, marker='^', markersize=7, color='steelblue', linestyle='-.',
#          linewidth=1,
#          label='This Paper(EWM)')
#
# plt.xlabel('Number of Requests (unit time)')
# plt.ylabel('Scheduling Success Rate')
# plt.xticks(x_labels, rst_num)
#
# # 动态设置 y 轴范围
# min_y = min(min(perfect_satisfaction_rate_com_dy_my), min(perfect_satisfaction_rate_com_dy)) - 0.05
# max_y = max(max(perfect_satisfaction_rate_com_dy_my), max(perfect_satisfaction_rate_com_dy)) + 0.05
# plt.ylim(min_y, max_y)
#
# plt.grid(axis='x', linestyle='-.', color='lightgray')
# plt.grid(axis='y', linestyle='-.', color='lightgray')
# plt.legend()
#
# # 设置背景色
# # plt.gca().set_facecolor('lightgray')  # 设置淡色背景
#
# # 设置边框线条粗细
# plt.gca().spines['top'].set_linewidth(1.5)
# plt.gca().spines['right'].set_linewidth(1.5)
# plt.gca().spines['left'].set_linewidth(1.5)
# plt.gca().spines['bottom'].set_linewidth(1.5)
#
# # 显示图形
# plt.show()

#
# plt.figure(figsize=(9, 10), dpi=600)  # 高分辨率图形
# # 绘制第3个图
# plt.plot(x_labels, perfect_satisfaction_rate_com_dy, marker='^', markersize=12, color='steelblue', linestyle='-',
#          linewidth=4.5, label='This Paper(EWM)')
# plt.plot(x_labels, perfect_satisfaction_rate_com_dy_my, marker='^', markersize=12, color='steelblue', linestyle='-.',
#          linewidth=4, label='This Paper(BWM)', alpha=0.5)
# plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy, marker='s', markersize=12, color='darkorange', linestyle='-',
#          linewidth=4.5, label='CFN(EWM)')
# plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy_my, marker='s', markersize=12, color='darkorange', linestyle='-.',
#          linewidth=4, label='CFN(BWM)', alpha=0.5)
#
# plt.xlabel('Number of Requests (unit time)', fontsize=22)  # 设置字体大小
# plt.ylabel('Scheduling Success Rate', fontsize=22)  # 设置字体大小
# plt.xticks(x_labels, rst_num, fontsize=20)  # 设置字体大小
# plt.yticks(fontsize=20)
# # 动态设置 y 轴范围
# min_y = min(min(perfect_satisfaction_rate_com_dy), min(perfect_satisfaction_rate_com_dy_my),
#             min(perfect_satisfaction_rate_cfn_dy), min(perfect_satisfaction_rate_cfn_dy_my)) - 0.05
# max_y = max(max(perfect_satisfaction_rate_com_dy), max(perfect_satisfaction_rate_com_dy_my),
#             max(perfect_satisfaction_rate_cfn_dy), max(perfect_satisfaction_rate_cfn_dy_my)) + 0.05
# plt.ylim(min_y, max_y)
#
# plt.grid(axis='x', linestyle='-.', color='lightgray', linewidth=2)
# plt.grid(axis='y', linestyle='-.', color='lightgray', linewidth=2)
# plt.legend(fontsize=19, loc='lower left')  # 设置图例字体大小
# # 设置边框线条粗细
# plt.gca().spines['top'].set_linewidth(4)
# plt.gca().spines['right'].set_linewidth(4)
# plt.gca().spines['left'].set_linewidth(4)
# plt.gca().spines['bottom'].set_linewidth(4)
# # plt.tick_params(axis='x', which='both', direction='in', length=1, width=0.2)  # x轴刻度
# # plt.tick_params(axis='y', which='both', direction='in', length=1, width=0.2)  # y轴刻度
# # 显示图形
# plt.savefig('figure10b.pdf', dpi=600)
# plt.show()

import pandas as pd
import matplotlib.pyplot as plt


def extract_balance_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algorithm'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['zero_ratio'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_success_rate_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['success_rate'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_dy_success_rate_values(file_list):
    success_rates = []
    improvement_rates = []
    perfect_satisfaction_rates = []

    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            success_rates.append(topsis_row['success_rate'].values[0])
            improvement_rates.append(topsis_row['avg_improvement_rate'].values[0])
            perfect_satisfaction_rates.append(topsis_row['avg_perfect_rate'].values[0])

    return success_rates, improvement_rates, perfect_satisfaction_rates


def plot_data(x, y_data, labels, title, ax):
    for y, label in zip(y_data, labels):
        valid_x = [x[i] for i in range(len(x)) if y[i] is not None]
        valid_y = [val for val in y if val is not None]
        ax.plot(valid_x, valid_y, marker='o', label=label)
        for i, txt in enumerate(valid_y):
            ax.annotate(f'{txt:.3f}', (valid_x[i], valid_y[i]), textcoords="offset points", xytext=(0, 10), ha='center',
                        fontsize=6)
    ax.set_title(title, fontsize=12)
    ax.set_xlabel('Request Numbers', fontsize=12)
    ax.set_ylabel('Values', fontsize=12)
    ax.grid(True)
    ax.set_xticks(x)
    ax.legend(fontsize=6)


def plot_metric(rst_num, data, metric, ylabel, title):
    plt.figure(figsize=(10, 6))
    # colors = ['red', 'blue', 'black', 'green', 'orange', 'purple', 'pink']
    # labels = ['cfn_en', 'com1_en', 'com1_en_and_my', 'com1_enbwm', 'com1_my_bwm', 'com1_mix_bwm', 'com1_choice']
    # colors = ['red', 'blue', 'purple']
    # labels = ['cfn_en', 'com1_en', 'com1_my_bwm']
    # colors = ['red', 'blue', 'purple', 'black']
    # labels = ['cfn_en', 'com1_en', 'com1_my_bwm', 'com1_enbwm']
    colors = ['red', 'blue', 'black', 'purple']
    labels = ['cfn_en', 'com1_en', 'com1_my_bwm', 'com1_choice']
    for i, (color, label) in enumerate(zip(colors, labels)):
        plt.plot(rst_num, data[i], label=label, color=color, marker='o')
        plt.scatter(rst_num, data[i], color=color)
        for x, y in zip(rst_num, data[i]):
            plt.text(x, y, f'{y:.2f}', fontsize=9, ha='right', va='bottom', color=color)

    plt.xlabel('Request Number')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()


# 数字列表
rst_num = [10, 30, 50, 100, 150]
balance_list_cfn = [f"./algo_final_result/avg_balance_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com_en = [f"./algo_final_result/avg_balance_results_with_com1_en_{n}_{n}_{n}.csv" for n in rst_num]
# balance_list_com_en_and_my = [f"./algo_final_result/avg_balance_results_with_com1_en_and_my_{n}_{n}_{n}.csv" for n in
#                               rst_num]
# balance_list_com_enbwm = [f"./algo_final_result/avg_balance_results_with_com1_enbwm_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com_my_bwm = [f"./algo_final_result/avg_balance_results_with_com1_my_bwm_{n}_{n}_{n}.csv" for n in
                           rst_num]
# balance_list_com_mix_bwm = [f"./algo_final_result/avg_balance_results_with_com1_mix_bwm_{n}_{n}_{n}.csv" for n in
#                             rst_num]
balance_list_com_choice = [f"./algo_final_result/avg_balance_results_with_com1_choice_{n}_{n}_{n}.csv" for n in
                           rst_num]
balance_cfn = extract_balance_values(balance_list_cfn)
balance_com_en = extract_balance_values(balance_list_com_en)
# balance_com_en_and_my = extract_balance_values(balance_list_com_en_and_my)
# balance_com_enbwm = extract_balance_values(balance_list_com_enbwm)
balance_com_my_bwm = extract_balance_values(balance_list_com_my_bwm)
# balance_com_mix_bwm = extract_balance_values(balance_list_com_mix_bwm)
balance_com_choice = extract_balance_values(balance_list_com_choice)

success_list_cfn_dy = [f"./algo_final_result/success_rate_dy_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_en_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_en_{n}_{n}_{n}.csv" for n in rst_num]
# success_list_com_en_and_my_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_en_and_my_{n}_{n}_{n}.csv" for
#                                  n in rst_num]
# success_list_com_enbwm_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_enbwm_{n}_{n}_{n}.csv" for n in
#                              rst_num]
success_list_com_my_bwm_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_my_bwm_{n}_{n}_{n}.csv" for n in
                              rst_num]
# success_list_com_mix_bwm_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_mix_bwm_{n}_{n}_{n}.csv" for n
#                                in
#                                rst_num]
success_list_com_choice_dy = [f"./algo_final_result/success_rate_dy_results_with_com1_choice_{n}_{n}_{n}.csv" for n in
                              rst_num]

success_cfn_dy, improvement_cfn_dy, perfect_satisfaction_cfn_dy = extract_dy_success_rate_values(success_list_cfn_dy)
success_com_en_dy, improvement_com_en_dy, perfect_satisfaction_com_en_dy = extract_dy_success_rate_values(
    success_list_com_en_dy)
# success_com_en_and_my_dy, improvement_com_en_and_my_dy, perfect_satisfaction_com_en_and_my_dy = extract_dy_success_rate_values(
#     success_list_com_en_and_my_dy)
# success_com_enbwm_dy, improvement_com_enbwm_dy, perfect_satisfaction_com_enbwm_dy = extract_dy_success_rate_values(
#     success_list_com_enbwm_dy)
success_com_my_bwm_dy, improvement_com_my_bwm_dy, perfect_satisfaction_com_my_bwm_dy = extract_dy_success_rate_values(
    success_list_com_my_bwm_dy)
# success_com_mix_bwm_dy, improvement_com_mix_bwm_dy, perfect_satisfaction_com_mix_bwm_dy = extract_dy_success_rate_values(
#     success_list_com_mix_bwm_dy)
success_com_choice_dy, improvement_com_choice_dy, perfect_satisfaction_com_choice_dy = extract_dy_success_rate_values(
    success_list_com_choice_dy)

# 可视化函数


# 数据汇总
# success_rates = [success_cfn_dy, success_com_en_dy, success_com_en_and_my_dy, success_com_enbwm_dy,
#                  success_com_my_bwm_dy, success_com_mix_bwm_dy, success_com_choice_dy]
# improvement_rates = [improvement_cfn_dy, improvement_com_en_dy, improvement_com_en_and_my_dy, improvement_com_enbwm_dy,
#                      improvement_com_my_bwm_dy, improvement_com_mix_bwm_dy, improvement_com_choice_dy]
# perfect_satisfaction_rates = [perfect_satisfaction_cfn_dy, perfect_satisfaction_com_en_dy,
#                               perfect_satisfaction_com_en_and_my_dy, perfect_satisfaction_com_enbwm_dy,
#                               perfect_satisfaction_com_my_bwm_dy, perfect_satisfaction_com_mix_bwm_dy,
#                               perfect_satisfaction_com_choice_dy]
success_rates = [success_cfn_dy, success_com_en_dy, success_com_my_bwm_dy, success_com_choice_dy]
improvement_rates = [improvement_cfn_dy, improvement_com_en_dy, improvement_com_my_bwm_dy, improvement_com_choice_dy]
perfect_satisfaction_rates = [perfect_satisfaction_cfn_dy, perfect_satisfaction_com_en_dy,
                              perfect_satisfaction_com_my_bwm_dy,
                              perfect_satisfaction_com_choice_dy]
# success_rates = [success_cfn_dy, success_com_en_dy,success_com_my_bwm_dy]
# improvement_rates = [improvement_cfn_dy, improvement_com_en_dy,
#                      improvement_com_my_bwm_dy]
# perfect_satisfaction_rates = [perfect_satisfaction_cfn_dy, perfect_satisfaction_com_en_dy,
#                               perfect_satisfaction_com_my_bwm_dy]
# success_rates = [success_cfn_dy, success_com_en_dy, success_com_my_bwm_dy, success_com_enbwm_dy]
# improvement_rates = [improvement_cfn_dy, improvement_com_en_dy, improvement_com_my_bwm_dy, improvement_com_enbwm_dy]
# perfect_satisfaction_rates = [perfect_satisfaction_cfn_dy,perfect_satisfaction_com_en_dy, perfect_satisfaction_com_my_bwm_dy,
#                               perfect_satisfaction_com_enbwm_dy]
# 绘制成功率图
plot_metric(rst_num, success_rates, 'success_rate', 'Success Rate', 'Success Rate Comparison')

# 绘制改进率图
plot_metric(rst_num, improvement_rates, 'avg_improvement_rate', 'Average Improvement Rate',
            'Average Improvement Rate Comparison')

# 绘制完美满意率图
plot_metric(rst_num, perfect_satisfaction_rates, 'avg_perfect_rate', 'Perfect Satisfaction Rate',
            'Perfect Satisfaction Rate Comparison')

success_list_cfn = [f"./algo_final_result/success_rate_sta_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_en = [f"./algo_final_result/success_rate_sta_results_with_com1_en_{n}_{n}_{n}.csv" for n in rst_num]
# success_list_com_en_and_my = [f"./algo_final_result/success_rate_sta_results_with_com1_en_and_my_{n}_{n}_{n}.csv" for n
#                               in rst_num]
# success_list_com_enbwm = [f"./algo_final_result/success_rate_sta_results_with_com1_enbwm_{n}_{n}_{n}.csv" for n in
#                           rst_num]
success_list_com_my_bwm = [f"./algo_final_result/success_rate_sta_results_with_com1_my_bwm_{n}_{n}_{n}.csv" for n in
                           rst_num]
# success_list_com_mix_bwm = [f"./algo_final_result/success_rate_sta_results_with_com1_mix_bwm_{n}_{n}_{n}.csv" for n in
#                             rst_num]
success_list_com_choice = [f"./algo_final_result/success_rate_sta_results_with_com1_choice_{n}_{n}_{n}.csv" for n in
                           rst_num]
success_cfn = extract_success_rate_values(success_list_cfn)
success_com_en = extract_success_rate_values(success_list_com_en)
# success_com_en_and_my = extract_success_rate_values(success_list_com_en_and_my)
# success_com_enbwm = extract_success_rate_values(success_list_com_enbwm)
success_com_my_bwm = extract_success_rate_values(success_list_com_my_bwm)
# success_com_mix_bwm = extract_success_rate_values(success_list_com_mix_bwm)
success_com_choice = extract_success_rate_values(success_list_com_choice)
fig, axs = plt.subplots(1, 3, figsize=(18, 6))

# Balance数据
# balance_data = [
#     balance_cfn, balance_com_en, balance_com_en_and_my,
#     balance_com_enbwm, balance_com_my_bwm, balance_com_mix_bwm, balance_com_choice
# ]
balance_data = [
    balance_cfn, balance_com_en,
    balance_com_my_bwm, balance_com_choice
]
# balance_labels = [
#     'balance_cfn', 'balance_com_en', 'balance_com_en_and_my',
#     'balance_com_enbwm', 'balance_com_my_bwm', 'balance_com_mix_bwm', 'balance_com_choice'
# ]
balance_labels = [
    'balance_cfn', 'balance_com_en',
    'balance_com_my_bwm', 'balance_com_choice'
]
plot_data(rst_num, balance_data, balance_labels, 'Balance Values', axs[0])

# Dynamic Success Rate数据
# success_dy_data = [
#     success_cfn_dy, success_com_en_dy, success_com_en_and_my_dy,
#     success_com_enbwm_dy, success_com_my_bwm_dy, success_com_mix_bwm_dy, success_com_choice_dy
# ]
success_dy_data = [
    success_cfn_dy, success_com_en_dy,
    success_com_my_bwm_dy, success_com_choice_dy
]
print(success_dy_data)
# success_dy_labels = [
#     'success_cfn_dy', 'success_com_en_dy', 'success_com_en_and_my_dy',
#     'success_com_enbwm_dy', 'success_com_my_bwm_dy', 'success_com_mix_bwm_dy', 'success_com_choice_dy'
# ]
success_dy_labels = [
    'success_cfn_dy', 'success_com_en_dy', 'success_com_my_bwm_dy', 'success_com_choice_dy'
]
plot_data(rst_num, success_dy_data, success_dy_labels, 'Dynamic Success Rate', axs[1])

# Static Success Rate数据
# success_sta_data = [
#     success_cfn, success_com_en, success_com_en_and_my,
#     success_com_enbwm, success_com_my_bwm, success_com_mix_bwm, success_com_choice
# ]
success_sta_data = [
    success_cfn, success_com_en,
     success_com_my_bwm, success_com_choice
]
# success_sta_labels = [
#     'success_cfn', 'success_com_en', 'success_com_en_and_my',
#     'success_com_enbwm', 'success_com_my_bwm', 'success_com_mix_bwm', 'success_com_choice'
# ]
success_sta_labels = [
    'success_cfn', 'success_com_en',
     'success_com_my_bwm', 'success_com_choice'
]
plot_data(rst_num, success_sta_data, success_sta_labels, 'Static Success Rate', axs[2])

# 调整子图之间的间距
plt.tight_layout()
plt.show()

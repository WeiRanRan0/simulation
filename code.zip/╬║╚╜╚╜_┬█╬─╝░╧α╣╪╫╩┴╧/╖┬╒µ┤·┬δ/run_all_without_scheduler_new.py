import os

py_files_rst_gen = ['datacenter_per_requests_num.py',
                    'datacenter_request_info_gen.py']
py_files_com_scheduler = [
                          'match_with_delay_complicated22.py',
                          'satisfaction_rate_com22.py',
                          'resource_analy_with_delay_domain_complicated22.py',
                          'satisfaction_rate_com22_with_resource.py',
                          'balance_analy_com22.py'
                          ]

py_files_cfn_scheduler = [
                          'match_with_cfn.py',
                          'satisfaction_rate_cfn.py',
                          'resource_analy_with_cfn.py',
                          'satisfaction_rate_cfn_with_resource.py',
                          'balance_analy_cfn.py']

num = 10
algo_com = 'en'
algo_cfn = 'en'

# os.system(f"python scheduler_with_delay_complicated2.py {algo_com}")
# os.system(f"python scheduler_with_cfn.py {algo_cfn}")

for i in range(num):

    for py_file in py_files_rst_gen:
        os.system(f"python {py_file} {algo_cfn} {i}")

    for py_file in py_files_com_scheduler:
        os.system(f"python {py_file} {algo_com} {i}")

    for py_file in py_files_cfn_scheduler:
        os.system(f"python {py_file} {algo_cfn} {i}")




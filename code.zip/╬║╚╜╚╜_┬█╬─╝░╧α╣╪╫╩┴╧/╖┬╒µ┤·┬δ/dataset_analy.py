import pickle
import pandas as pd
import matplotlib.pyplot as plt
from Parameter import *
# Step 1: 读取 data.xlsx 文件
data = pd.read_excel('data.xlsx').iloc[:1300, :]

# Step 2: 提取每一列数据，并分别进行分析
time_data = data.iloc[:, 0]
rate_data = data.iloc[:, 1]
cpu_data = data.iloc[:, 2]
mem_data = data.iloc[:, 3]

# 指定区间范围


# 分析第一列数据
interval_counts1 = []
total_data_count = len(time_data)

for interval in DELAY_INTERVALS:
    interval_start, interval_end = interval
    interval_count = ((time_data >= interval_start) & (time_data <= interval_end)).sum()
    interval_counts1.append(interval_count)

# 计算每个区间的概率值
interval_probabilities1 = [count / total_data_count for count in interval_counts1]
with open('interval_probabilities1.pkl', 'wb') as file:
    pickle.dump(interval_probabilities1, file)
# 打印每个区间的数据个数和概率值
print("Column 1 Interval Counts and Probabilities:")
for interval, count, probability in zip(DELAY_INTERVALS, interval_counts1, interval_probabilities1):
    interval_start, interval_end = interval
    print(f"Interval [{interval_start}, {interval_end}]: Count = {count}/{total_data_count}, Probability = {probability}")

print("-" * 50)

# 分析第二列数据

interval_counts2 = []
total_data_count = len(rate_data)

for interval in RATE_INTERVALS:
    interval_start, interval_end = interval
    interval_count = ((rate_data >= interval_start) & (rate_data <= interval_end)).sum()
    interval_counts2.append(interval_count)

# 计算每个区间的概率值
print(sum(interval_counts2))
interval_probabilities2 = [count / sum(interval_counts2) for count in interval_counts2]
with open('interval_probabilities2.pkl', 'wb') as file:
    pickle.dump(interval_probabilities2, file)
# 打印每个区间的数据个数和概率值
print("Column 2 Interval Counts and Probabilities:")
for i, (interval, count, probability) in enumerate(zip(RATE_INTERVALS, interval_counts2, interval_probabilities2)):
    interval_start, interval_end = interval
    print(
        f"Interval {i + 1}: [{interval_start}, {interval_end}], Count: {count}/{sum(interval_counts2)}, Probability: {probability}")

print("-" * 50)

# 打印每个区间的数据个数和概率值
print("Column 2 Interval Counts and Probabilities:")
for i, (interval, count, probability) in enumerate(zip(RATE_INTERVALS, interval_counts2, interval_probabilities2)):
    interval_start, interval_end = interval
    print(
        f"Interval {i + 1}: [{interval_start}, {interval_end}], Count: {count}/{sum(interval_counts2)}, Probability: {probability}")

print("-" * 50)
max_probability_1 = max(interval_probabilities1)
max_probability_2 = max(interval_probabilities2)
plt.figure(figsize=(10, 6))

plt.subplot(2, 1, 1)  # 第一个子图
plt.bar(range(len(DELAY_INTERVALS)), interval_probabilities1, tick_label=[f"[{interval[0]}, {interval[1]}]" for interval in DELAY_INTERVALS])
plt.xlabel('Intervals')
plt.ylabel('Probability')
plt.title('Service Delay Interval Probabilities')
plt.ylim(0, max_probability_1 + 0.1)
# 显示计数和概率
for i, (interval, count, probability) in enumerate(zip(DELAY_INTERVALS, interval_counts1, interval_probabilities1)):
    plt.text(i, probability + 0.01, f" {probability:.4f}", ha='center')

# 绘制子图2
plt.subplot(2, 1, 2)  # 第二个子图
plt.bar(range(len(RATE_INTERVALS)), interval_probabilities2, tick_label=[f"[{interval[0]}, {interval[1]}]" for interval in RATE_INTERVALS])
plt.xlabel('Intervals')
plt.ylabel('Probability')
plt.title('Success Rate Interval Probabilities')
plt.ylim(0, max_probability_2 + 0.1)
# 显示计数和概率
for i, (interval, count, probability) in enumerate(zip(RATE_INTERVALS, interval_counts2, interval_probabilities2)):
    plt.text(i, probability + 0.02, f" {probability:.4f}", ha='center')

plt.tight_layout()  # 调整布局，避免子图重叠
plt.show()
# 分析第三列数据

interval_counts3 = []
total_data_count = len(cpu_data)

for interval in CPU_INTERVALS:
    interval_start, interval_end = interval
    interval_count = ((cpu_data >= interval_start) & (cpu_data <= interval_end)).sum()
    interval_counts3.append(interval_count)

# 计算每个区间的概率值
print(sum(interval_counts3))
interval_probabilities3 = [count / sum(interval_counts3) for count in interval_counts3]
with open('interval_probabilities3.pkl', 'wb') as file:
    pickle.dump(interval_probabilities3, file)
# 打印每个区间的数据个数和概率值
print("Column 3 Interval Counts and Probabilities:")
for i, (interval, count, probability) in enumerate(zip(CPU_INTERVALS, interval_counts3, interval_probabilities3)):
    interval_start, interval_end = interval
    print(
        f"Interval {i + 1}: [{interval_start}, {interval_end}], Count: {count}/{sum(interval_counts3)}, Probability: {probability}")

print("-" * 50)

# 分析第四列数据

interval_counts4 = []
total_data_count = len(mem_data)

for interval in MEM_INTERVALS:
    interval_start, interval_end = interval
    interval_count = ((mem_data >= interval_start) & (mem_data <= interval_end)).sum()
    interval_counts4.append(interval_count)

# 计算每个区间的概率值
print(sum(interval_counts4))
interval_probabilities4 = [count / sum(interval_counts4) for count in interval_counts4]
with open('interval_probabilities4.pkl', 'wb') as file:
    pickle.dump(interval_probabilities4, file)
# 打印每个区间的数据个数和概率值
print("Column 4 Interval Counts and Probabilities:")
for i, (interval, count, probability) in enumerate(zip(MEM_INTERVALS, interval_counts4, interval_probabilities4)):
    interval_start, interval_end = interval
    print(
        f"Interval {i + 1}: [{interval_start}, {interval_end}], Count: {count}/{sum(interval_counts4)}, Probability: {probability}")

print("-" * 50)
max_probability_3 = max(interval_probabilities3)
max_probability_4 = max(interval_probabilities4)
plt.figure(figsize=(10, 6))

plt.subplot(2, 1, 1)  # 第一个子图
plt.bar(range(len(CPU_INTERVALS)), interval_probabilities3, tick_label=[f"[{interval[0]}, {interval[1]}]" for interval in CPU_INTERVALS])
plt.xlabel('Intervals')
plt.ylabel('Probability')
plt.title('CPU need Interval Probabilities')
plt.ylim(0, max_probability_3 + 0.1)
# 显示计数和概率
for i, (interval, count, probability) in enumerate(zip(CPU_INTERVALS, interval_counts3, interval_probabilities3)):
    plt.text(i, probability + 0.01, f" {probability:.4f}", ha='center')

# 绘制子图2
plt.subplot(2, 1, 2)  # 第二个子图
plt.bar(range(len(MEM_INTERVALS)), interval_probabilities4, tick_label=[f"[{interval[0]}, {interval[1]}]" for interval in MEM_INTERVALS])
plt.xlabel('Intervals')
plt.ylabel('Probability')
plt.title('Mem Interval Probabilities')
plt.ylim(0, max_probability_4 + 0.1)
# 显示计数和概率
for i, (interval, count, probability) in enumerate(zip(MEM_INTERVALS, interval_counts4, interval_probabilities4)):
    plt.text(i, probability + 0.02, f" {probability:.4f}", ha='center')

plt.tight_layout()  # 调整布局，避免子图重叠
plt.show()



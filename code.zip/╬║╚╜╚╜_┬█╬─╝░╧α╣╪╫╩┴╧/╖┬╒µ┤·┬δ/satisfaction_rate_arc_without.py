import os
import pandas as pd
from Parameter import REQUEST_NUM, SERVICE_RECORD_NUM

folder_path = f'rst{REQUEST_NUM}_service{SERVICE_RECORD_NUM}/'

result_domain = pd.read_csv(folder_path + f'match_result_without_domain_{SERVICE_RECORD_NUM}.csv')
# result_without_domain = pd.read_csv(folder_path + f'match_result_without_domain_{SERVICE_RECORD_NUM}.csv')
# result_random_without_domain = pd.read_csv(folder_path + f'match_result_random_without_domain_{SERVICE_RECORD_NUM}.csv')
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
# 算法性能分析
print('in domain')
result_domain_g = result_domain.groupby('algo')
results_details_with_success = pd.DataFrame()
results_analysis_with_success = pd.DataFrame()
for algo_name, results in result_domain_g:
    success_count = 0
    success_count_without_link = 0
    rst_num = len(results)
    print(rst_num)
    # print('algo', algo_name)
    # print(results.head(3))
    for index, result in results.iterrows():
        # print(type(result))
        success = 1 if (result['rst_delay'] / result['rst_rate']) * 100 >= result['delay'] + result[
            'link_condition'] else 0
        success_without_link = 1 if (result['rst_delay'] / result['rst_rate']) * 100 >= result[
            'delay'] else 0
        result['success'] = success
        result['success_without_link'] = success_without_link
        success_count += success
        success_count_without_link += success_without_link
        results_details_with_success = pd.concat([results_details_with_success, pd.DataFrame(result).T])
    # print(success_count)
    results_analysis_with_success = pd.concat([results_analysis_with_success, pd.DataFrame(
        {'algo': [algo_name], 'success_rate': success_count / rst_num,
         'success_rate_without_link': success_count_without_link / rst_num})], ignore_index=True)
results_details_with_success.to_csv(
    folder_path + f'results_details_without_success_{REQUEST_NUM}_{SERVICE_RECORD_NUM}.csv')
results_details_with_success.to_excel(
    folder_path + f'results_details_without_success_{REQUEST_NUM}_{SERVICE_RECORD_NUM}.xlsx')
results_analysis_with_success.to_csv(
    folder_path + f'results_analysis_without_success_{REQUEST_NUM}_{SERVICE_RECORD_NUM}.csv')
import pickle
import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import s_max, s_min, strategy_coefficient, SERVICE_RECORD_NUM, Large_num, Medium_num, Edge_num, \
    large_service_num, medium_service_num, edge_service_num
from function import entropy_to_bwm

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

service_df = pd.read_csv(
    f'all_data_centers_services_with_delay_simple_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
service_grouped = service_df.groupby(['local_node', 'services_Type'])
schedule_result_df = pd.DataFrame()
with open('bwm_weights.pkl', 'rb') as file:
    bwm_weight = pickle.load(file)
algorithms = ['topsis', 'spotis', 'saw']
custom_m = ['mtp']
all_algo = algorithms + custom_m
for name, group in service_grouped:
    if len(group) == 1:
        for algo in all_algo:
            temp_result = group.copy()
            temp_result['algo'] = algo
            temp_result['cluster_rank_by_algo'] = 1
            schedule_result_df = pd.concat([schedule_result_df, temp_result])
    else:
        criteria_arr = group[
            ['Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity',
             'link_condition']].values
        criteria_type = ['min', 'max', 'max', 'max', 'max', 'max', 'max', 'min']
        alternatives = group[['Data_Center_Name']].values
        # print('criteria_arr', criteria_arr)
        en_weight = entropy_method(criteria_arr, criteria_type)
        # lic, mic = entropy_to_bwm(en_weight)
        # bwm_weight = bw_method(mic, lic)
        # print(en_weight, bwm_weight)
        my_ranks = my_topsis_method(criteria_arr, bwm_weight, criteria_type, s_min)
        custom_r = [my_ranks]
        values, ranks = compare_ranks_crisp(criteria_arr, en_weight, criteria_type, methods_list=algorithms,
                                            custom_methods=custom_m, custom_ranks=custom_r,
                                            strategy_coefficient=strategy_coefficient, s_min=s_min,
                                            s_max=s_max)
        for method, rank_series in ranks.items():
            # print(rank_series.values)
            temp_result = group.copy()
            temp_result['algo'] = method
            temp_result['cluster_rank_by_algo'] = rank_series.values
            # print(temp_result)
            schedule_result_df = pd.concat([schedule_result_df, temp_result])

schedule_result_df.to_csv(
    f'schedule_result_with_delay_simple_{large_service_num}_{medium_service_num}_{edge_service_num}.csv', index=False)
schedule_result_df.to_excel(
    f'schedule_result_with_delay_simple_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx', index=False)

import os
import sys

import pandas as pd
from Parameter import REQUEST_NUM, SERVICE_RECORD_NUM, large_service_num, medium_service_num, edge_service_num, \
    large_request_num, medium_request_num, edge_request_num

default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values
file_path = './match/'
file_to_save = './successrate/'
result_domain = pd.read_csv(file_path +
                            f'match_result_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
# failed_df = pd.read_csv(
#     f'./match/failed_rst_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
# failed_num = len(failed_df)
# print('failed num in match:', failed_num)
try:
    failed_df = pd.read_csv(f'./match/failed_rst_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
    failed_num = len(failed_df)
except pd.errors.EmptyDataError:
    failed_num = 0

print('failed num in match:', failed_num)
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
# 算法性能分析
print('***Static Success Rate SRV6******************************************************************************************************************')
result_domain_g = result_domain.groupby('algo')
results_details_with_success = pd.DataFrame()
results_analysis_with_success = pd.DataFrame()
for algo_name, results in result_domain_g:
    success_count = 0
    # success_count_without_link = 0
    rst_num = len(results)
    print('Algo:', algo_name, 'Request_num:', rst_num)

    # print('algo', algo_name)
    # print(results.head(3))
    for index, result in results.iterrows():
        # print(type(result))
        success = 1 if (result['Delay'] / result['Success_Rate']) * 100 >= result['delay'] + result[
            'link_condition'] else 0
        # success_without_link = 1 if (result['rst_delay'] / result['rst_rate']) * 100 >= result[
        #     'delay'] else 0
        result['success'] = success
        # result['success_without_link'] = success_without_link
        success_count += success
        # success_count_without_link += success_without_link
        results_details_with_success = pd.concat([results_details_with_success, pd.DataFrame(result).T])
    # print(success_count)
    results_analysis_with_success = pd.concat([results_analysis_with_success, pd.DataFrame(
        {'algo': [algo_name], 'success_rate': (success_count-failed_num) / rst_num
         # 'success_rate_without_link': success_count_without_link / rst_num
         })], ignore_index=True)

print('***SRV6 Success Rate ***: ')
print(results_analysis_with_success)
results_details_with_success.to_csv(file_to_save +
                                    f'results_details_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
results_details_with_success.to_excel(file_to_save +
                                      f'results_details_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx')
results_analysis_with_success.to_csv(file_to_save +
                                     f'results_analysis_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv',
                                     index=False)
print(
    f'satisfaction_rate_srv6.py********{weight_type}{iter_num} end--------------------------------------------------------------------------------')

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def extract_balance_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algorithm'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['zero_ratio'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_success_rate_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['success_rate'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_dy_success_rate_values(file_list):
    success_rates = []
    improvement_rates = []
    perfect_satisfaction_rates = []

    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            success_rates.append(topsis_row['avg_success_rate'].values[0])
            improvement_rates.append(topsis_row['avg_improvement_rate'].values[0])
            perfect_satisfaction_rates.append(topsis_row['avg_perfect_satisfaction_rate'].values[0])

    return success_rates, improvement_rates, perfect_satisfaction_rates


# 数字列表
rst_num = [10, 30, 60, 90, 120, 150]
algo_cfn = ['en', 'my_bwm', 'choice']
algo_com = ['en', 'my_bwm', 'choice']
# 创建两组文件名列表，使用 f-string 匹配数字部分


balance_list_cfn = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_cfn = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[0]}_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com = [f"./final_result/avg_balance_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
                       rst_num]
# success_list_com = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                     rst_num]

balance_list_cfn_my = [f"./final_result/avg_balance_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy_my = [f"./final_result/success_rate_dy_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_cfn_my = [f"./final_result/success_rate_sta_results_with_cfn_{algo_cfn[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
balance_list_com_my = [f"./final_result/avg_balance_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy_my = [f"./final_result/success_rate_dy_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
                          rst_num]
# success_list_com_my = [f"./final_result/success_rate_sta_results_with_com22_{algo_com[1]}_{n}_{n}_{n}.csv" for n in
#                        rst_num]
# balance_list_com1 = [f"./final_result/avg_balance_results_with_com1_{algo_com[0]}_{n}_{n}_{n}.csv" for n in rst_num]
# success_list_com1_dy = [f"./final_result/success_rate_dy_results_with_com1_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                         rst_num]
# success_list_com1 = [f"./final_result/success_rate_sta_results_with_com1_{algo_com[0]}_{n}_{n}_{n}.csv" for n in
#                      rst_num]

# 提取两组文件的topsis行的zero_ratio值
balance_cfn = extract_balance_values(balance_list_cfn)
balance_com = extract_balance_values(balance_list_com)
balance_cfn_my = extract_balance_values(balance_list_cfn_my)
balance_com_my = extract_balance_values(balance_list_com_my)
# balance_com1 = extract_balance_values(balance_list_com1)
# success_com1_dy = extract_dy_success_rate_values(success_list_com1_dy)
# success_com1 = extract_success_rate_values(success_list_com1)
success_cfn_dy = extract_dy_success_rate_values(success_list_cfn_dy)
success_com_dy = extract_dy_success_rate_values(success_list_com_dy)
success_cfn_dy_my = extract_dy_success_rate_values(success_list_cfn_dy_my)
success_com_dy_my = extract_dy_success_rate_values(success_list_com_dy_my)

# success_cfn = extract_success_rate_values(success_list_cfn)
# success_com = extract_success_rate_values(success_list_com)
# success_cfn_my = extract_success_rate_values(success_list_cfn_my)
# success_com_my = extract_success_rate_values(success_list_com_my)

# Extract the success rate, improvement rate, and perfect satisfaction rate
success_rate_cfn_dy, improvement_rate_cfn_dy, perfect_satisfaction_rate_cfn_dy = success_cfn_dy
success_rate_com_dy, improvement_rate_com_dy, perfect_satisfaction_rate_com_dy = success_com_dy
success_rate_cfn_dy_my, improvement_rate_cfn_dy_my, perfect_satisfaction_rate_cfn_dy_my = success_cfn_dy_my
success_rate_com_dy_my, improvement_rate_com_dy_my, perfect_satisfaction_rate_com_dy_my = success_com_dy_my

# Define the request numbers for the x-axis
x_labels = np.linspace(0, len(rst_num) - 1, len(rst_num))
# Plot for Balance CFN


# Create a new figure
plt.figure(figsize=(12, 8))
width = 0.1  # Width of bars
# Plot for Balance CFN

plt.plot(x_labels, balance_cfn, marker='o', color='#ff7f0e', linestyle='--', linewidth=1.5, label='CFN with objective weighting ')
plt.plot(x_labels, balance_cfn_my, marker='s', color='#ff7f0e', linestyle='--', linewidth=1.5, label='Balance CFN My')
plt.plot(x_labels, balance_com, marker='o', color='#1f77b4', linestyle='-', linewidth=1.5, label='Balance COM')
plt.plot(x_labels, balance_com_my, marker='s', color='#1f77b4', linestyle='-', linewidth=1.5, label='Balance COM My')

#
#
# # Adding bars for each dataset
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 1.5 * width, balance_cfn[i], width, color='#ff7f0e', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] - 0.5 * width, balance_cfn_my[i], width, color='#ff7f0e', alpha=1,hatch='////',edgecolor ='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, balance_com[i], width, color='#1f77b4', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, balance_com_my[i], width, color='#1f77b4', alpha=1, hatch='////',edgecolor ='darkgray')
# Annotate bars
for i, txt in enumerate(balance_cfn):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(balance_cfn_my):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(balance_com):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(balance_com_my):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
# Adding titles and labels
plt.title('Balance Comparison: CFN vs. COM')
plt.xlabel('Request Number')
plt.ylabel('Balance')
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='--', color='darkgray')
plt.ylim(0.2,1.1 )
plt.legend()
# plt.grid(True)

# Show plot
plt.show()

# Create figures for each indicator
# 1. Success Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, success_rate_cfn_dy, marker='o', color='#ff7f0e', linestyle='--', label='Success Rate CFN')
plt.plot(x_labels, success_rate_cfn_dy_my, marker='s', color='#ff7f0e', linestyle='--', label='Success Rate CFN My')
plt.plot(x_labels, success_rate_com_dy, marker='o', color='#1f77b4', linestyle='-', label='Success Rate COM')
plt.plot(x_labels, success_rate_com_dy_my, marker='s', color='#1f77b4', linestyle='-', label='Success Rate COM My')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 1.5 * width,  success_rate_cfn_dy[i], width, color='#ff7f0e', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] - 0.5 * width, success_rate_cfn_dy_my[i], width, color='#ff7f0e', alpha=1,hatch='////',edgecolor ='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, success_rate_com_dy[i], width, color='#1f77b4', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, success_rate_com_dy_my[i], width, color='#1f77b4', alpha=1, hatch='////',edgecolor ='darkgray')
for i, txt in enumerate(success_rate_cfn_dy):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(success_rate_cfn_dy_my):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(success_rate_com_dy):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
for i, txt in enumerate(success_rate_com_dy_my):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=7)
plt.title('Success Rate Comparison: CFN vs. COM')
plt.xlabel('Request Number')
plt.ylabel('Success Rate')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='--', color='darkgray')
plt.show()

# 2. Improvement Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, improvement_rate_cfn_dy, marker='o', color='#ff7f0e', linestyle='--', label='Improvement Rate CFN')
plt.plot(x_labels, improvement_rate_cfn_dy_my, marker='s', color='#ff7f0e', linestyle='--', label='Improvement Rate CFN My')
plt.plot(x_labels, improvement_rate_com_dy, marker='o', color='#1f77b4', linestyle='-', label='Improvement Rate COM')
plt.plot(x_labels, improvement_rate_com_dy_my, marker='s', color='#1f77b4', linestyle='-',
         label='Improvement Rate COM My')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 1.5 * width, improvement_rate_cfn_dy[i], width, color='#ff7f0e', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] - 0.5 * width, improvement_rate_cfn_dy_my[i], width, color='#ff7f0e', alpha=1,hatch='////',edgecolor ='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, improvement_rate_com_dy[i], width, color='#1f77b4', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, improvement_rate_com_dy_my[i], width, color='#1f77b4', alpha=1, hatch='////',edgecolor ='darkgray')
for i, txt in enumerate(improvement_rate_cfn_dy):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_cfn_dy_my):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_com_dy):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(improvement_rate_com_dy_my):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
plt.title('Improvement Rate Comparison: CFN vs. COM')
plt.xlabel('Request Number')
plt.ylabel('Improvement Rate')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='--', color='darkgray')
plt.show()

# 3. Perfect Satisfaction Rate
plt.figure(figsize=(12, 8))
plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy, marker='o', color='#ff7f0e', linestyle='--',
         label='Perfect Satisfaction Rate CFN')
plt.plot(x_labels, perfect_satisfaction_rate_cfn_dy_my, marker='s', color='#ff7f0e', linestyle='--',
         label='Perfect Satisfaction Rate CFN My')
plt.plot(x_labels, perfect_satisfaction_rate_com_dy, marker='o', color='#1f77b4', linestyle='-',
         label='Perfect Satisfaction Rate COM')
plt.plot(x_labels, perfect_satisfaction_rate_com_dy_my, marker='s', color='#1f77b4', linestyle='-',
         label='Perfect Satisfaction Rate COM My')
for i in range(len(rst_num)):
    plt.bar(x_labels[i] - 1.5 * width, perfect_satisfaction_rate_cfn_dy[i], width, color='#ff7f0e', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] - 0.5 * width, perfect_satisfaction_rate_cfn_dy_my[i], width, color='#ff7f0e', alpha=1,hatch='////',edgecolor ='darkgray')
    plt.bar(x_labels[i] + 0.5 * width, perfect_satisfaction_rate_com_dy[i], width, color='#1f77b4', alpha=1,edgecolor ='darkgray')
    plt.bar(x_labels[i] + 1.5 * width, perfect_satisfaction_rate_com_dy_my[i], width, color='#1f77b4', alpha=1, hatch='////',edgecolor ='darkgray')
for i, txt in enumerate(perfect_satisfaction_rate_cfn_dy):
    plt.text(x_labels[i] - 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_cfn_dy_my):
    plt.text(x_labels[i] - 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_com_dy):
    plt.text(x_labels[i] + 0.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
for i, txt in enumerate(perfect_satisfaction_rate_com_dy_my):
    plt.text(x_labels[i] + 1.5 * width, txt, f'{txt:.2f}', ha='center', va='bottom', fontsize=6)
plt.title('Perfect Satisfaction Rate Comparison: CFN vs. COM')
plt.xlabel('Request Number')
plt.ylabel('Perfect Satisfaction Rate')
plt.legend()
plt.xticks(x_labels, rst_num)
plt.grid(axis='x', linestyle='--', color='darkgray')
plt.show()

# balance_com1 = extract_balance_values(balance_list_com1)
# success_com1_dy = extract_dy_success_rate_values(success_list_com1_dy)
# success_com1 = extract_success_rate_values(success_list_com1)


# print('dy',success_cfn_dy[2],len(success_cfn_dy[2]))
# fig, axes = plt.subplots(1, 4, figsize=(18, 5))
#
# # 平衡值可视化
# axes[0].plot(rst_num, balance_cfn, color='blue', marker='o', label='CFN')
# for i, txt in enumerate(balance_cfn):
#     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[0].plot(rst_num, balance_com, color='yellow', marker='o', label='COM')
# for i, txt in enumerate(balance_com):
#     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[0].plot(rst_num, balance_com1, color='green', marker='o', label='COM1')
# # for i, txt in enumerate(balance_com1):
# #     axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[0].set_title('Balance Values')
# axes[0].set_xlabel('Number of Requests')
# axes[0].set_ylabel('Balance Value')
# axes[0].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[0].legend()
# axes[0].grid(True)
#
# # 动态成功率可视化
# axes[1].plot(rst_num, success_cfn_dy[0], color='blue', marker='o', label='CFN Dynamic')
# for i, txt in enumerate(success_cfn_dy[0]):
#     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[1].plot(rst_num, success_com_dy[0], color='yellow', marker='o', label='COM Dynamic')
# for i, txt in enumerate(success_com_dy[0]):
#     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[1].plot(rst_num, success_com1_dy[0], color='green', marker='o', label='COM1 Dynamic')
# # for i, txt in enumerate(success_com1_dy[0]):
# #     axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[1].set_title('Success Rate (Dynamic)')
# axes[1].set_xlabel('Number of Requests')
# axes[1].set_ylabel('Success Rate')
# axes[1].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[1].legend()
# axes[1].grid(True)
#
# axes[2].plot(rst_num, success_cfn_dy[1], color='blue', marker='o', label='CFN IMP')
# for i, txt in enumerate(success_cfn_dy[1]):
#     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[2].plot(rst_num, success_com_dy[1], color='yellow', marker='o', label='COM IMP')
# for i, txt in enumerate(success_com_dy[1]):
#     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[2].plot(rst_num, success_com1_dy[1], color='green', marker='o', label='COM1 IMP')
# # for i, txt in enumerate(success_com1_dy[1]):
# #     axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[2].set_title('IMP Rate (Dynamic)')
# axes[2].set_xlabel('Number of Requests')
# axes[2].set_ylabel('IMP Rate')
# axes[2].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[2].legend()
# axes[2].grid(True)
#
# axes[3].plot(rst_num, success_cfn_dy[2], color='blue', marker='o', label='CFN PERFECT')
# for i, txt in enumerate(success_cfn_dy[2]):
#     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[3].plot(rst_num, success_com_dy[2], color='yellow', marker='o', label='COM PERFECT')
# for i, txt in enumerate(success_com_dy[2]):
#     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# # axes[3].plot(rst_num, success_com1_dy[2], color='green', marker='o', label='COM1 PERFECT')
# # for i, txt in enumerate(success_com1_dy[2]):
# #     axes[3].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[3].set_title('PERFECT Rate (Dynamic)')
# axes[3].set_xlabel('Number of Requests')
# axes[3].set_ylabel('PERFECT Rate')
# axes[3].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[3].legend()
# axes[3].grid(True)
# 静态成功率可视化
# axes[4].plot(rst_num, success_cfn, marker='o', label='CFN Static')
# for i, txt in enumerate(success_cfn):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].plot(rst_num, success_com, marker='o', label='COM Static')
# for i, txt in enumerate(success_com):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].plot(rst_num, success_com1, marker='o', label='COM1 Static')
# for i, txt in enumerate(success_com1):
#     axes[4].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# axes[4].set_title('Success Rate (Static)')
# axes[4].set_xlabel('Number of Requests')
# axes[4].set_ylabel('Success Rate')
# axes[4].set_xticks(rst_num)  # 设置X轴刻度为指定的值
# axes[4].legend()
# axes[4].grid(True)

# plt.tight_layout()
# plt.show()

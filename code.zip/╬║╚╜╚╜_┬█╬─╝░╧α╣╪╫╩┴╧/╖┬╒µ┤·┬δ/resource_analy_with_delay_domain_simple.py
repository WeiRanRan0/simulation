import json
import numpy as np
from collections import deque
import time
import os
import math
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from function import read_node_resources_from_csv, read_tasks_from_csv
from Parameter import top_k, DOMAIN_INTERVAL, SERVICE_RECORD_NUM, REQUEST_NUM, large_request_num, medium_request_num, \
    edge_request_num, large_service_num, medium_service_num, edge_service_num, lam


def poisson_task_arrival(node_id):
    if node_id.startswith('Edge'):
        return max(np.random.poisson(20), 1)  # Minimum task count of 1 for 'Edge' nodes
    elif node_id.startswith('Medium'):
        return max(np.random.poisson(10), 1)  # Minimum task count of 1 for 'Medium' nodes
    elif node_id.startswith('Large'):
        return max(np.random.poisson(15), 1)  # Minimum task count of 1 for 'Large' nodes
    else:
        raise ValueError("Invalid node ID format.")


pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
folder_path = f'rst{REQUEST_NUM}_service{SERVICE_RECORD_NUM}/'

task_timings = {}
algorithm_results = {}
tasks_by_algo_and_node = {}
resource_utilizations = {}
task_failed_by_algo_and_node = {}


def task_processing(task):
    global node_resources
    print(f"InTask:{task.sid} Node_id{task.node_id}at time {time.time()},proTime{task.processing_time}")
    start_time = time.time()
    node_id = task.node_id
    alg = task.algorithm
    time.sleep(task.processing_time / 1000)
    end_time = time.time()  # Record task end time
    # Calculate task processing duration
    processing_duration = (end_time - start_time) * 1000
    # Save task timings by algorithm
    with node_resources[node_id]['lock']:
        node_resources[node_id]['cpu_capacity'] += task.cpu_need
        node_resources[node_id]['mem_capacity'] += task.mem_need
        node_resources[node_id]['disk_capacity'] += task.disk_need
        start_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time))
        end_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(end_time))
        if node_id not in task_timings:
            task_timings[node_id] = {}
        if alg not in task_timings[node_id]:
            task_timings[node_id][alg] = []

        task_timings[node_id][alg].append({
            'task_sid': task.sid,
            'start_time': start_time,
            'end_time': end_time,
            'start_time_str': start_time_str,
            'end_time_str': end_time_str,
            'p_time': processing_duration,
            'max_latency': task.rs_max_tolerance_latency
        })

        print(
            f"Task {task.sid} started at {start_time_str}, ended at {end_time_str}, cp_need:{task.cpu_need},mem_need:{task.mem_need},duration: {processing_duration} seconds, Algorithm: {alg}")
        print(
            f"Task {task.sid} completed on Node {node_id} with Algorithm {alg}. CPU: {node_resources[node_id]['cpu_capacity']}, Memory: {node_resources[node_id]['mem_capacity']}")


#
def process_wait_queue(tasks_dict: dict, node_rs: dict):
    for algor, nodes_tasks in tasks_dict.items():
        if algor not in task_failed_by_algo_and_node:
            task_failed_by_algo_and_node[algor] = {}

        for node_ids, tasks_lst in nodes_tasks.items():
            worker = math.floor(node_rs[node_ids]['cpu_all'])
            if node_ids not in task_failed_by_algo_and_node[algor]:
                task_failed_by_algo_and_node[algor][node_ids] = []

            executor = ThreadPoolExecutor(max_workers=worker)  # 设置最大工作线程数为可用的 CPU 核心数
            print(f"Algo:{algor}, Node:{node_ids},  Worker:{worker}")

            # 使用 deque 来作为等待队列
            wait_queue = deque()
            for tsk in tasks_lst:
            # task_count = poisson_task_arrival(node_ids)
            # length = len(tasks_lst)
            # iterations = length // task_count + 1
            #
            # for i in range(iterations):
            #     if (i + 1) * task_count > length:
            #         tasks_to_read = tasks_lst[i * task_count:]
            #     else:
            #         tasks_to_read = tasks_lst[i * task_count:(i + 1) * task_count]

                # for tsk in tasks_to_read:
                    # for _ in range(task_count):
                with node_rs[node_ids]['lock']:
                    if node_rs[node_ids]['cpu_capacity'] >= tsk.cpu_need and \
                            node_rs[node_ids]['mem_capacity'] >= tsk.mem_need and \
                            node_rs[node_ids]['disk_capacity'] >= tsk.disk_need:
                        wait_queue.append(tsk)  # 将任务按顺序添加到等待队列的末尾
                    else:
                        task_failed_by_algo_and_node[algor][node_ids].append({
                            'task_sid': tsk.sid,
                            'process_time': tsk.processing_time,
                            'max_delay': tsk.rs_max_tolerance_latency,
                            'cpu_need': tsk.cpu_need,
                            'mem_need': tsk.mem_need,
                            'disk_need': tsk.disk_need

                        })

            while wait_queue:  # 只要等待队列不为空，就继续处理任务
                tsks = wait_queue.popleft()  # 从等待队列左侧（队首）取出任务
                # print(
                #     f"Task {task.sid} on Node {node_id} with Algorithm {algorithm}. CPU: {node_resources[node_id]['cpu_capacity']}, Memory: {node_resources[node_id]['mem_capacity']}")

                with node_rs[node_ids]['lock']:
                    if node_rs[node_ids]['cpu_capacity'] >= tsks.cpu_need and \
                            node_rs[node_ids]['mem_capacity'] >= tsks.mem_need and \
                            node_rs[node_ids]['disk_capacity'] >= tsks.disk_need:
                        node_rs[node_ids]['cpu_capacity'] -= tsks.cpu_need
                        node_rs[node_ids]['mem_capacity'] -= tsks.mem_need
                        node_rs[node_ids]['disk_capacity'] -= tsks.disk_need
                        cpu_utilization = node_rs[node_ids]['cpu_capacity'] / node_rs[node_ids]['cpu_all']
                        mem_utilization = node_rs[node_ids]['mem_capacity'] / node_rs[node_ids]['mem_all']
                        disk_utilization = node_rs[node_ids]['disk_capacity'] / node_rs[node_ids]['disk_all']

                        balance_rate = cpu_utilization / mem_utilization
                        print(
                            f"Task {tsks.sid} on Node{node_ids} cpu_need:{tsks.cpu_need},mem_need:{tsks.mem_need},cpu_utilization: {node_rs[node_ids]['cpu_capacity'], cpu_utilization} ,mem_utilization:{node_rs[node_ids]['mem_capacity'], mem_utilization} Algorithm: {algor}")
                        if algor not in resource_utilizations:
                            resource_utilizations[algor] = {}
                        if node_ids not in resource_utilizations[algor]:
                            resource_utilizations[algor][node_ids] = []
                        resource_utilizations[algor][node_ids].append({
                            'task_id': tsks.sid,
                            'process_time': tsks.processing_time,
                            'max_delay': tsks.rs_max_tolerance_latency,
                            'cpu_need': tsks.cpu_need,
                            'mem_need': tsks.mem_need,
                            'disk_need': tsks.disk_need,
                            'cpu_utilization': cpu_utilization,
                            'mem_utilization': mem_utilization,
                            'disk_utilization': disk_utilization,
                            'balance_rate': balance_rate
                        })
                        executor.submit(task_processing, tsks)

                    else:
                        wait_queue.appendleft(tsks)  # 如果资源不足，将任务重新放入等待队列的左侧（原位置）

            executor.shutdown(wait=True)
            print(
                f"After algo:{algor}, cpu_left:{node_rs[node_ids]['cpu_capacity']}, mem_left:{node_rs[node_ids]['mem_capacity']},disk_left:{node_rs[node_ids]['disk_capacity']}")


def flatten_tasks_dict(tasks_by_algo_and_node):
    flat_data = []
    for algorithm, nodes in tasks_by_algo_and_node.items():
        for node_id, tasks in nodes.items():
            for task in tasks:
                flat_data.append({
                    'algorithm': algorithm,
                    'node_id': node_id,
                    'task': task  # You can add more task details here if needed
                })
    return flat_data


# #########################################################################################################################
# 读取任务匹配结果，提取每个集群的任务

tasks = read_tasks_from_csv(
    f'match_result_with_delay_domain_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
for task in tasks:
    if task.algorithm not in tasks_by_algo_and_node:
        tasks_by_algo_and_node[task.algorithm] = {}
    if task.node_id not in tasks_by_algo_and_node[task.algorithm]:
        tasks_by_algo_and_node[task.algorithm][task.node_id] = []
    tasks_by_algo_and_node[task.algorithm][task.node_id].append(task)

for algorithm, node_tasks in tasks_by_algo_and_node.items():
    for node_name, tasks_list in node_tasks.items():
        # print(algorithm)
        # print(tasks_list)
        tasks_list.sort(key=lambda x: (x.rs_delay, x.rs_rate))
        # print('after', tasks_list)
print("Sorted tasks organized by node and algorithm:")
for algorithm, node_tasks in tasks_by_algo_and_node.items():
    print(f"Algorithm  {algorithm}:")
    for node_id, tasks_list in node_tasks.items():
        print(f" Node {node_id}:")
        for task in tasks_list:
            print(
                f"    Task {task.sid} - Processing Time: {task.rs_delay}, CPU Need: {task.cpu_need}, Memory Need: {task.mem_need}"
                f"disk need: {task.disk_need}")

flat_data = flatten_tasks_dict(tasks_by_algo_and_node)

# Convert the flattened data to a pandas DataFrame
df = pd.DataFrame(flat_data)

# Save the DataFrame to CSV
csv_filename = f'tasks_by_algo_and_node_domain_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
df.to_csv(csv_filename, index=False)

# Save the DataFrame to Excel
excel_filename = f'tasks_by_algo_and_node_domain_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx'
df.to_excel(excel_filename, index=False)

node_resources = read_node_resources_from_csv('datacenterinfo/data_centers_info.csv')

#######################################################################################################################################################
########################################################################################################################################################
# 模拟任务处理
process_wait_queue(tasks_by_algo_and_node, node_resources)
if os.path.exists(
        folder_path + f'resource_utilizations_with_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.json'):
    os.remove(
        folder_path + f'resource_utilizations_with_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.json')

# Save resource_utilizations to a JSON file
with open(
        folder_path + f'resource_utilizations_with_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.json',
        'w') as file:
    json.dump(resource_utilizations, file, indent=2)
#

flat_data = []
#
# # 遍历嵌套字典的键和值，将其转换为DataFrame的行
for algor, node_data in resource_utilizations.items():
    for node_ids, tasks_list in node_data.items():
        for task in tasks_list:
            flat_data.append({
                'Algorithm': algor,
                'Node IDs': node_ids,
                'Task ID': task['task_id'],
                'Process Time': task['process_time'],
                'Max Delay': task['max_delay'],
                'CPU Need': task['cpu_need'],
                'Memory Need': task['mem_need'],
                'disk_need': task['disk_need'],
                'CPU Utilization': task['cpu_utilization'],
                'Memory Utilization': task['mem_utilization'],
                'disk utilization': task['disk_utilization'],
                'Balance Rate': task['balance_rate']
            })
df = pd.DataFrame(flat_data)
# 将DataFrame保存为CSV文件
df.to_csv(f'resource_utilizations_with_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.csv', index=False)
excel_filename = f'resource_utilizations_with_simple_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx'
df.to_excel(excel_filename, index=False)

import hashlib
import random
import threading
import numpy as np
import json
import pickle
import pandas as pd
from Parameter import service_type_num


# 节点sid生成函数
def generate_sid() -> int:
    return random.randint(1, service_type_num)  # 暂定，实际取值为0-255


# 时延等级映射函数
def delay_level(value):
    if value < 0:
        return None  # 如果输入值小于0，返回None或者其他你认为合适的值
    elif value < 50:
        return 0
    elif value < 100:
        return 1
    elif value < 150:
        return 2
    elif value < 200:
        return 3
    elif value < 250:
        return 4
    elif value < 300:
        return 5
    elif value < 350:
        return 6
    elif value < 400:
        return 7
    else:
        return 8


# 成功率等级映射函数
def rate_level(value):
    if value < 80:
        return None  # 如果输入值小于0，返回None或者其他你认为合适的值
    elif value < 85:
        return 3
    elif value < 90:
        return 2
    elif value < 95:
        return 1
    else:
        return 0


def hash_to_range_int(input_string, min_value, max_value):
    hash_value = hashlib.sha256(input_string.encode()).hexdigest()
    hash_integer = int(hash_value, 16)
    scaled_value = min_value + (hash_integer % (max_value - min_value + 1))
    return scaled_value


def hash_to_range(data, range_min, range_max):
    hash_object = hashlib.sha256(data.encode())
    hash_hex = hash_object.hexdigest()
    hash_int = int(hash_hex, 16)  # 将哈希值解释为一个整数
    mapped_value = range_min + (hash_int % (10 ** 10)) / (10 ** 10) * (range_max - range_min)  # 将整数映射到指定范围
    return mapped_value


# 节点名字生成函数
def generate_node_name() -> str:  # 暂时手动指定，根据拓扑来
    return f"h{random.randint(1, 8)}"


def generate_cluster_name(arr):
    return random.choice(arr)


# 网络节点名字生成函数
def generate_network_node_name() -> int:  # 暂时手动指定，根据拓扑来
    return random.randint(0, 24)


# 网络域内节点时延生成函数
def generate_link_btw_network_nodes(local_network_num, other_network_num) -> float:
    if abs(local_network_num - other_network_num) == 0:
        return 0.0001
    elif abs(local_network_num - other_network_num) <= 4:
        return hash_to_range(f'in_domain_delay_{local_network_num}_{other_network_num}', 0.01, 4.99)
    else:
        return hash_to_range(f'out_domain_delay_{local_network_num}_{other_network_num}', 5, 14.99)


def generate_domain_btw_network_nodes(node_i, node_j, interval) -> int:
    domain_i = node_i // interval  # Calculate the domain for node_i
    domain_j = node_j // interval  # Calculate the domain for node_j
    return domain_i if domain_i == domain_j else -1  # Return the domain if nodes are in the same domain, otherwise -1


# 节点链路 服务等级等哈希映射函数


# 计算服务之间的计算和存储需求与集群本身剩余计算和存储资源的相似度
def cosine_similarity(a, b):
    dot_product = np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    similarity = dot_product / (norm_a * norm_b)
    return similarity


def interval_function(value, std_value):
    # 将value转换为NumPy数组
    value_array = np.array(value)

    # 计算与标准值的差的绝对值
    absolute_difference = np.abs(value_array - std_value)

    # 使用条件表达式判断绝对值大小并返回相应的值
    result = np.where(absolute_difference < 0.5, 1.5,
                      np.where((absolute_difference >= 0.5) & (absolute_difference < 1), 1, 1 / absolute_difference))

    # 返回结果的平均值作为浮点数
    return float(np.mean(result))


# 节点状态生成函数
def simple_string_hash(input_string):
    hash_value = sum(ord(char) for char in input_string) % 3
    return hash_value + 1


def balance(difference):
    if difference <= 0.2:
        return 3
    elif 0.2 < difference <= 0.4:
        return 2

    elif 0.4 < difference <= 0.6:
        return 1
    else:
        return 0  # 如果超过了 0.6 的差距，可以根据具体情况进行处理，这里设为 0


# 定义节点信息值
def calculate_link_condition(self):
    lc = hash_to_range(self.node_name, 0.2, 0.99)
    return lc


def fuzzy_coefficient(rank1, rank2, top_k):
    # 只考虑前 k 个元素
    k = top_k
    rank1_top_k = rank1[:k]
    rank2_top_k = rank2[:k]
    # 检查两个排名列表的前 k 个元素是否完全相同
    if all(rank1_top_k[i] == rank2_top_k[i] for i in range(k)):
        return 1
    else:
        return 0


class Task:
    def __init__(self, sid, node_id, algorithm, rs_delay, rs_max_tolerance_latency, delay_level, rate_level, cpu_need,
                 mem_need, processing_time, link_condition):
        self.sid = sid
        self.node_id = node_id
        self.algorithm = algorithm
        self.rs_delay = rs_delay
        self.rs_max_tolerance_latency = rs_max_tolerance_latency
        self.delay_level = delay_level
        self.rate_level = rate_level
        self.cpu_need = cpu_need
        self.mem_need = mem_need
        self.processing_time = processing_time
        self.link_condition = link_condition


class Tasks:
    def __init__(self, algorithm, local_id, node_id, sid, rs_delay, rs_rate, processing_time, cpu_need, mem_need,
                 disk_need, link_c):
        self.algorithm = algorithm
        self.local_id = local_id
        self.node_id = node_id
        self.sid = sid
        self.rs_delay = rs_delay
        self.rs_rate = rs_rate
        self.processing_time = processing_time
        self.rs_max_tolerance_latency = (self.rs_delay / self.rs_rate) * 100
        self.cpu_need = cpu_need
        self.mem_need = mem_need
        self.disk_need = disk_need
        self.link_condition = link_c

    def to_dict(self):
        return {
            'algorithm': self.algorithm,
            'local_node': self.local_id,
            'name': self.node_id,
            'Request_Type': self.sid,
            'Delay': self.rs_delay,
            'Success_Rate': self.rs_rate,
            'delay': self.processing_time,
            'cpu_need': self.cpu_need,
            'mem_need': self.mem_need,
            'disk_need': self.disk_need,
            'link_condition': self.link_condition
        }


class ResourceUtilization:
    def __init__(self, sid):
        self.sid = sid
        self.cpu_utilization = []  # 存储每个时刻的CPU利用率
        self.mem_utilization = []  # 存储每个时刻的内存利用率
        self.balance_rate = []  # 存储每个时刻的均衡率

    def add_utilization(self, cpu_util, mem_util, balance_rate):
        self.cpu_utilization.append(cpu_util)
        self.mem_utilization.append(mem_util)
        self.balance_rate.append(balance_rate)


def read_node_resources_from_json(filename):
    with open(filename, 'r') as file:
        node_data = json.load(file)
    node_resources = {}
    for node_info in node_data:
        node_id = node_info['node_name']
        cpu_all = node_info['cpu_all']
        mem_all = node_info['mem_all']
        cpu_availability = node_info['cpu_availability']
        mem_availability = node_info['mem_availability']
        cpu = node_info['cpu']
        mem = node_info['mem']
        balance = node_info['balance']
        link_condition = node_info['link_condition']
        node_resources[node_id] = {
            'cpu_all': cpu_all,
            'mem_all': mem_all,
            'cpu_availability': cpu_availability,
            'mem_availability': mem_availability,
            'balance': balance,
            'link_condition': link_condition,
            'cpu_capacity': cpu,  # Calculate initial CPU capacity
            'mem_capacity': mem,  # Calculate initial memory capacity
            'lock': threading.Lock()  # Add lock for thread safety
        }
    return node_resources


def read_node_resources_from_csv(csv_file):
    # 从 CSV 文件读取数据
    cluster = pd.read_csv(csv_file)

    # 创建一个空的字典用于存储节点资源信息
    node_resource = {}

    # 遍历 CSV 数据的每一行，并将每行数据作为一个节点的信息添加到 node_resources 字典中
    for index, row in cluster.iterrows():
        node_id = row['name']
        cpu_all = row['cpu_all']
        mem_all = row['mem_all']
        disk_all = row['disk_all']
        cpu_availability = row['cpu_utili']
        mem_availability = row['mem_utili']
        disk_availability = row['disk_utili']
        cpu_capacity = row['cpu_capacity']
        mem_capacity = row['mem_capacity']
        disk_capacity = row['disk_capacity']

        # 添加节点信息到字典中，包括 CPU 和内存的各种指标以及一个用于线程安全的锁对象
        node_resource[node_id] = {
            'cpu_all': cpu_all,
            'mem_all': mem_all,
            'disk_all': disk_all,
            'cpu_availability': cpu_availability,
            'mem_availability': mem_availability,
            'disk_availability': disk_availability,
            'cpu_capacity': cpu_capacity,
            'mem_capacity': mem_capacity,
            'disk_capacity': disk_capacity,
            'lock': threading.Lock()  # 为每个节点添加一个线程锁对象
        }

    # 返回包含节点信息的字典
    return node_resource


def read_tasks_from_csv(filename):
    # 读取CSV文件并转换为DataFrame
    df = pd.read_csv(filename)

    tasks = []
    for index, row in df.iterrows():
        task = Tasks(row['algo'], row['local_node'], row['name'], row['Request_Type'], row['Delay'],
                     row['Success_Rate'], row['delay'], row['cpu_need'], row['mem_need'],
                     row['disk_need'], row['link_condition'])
        tasks.append(task)

    return tasks


def update_link_condition(tasks_list, threshold, increase_percent):
    excess_tasks = len(tasks_list) - threshold
    if excess_tasks > 0:
        for i in range(excess_tasks):
            task = tasks_list[threshold + i]
            factor = excess_tasks / threshold
            if factor < 1:
                task.link_condition *= (1 + increase_percent / 100)
            elif factor < 2:
                task.link_condition *= (1 + 2 * increase_percent / 100)
            else:
                task.link_condition *= (1 + 3 * increase_percent / 100)


def save_tasks_to_csv(tasks, filename):
    df = pd.DataFrame([task.to_dict() for task in tasks])
    # df.to_csv(filename, index=False)
    df.to_excel(filename, index=False)


def read_tasks_from_json(filename):
    with open(filename, 'r') as file:
        tasks_data = json.load(file)
    tasks = []
    for node_id, algorithms in tasks_data.items():
        for algorithm, tasks_list in algorithms.items():
            for task_data in tasks_list:
                task = Task(task_data['sid'], node_id, algorithm, task_data['rs_delay'],
                            task_data['rs_max_tolerance_latency'],
                            task_data['delay_level'], task_data['rate_level'], task_data['cpu_need'],
                            task_data['mem_need'],
                            task_data['processing_time'],
                            task_data['link_condition']
                            )
                tasks.append(task)
    return tasks


def process_task_timings_by_node(task_timings_file, node_id):
    with open(task_timings_file, 'r') as file:
        task_timings_data = json.load(file)

    algorithms = task_timings_data.get(node_id, {})
    if not algorithms:
        print(f"No data found for node {node_id}")
        return {}, {}

    # 初始化字典存储任务满意率和平均延时率
    satisfaction_rates = {}
    average_delay_rates = {}
    latency_improvement_rates = {}
    algorithm_task_data = {}
    # 遍历算法
    for algorithm, tasks in algorithms.items():

        # 初始化成功任务个数和延时率总和
        success_count = 0
        delay_rate_sum = 0
        total_tasks = len([item for sublist in tasks for item in sublist])
        latency_improvement_sum = 0
        total_failed_tasks = 0
        task_data = []
        print(f"Processing {total_tasks} tasks for algorithm {algorithm} on node {node_id}")
        for task_id, task_info in tasks.items():

            # 找到最小的start_time
            min_start_time = min(task["start_time"] for task in task_info)

            # 计算processing_time
            for task in task_info:
                processing_time = (task["end_time"] - min_start_time) * 100
                print('processing_time', processing_time)
                print('task["max_latency"]', task["max_latency"])
                # 根据processing_time和max_latency判断任务状态
                if processing_time <= task["max_latency"]:
                    task["status"] = 1  # 标记任务成功
                    success_count += 1
                    latency_improvement = (task["max_latency"] - processing_time) / processing_time
                    task["latency_improvement"] = latency_improvement  # 记录时延提升率
                    latency_improvement_sum += latency_improvement
                else:
                    delay_rate = (processing_time - task["max_latency"]) / task["max_latency"]
                    print('delay_rate', delay_rate)
                    task["delay_rate"] = delay_rate  # 记录延时率
                    delay_rate_sum += delay_rate
                    total_failed_tasks += 1
                task_data.append({
                    "sid": task_id,
                    "status": task.get("status", 0),
                    "delay_rate": task.get("delay_rate", None),
                    "latency_improvement": task.get("latency_improvement", None)
                })
                # 打印任务处理值
                print(
                    f"Task ID: {task_id}, Processing Time: {processing_time}, Delay Rate: {task.get('delay_rate', 'N/A')}, Latency Improvement: {task.get('latency_improvement', 'N/A')}")

        # 计算任务满意率和平均延时率
        print('count', success_count)
        satisfaction_rate = success_count / (success_count + total_failed_tasks) if (
                                                                                            success_count + total_failed_tasks) > 0 else 0
        average_delay_rate = delay_rate_sum / total_failed_tasks if total_failed_tasks > 0 else 0
        average_latency_improvement = latency_improvement_sum / success_count if success_count > 0 else 0
        # 存储任务满意率和平均延时率
        satisfaction_rates[algorithm] = satisfaction_rate
        average_delay_rates[algorithm] = average_delay_rate
        latency_improvement_rates[algorithm] = average_latency_improvement
        algorithm_task_data[algorithm] = task_data
    return satisfaction_rates, average_delay_rates, latency_improvement_rates, algorithm_task_data


# 使用tabulate库打印表格
# print("任务满意率:")
# print(tabulate(satisfaction_rates.items(), headers=["Algorithm", "Satisfaction Rate"], tablefmt="grid"))
# print()
#
# print("平均延时率:")
# print(tabulate(average_delay_rates.items(), headers=["Algorithm", "Average Delay Rate"], tablefmt="grid"))
# print()
#
# print("平均时延提升率:")
# print(tabulate(latency_improvement_rates.items(), headers=["Algorithm", "Average Latency Improvement Rate"],
#                tablefmt="grid"))
# print()
# for algorithm, tasks in algorithm_task_data.items():
#     print(f"任务数据 for Algorithm {algorithm}:")
#     print(tabulate(tasks, headers="keys", tablefmt="grid"))
#     print()
def process_task_timings(task_timings_file):
    with open(task_timings_file, 'r') as file:
        task_timings_data = json.load(file)

    # 初始化字典存储任务满意率、平均延时率和时延提升率
    satisfaction_rates = {}
    average_delay_rates = {}
    latency_improvement_rates = {}
    algorithm_task_data = {}

    # 遍历节点
    for node_id, algorithms in task_timings_data.items():
        satisfaction_rates[node_id] = {}
        average_delay_rates[node_id] = {}
        latency_improvement_rates[node_id] = {}
        algorithm_task_data[node_id] = {}

        # 遍历算法
        for algorithm, tasks in algorithms.items():

            # 初始化成功任务个数和延时率总和
            success_count = 0
            delay_rate_sum = 0
            total_tasks = len([item for sublist in tasks.values() for item in sublist])
            latency_improvement_sum = 0
            total_failed_tasks = 0
            task_data = []

            print(f"Processing {total_tasks} tasks for algorithm {algorithm} on node {node_id}")

            for task_id, task_info in tasks.items():

                # 找到最小的start_time
                min_start_time = min(task["start_time"] for task in task_info)

                # 计算processing_time
                for task in task_info:
                    processing_time = (task["end_time"] - min_start_time) * 100

                    # 根据processing_time和max_latency判断任务状态
                    if processing_time <= task["max_latency"]:
                        task["status"] = 1  # 标记任务成功
                        success_count += 1
                        latency_improvement = (task["max_latency"] - processing_time) / processing_time
                        task["latency_improvement"] = latency_improvement  # 记录时延提升率
                        latency_improvement_sum += latency_improvement
                    else:
                        delay_rate = (processing_time - task["max_latency"]) / task["max_latency"]
                        task["delay_rate"] = delay_rate  # 记录延时率
                        delay_rate_sum += delay_rate
                        total_failed_tasks += 1

                    task_data.append({
                        "sid": task_id,
                        "status": task.get("status", 0),
                        "delay_rate": task.get("delay_rate", None),
                        "latency_improvement": task.get("latency_improvement", None)
                    })

                    # 打印任务处理值
                    print(
                        f"Task ID: {task_id}, Status:{task.get('status', 0)},Processing Time: {processing_time}, Delay Rate: {task.get('delay_rate', 'N/A')}, Latency Improvement: {task.get('latency_improvement', 'N/A')}")

            # 计算任务满意率和平均延时率
            print('count', success_count)
            satisfaction_rate = success_count / (success_count + total_failed_tasks) if (
                                                                                                success_count + total_failed_tasks) > 0 else 0
            average_delay_rate = delay_rate_sum / total_failed_tasks if total_failed_tasks > 0 else 0
            average_latency_improvement = latency_improvement_sum / success_count if success_count > 0 else 0

            # 存储任务满意率和平均延时率
            satisfaction_rates[node_id][algorithm] = satisfaction_rate
            average_delay_rates[node_id][algorithm] = average_delay_rate
            latency_improvement_rates[node_id][algorithm] = average_latency_improvement
            algorithm_task_data[node_id][algorithm] = task_data

    return satisfaction_rates, average_delay_rates, latency_improvement_rates, algorithm_task_data


# task_timings_file = 'task_timings.json'
#
# satisfaction_rates, average_delay_rates, latency_improvement_rates, algorithm_task_data = process_task_timings(
#     task_timings_file)
#
# # 使用tabulate库打印表格
# print("任务满意率:")
# for node_id, node_data in satisfaction_rates.items():
#     print(f"Node {node_id}:")
#     print(tabulate(node_data.items(), headers=["Algorithm", "Satisfaction Rate"], tablefmt="grid"))
#     print()
#
# print("平均延时率:")
# for node_id, node_data in average_delay_rates.items():
#     print(f"Node {node_id}:")
#     print(tabulate(node_data.items(), headers=["Algorithm", "Average Delay Rate"], tablefmt="grid"))
#     print()
#
# print("平均时延提升率:")
# for node_id, node_data in latency_improvement_rates.items():
#     print(f"Node {node_id}:")
#     print(tabulate(node_data.items(), headers=["Algorithm", "Average Latency Improvement Rate"], tablefmt="grid"))
#     print()
#
# for node_id, node_data in algorithm_task_data.items():
#     for algorithm, tasks in node_data.items():
#         print(f"任务数据 for Algorithm {algorithm} on Node {node_id}:")
#         print(tabulate(tasks, headers="keys", tablefmt="grid"))
#         print()


def process_task_timings_all_by_alg(task_timings_file):
    with open(task_timings_file, 'r') as file:
        task_timings_data = json.load(file)

    # 初始化字典存储任务状态和时延数据
    algorithm_stats_by_node = {}
    algorithm_stats = {}
    # 遍历节点
    for node_id, algo_data in task_timings_data.items():
        for algo, tasks in algo_data.items():
            print(tasks)
            if algo not in algorithm_stats_by_node:
                algorithm_stats_by_node[algo] = {}
            if node_id not in algorithm_stats_by_node[algo]:
                algorithm_stats_by_node[algo][node_id] = {"total_tasks": len(tasks),
                                                          "success_count": 0,
                                                          "delay_count": 0,
                                                          "delay_sum": 0,
                                                          "improvement_sum": 0}
            # for task_info in tasks:
            #
            #     print(task_info["start_time"])
            min_start_time = min(task.get("start_time") for task in tasks)

            print(f"algo {algo} node_id {node_id} min start_time is {min_start_time} ")
            # 计算processing_time
            for task_info in tasks:
                all_time = (task_info["start_time"] - min_start_time) * 1000 + task_info["p_time"]
                # 根据processing_time和max_latency判断任务状态
                if all_time <= task_info["max_latency"]:
                    algorithm_stats_by_node[algo][node_id]["success_count"] += 1
                else:
                    algorithm_stats_by_node[algo][node_id]["delay_count"] += 1

    # 计算每个算法的任务成功率、平均延时率和平均提升率
    for algorithm, node_stats_data in algorithm_stats_by_node.items():
        if algorithm not in algorithm_stats:
            algorithm_stats[algorithm] = {"total_tasks": 0, "success_count": 0,
                                          "delay_count": 0, "delay_sum": 0,
                                          "improvement_sum": 0}

        for node_id, stats in node_stats_data.items():
            algorithm_stats[algorithm]["total_tasks"] += stats["total_tasks"]
            algorithm_stats[algorithm]["success_count"] += stats["success_count"]
            algorithm_stats[algorithm]["delay_count"] += stats["delay_count"]
            algorithm_stats[algorithm]["delay_sum"] += stats["delay_sum"]
            algorithm_stats[algorithm]["improvement_sum"] += stats["improvement_sum"]

    # 计算成功率、延时率和提升率
    for algorithm, stats in algorithm_stats.items():
        total_tasks = stats["total_tasks"]
        success_count = stats["success_count"]
        delay_count = stats["delay_count"]
        delay_sum = stats["delay_sum"]
        improvement_sum = stats["improvement_sum"]

        algorithm_stats[algorithm]["success_rate"] = success_count / total_tasks if total_tasks > 0 else 0
        algorithm_stats[algorithm]["avg_delay_rate"] = delay_sum / delay_count if delay_count > 0 else 0
        algorithm_stats[algorithm]["avg_improvement_rate"] = improvement_sum / total_tasks if total_tasks > 0 else 0

    # 打印或返回算法统计信息
    for algorithm, stats in algorithm_stats.items():
        print(f"算法 {algorithm} 统计信息: {stats}")

    return algorithm_stats


# # 文件路径
# task_timings_file = 'task_timings.json'
#
# algorithm_stats = process_task_timings_all_by_alg(task_timings_file)
#
# # 打印每个算法的任务成功率、平均延时率和平均提升率
# for algorithm, stats in algorithm_stats.items():
#     print(f"算法: {algorithm}")
#     print(f"任务满意率: {stats['success_rate']:.3%}")
#     print(f"平均延时率: {stats['average_delay_rate']:.3%}")
#     print(f"平均提升率: {stats['average_improvement_rate']:.3%}")
#     print()
def process_task_timings_all_by_node(task_timings_file, node_id):
    with open(task_timings_file, 'r') as file:
        task_timings_data = json.load(file)

    # 初始化字典存储任务状态和时延数据
    algorithm_stats = {}

    algorithms = task_timings_data.get(node_id, {})
    if not algorithms:
        print(f"No data found for node {node_id}")
        return {}

    # 遍历算法
    for algorithm, tasks in algorithms.items():
        if algorithm not in algorithm_stats:
            algorithm_stats[algorithm] = {"total_tasks": 0, "success_count": 0, "failed_count": 0, "delay_sum": 0,
                                          "improvement_sum": 0}

        for task_id, task_info in tasks.items():
            # 找到最小的start_time
            min_start_time = min(task["start_time"] for task in task_info)

            # 计算processing_time
            for task in task_info:
                processing_time = (task["end_time"] - min_start_time) * 100

                # 根据processing_time和max_latency判断任务状态
                if processing_time <= task["max_latency"]:
                    algorithm_stats[algorithm]["success_count"] += 1
                    algorithm_stats[algorithm]["improvement_sum"] += (task[
                                                                          "max_latency"] - processing_time) / processing_time
                else:
                    algorithm_stats[algorithm]["delay_sum"] += (processing_time - task["max_latency"]) / task[
                        "max_latency"]
                    algorithm_stats[algorithm]["failed_count"] += 1
                algorithm_stats[algorithm]["total_tasks"] += 1

    # 计算每个算法的任务成功率、平均延时率和平均提升率
    for algorithm, stats in algorithm_stats.items():
        total_tasks = stats["total_tasks"]
        success_count = stats["success_count"]
        failed_count = stats["failed_count"]
        delay_sum = stats["delay_sum"]
        improvement_sum = stats["improvement_sum"]

        success_rate = success_count / total_tasks if total_tasks > 0 else 0
        average_delay_rate = delay_sum / failed_count if failed_count > 0 else 0
        average_improvement_rate = improvement_sum / success_count if success_count > 0 else 0

        algorithm_stats[algorithm]["success_rate"] = success_rate
        algorithm_stats[algorithm]["average_delay_rate"] = average_delay_rate
        algorithm_stats[algorithm]["average_improvement_rate"] = average_improvement_rate

    return algorithm_stats


# # 文件路径
# task_timings_file = 'task_timings.json'
# node_id_to_process = "h9"  # 指定要处理的节点
#
# algorithm_stats = process_task_timings(task_timings_file, node_id_to_process)
#
# # 打印每个算法的任务成功率、平均延时率和平均提升率
# for algorithm, stats in algorithm_stats.items():
#     print(f"算法: {algorithm}")
#     print(f"任务满意率: {stats['success_rate']:.3%}")
#     print(f"平均延时率: {stats['average_delay_rate']:.3%}")
#     print(f"平均提升率: {stats['average_improvement_rate']:.3%}")
#     print()


def entropy_to_bwm(entropy_weights):
    """
    将熵权值转换为BWM值，分别映射成1-9和9-1的整数范围。

    参数:
    entropy_weights (numpy.ndarray): 熵权值数组

    返回:
    tuple: 包含两个numpy.ndarray, 分别表示两种映射结果 '1_to_9' 和 '9_to_1'
    """
    sorted_indices = np.argsort(entropy_weights)
    inverse_sorted_indices = np.argsort(-entropy_weights)

    ranked_weights_1_to_9 = np.zeros_like(entropy_weights, dtype=int)
    ranked_weights_9_to_1 = np.zeros_like(entropy_weights, dtype=int)

    ranked_weights_1_to_9[sorted_indices] = np.arange(1, len(entropy_weights) + 1)
    ranked_weights_9_to_1[inverse_sorted_indices] = np.arange(1, len(entropy_weights) + 1)

    return ranked_weights_1_to_9, ranked_weights_9_to_1

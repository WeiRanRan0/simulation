import pandas as pd
import matplotlib.pyplot as plt


def extract_balance_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algorithm'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['zero_ratio'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


def extract_success_rate_values(file_list):
    topsis_values = []
    for file in file_list:
        df = pd.read_csv(file)
        topsis_row = df[df['algo'] == 'topsis']
        if not topsis_row.empty:
            zero_ratio = topsis_row['success_rate'].values[0]
            topsis_values.append(zero_ratio)
    return topsis_values


# 数字列表
rst_num = [10, 20, 50, 100, 150]

# 创建两组文件名列表，使用 f-string 匹配数字部分
balance_list_cfn = [f"./final_result/avg_balance_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
balance_list_com = [f"./final_result/avg_balance_results_with_com22_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn_dy = [f"./final_result/success_rate_dy_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com_dy = [f"./final_result/success_rate_dy_results_with_com22_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_cfn = [f"./final_result/success_rate_sta_results_with_cfn_en_{n}_{n}_{n}.csv" for n in rst_num]
success_list_com = [f"./final_result/success_rate_sta_results_with_com22_en_{n}_{n}_{n}.csv" for n in rst_num]
# 提取两组文件的topsis行的zero_ratio值
balance_cfn = extract_balance_values(balance_list_cfn)
balance_com = extract_balance_values(balance_list_com)
success_cfn_dy = extract_success_rate_values(success_list_cfn_dy)
success_com_dy = extract_success_rate_values(success_list_com_dy)
success_cfn = extract_success_rate_values(success_list_cfn)
success_com = extract_success_rate_values(success_list_com)

fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# 平衡值可视化
axes[0].plot(rst_num, balance_cfn, marker='o', label='CFN')
for i, txt in enumerate(balance_cfn):
    axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[0].plot(rst_num, balance_com, marker='o', label='COM')
for i, txt in enumerate(balance_com):
    axes[0].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[0].set_title('Balance Values')
axes[0].set_xlabel('Number of Requests')
axes[0].set_ylabel('Balance Value')
axes[0].set_xticks(rst_num)  # 设置X轴刻度为指定的值
axes[0].legend()
axes[0].grid(True)

# 动态成功率可视化
axes[1].plot(rst_num, success_cfn_dy, marker='o', label='CFN Dynamic')
for i, txt in enumerate(success_cfn_dy):
    axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[1].plot(rst_num, success_com_dy, marker='o', label='COM Dynamic')
for i, txt in enumerate(success_com_dy):
    axes[1].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[1].set_title('Success Rate (Dynamic)')
axes[1].set_xlabel('Number of Requests')
axes[1].set_ylabel('Success Rate')
axes[1].set_xticks(rst_num)  # 设置X轴刻度为指定的值
axes[1].legend()
axes[1].grid(True)

# 静态成功率可视化
axes[2].plot(rst_num, success_cfn, marker='o', label='CFN Static')
for i, txt in enumerate(success_cfn):
    axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[2].plot(rst_num, success_com, marker='o', label='COM Static')
for i, txt in enumerate(success_com):
    axes[2].text(rst_num[i], txt, f'{txt:.2f}', ha='center', va='bottom')
axes[2].set_title('Success Rate (Static)')
axes[2].set_xlabel('Number of Requests')
axes[2].set_ylabel('Success Rate')
axes[2].set_xticks(rst_num)  # 设置X轴刻度为指定的值
axes[2].legend()
axes[2].grid(True)

plt.tight_layout()
plt.show()
import json
import os

from Parameter import Large_num, Medium_num, Edge_num, large_service_num, medium_service_num, edge_service_num
import random

file_p = './service_num_per_datacenter'
if not os.path.exists(file_p):
    os.makedirs(file_p)


def create_requests_dict_random(large_val, medium_val, edge_val, num_large, num_medium, num_edge):
    range_offset = 10  # Define the range offset around the specific value
    requests_dict = {}

    for i in range(1, num_large + 1):
        requests_dict[f"Large{i}"] = random.randint(large_val - range_offset, large_val + range_offset)

    for i in range(1, num_medium + 1):
        requests_dict[f"Medium{i}"] = random.randint(medium_val - range_offset, medium_val + range_offset)

    for i in range(1, num_edge + 1):
        requests_dict[f"Edge{i}"] = random.randint(edge_val - range_offset, edge_val + range_offset)

    return requests_dict


# Generate dictionary with default values
num_requests_dict = create_requests_dict_random(large_service_num, medium_service_num, edge_service_num, Large_num,
                                                Medium_num, Edge_num)

# Save the generated dictionary as a JSON file
json_file_path = os.path.join(file_p,
                              f'num_service_per_datacenter_{large_service_num}_{medium_service_num}_{edge_service_num}.json')

# Save the generated dictionary as a JSON file
with open(json_file_path, 'w') as json_file:
    json.dump(num_requests_dict, json_file, indent=4)

print("num_requests_dict has been saved to 'num_request_per_datacenter.json'")

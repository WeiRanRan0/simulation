import os

py_files_no_scheduler = [
                         'match_with_cfn.py',
                         # 'match_with_delay_complicated22.py',
                         'satisfaction_rate_cfn.py',
                         # 'satisfaction_rate_com22.py',
                         'resource_analy_with_cfn.py',
                         # 'resource_analy_with_delay_domain_complicated22.py',
                         'satisfaction_rate_cfn_with_resource.py',
                         # 'satisfaction_rate_com22_with_resource.py',
                         'balance_analy_cfn.py'
                         # 'balance_analy_com22.py'
                         ]

num = 10
algo = 'en'
for i in range(num):
    for py_file in py_files_no_scheduler:
        os.system(f"python {py_file} {algo} {i}")


import pandas as pd
from Parameter import *

service_info_df = pd.read_csv(f'merged_data_{SERVICE_RECORD_NUM}.csv')
network_delay_in_domain = pd.read_csv('node_delays_and_domains.csv')
all_merged_data = pd.DataFrame()
for i in range(NETWORK_NODE_NUM):
    for index, row in service_info_df.iterrows():
        delay_result = network_delay_in_domain[(network_delay_in_domain['other_node'] == row['network_node']) &
                                               (network_delay_in_domain['local_node'] == i)
                                               ]['Delay'].values
        merged_df = pd.DataFrame(row).T
        merged_df['local_node'] = i
        merged_df['link_condition'] = delay_result
        all_merged_data = pd.concat([all_merged_data, merged_df])

all_merged_data.to_csv(f'info_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
all_merged_data.to_excel(f'info_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)

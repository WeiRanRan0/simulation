# # import os
# # import pandas as pd
# #
# # # server_event = pd.read_csv('server_event.csv', header=None)
# # # server_usage = pd.read_excel('server_usage_ori.xlsx')
# # #
# # # # print(server_usage.head(10))
# # # # print(server_event.head(10))
# # #
# # # server_usage[2] = 100 - server_usage[2]
# # # server_usage[3] = 100 - server_usage[3]
# # # server_usage[4] = 100 - server_usage[4]
# # #
# # # node_ids = server_usage[1].unique()
# # # result_df = pd.DataFrame(columns=server_usage.columns)
# # #
# # # for node_id in node_ids:
# # #     # 获取该节点的所有记录
# # #     node_records = server_usage[server_usage[1] == node_id]
# # #
# # #     # 从中随机选取一个值作为代表值
# # #     selected_record = node_records.sample(n=1)
# # #
# # #     # 将选取的记录添加到结果DataFrame中
# # #     result_df = pd.concat([result_df, selected_record], ignore_index=True)
# # #
# # # # 打印最终结果
# # # # print("Result DataFrame:")
# # # # print(result_df.head(10))
# # #
# # # # 如果需要，将结果写回CSV文件
# # # result_df.to_csv('server_usage.csv', header=False, index=False)
# # # result_df.to_excel('server_usage.xlsx', header=False, index=False)
# # # server_usage.to_excel('server_usage_sub.xlsx')
# # # print(server_usage.head(10))
# # # df = pd.read_csv('container_event.csv')
# # # print(df.head(10))
# # import pandas as pd
# # import glob
# # from Parameter import large_request_num, medium_request_num, edge_request_num
# # import matplotlib.pyplot as plt
# # import numpy as np
# #
# # pd.set_option('display.max_rows', None)
# # pd.set_option('display.max_columns', None)
# # pd.set_option('display.max_colwidth', 500)
# # pd.set_option('display.expand_frame_repr', False)
# #
# #
# # def process_files_and_save(file_pattern, output_file):
# #     # 存储所有数据的列表
# #     all_data = []
# #
# #     # 使用glob模块匹配指定文件名模式的文件
# #     for file_name in glob.glob(file_pattern):
# #         data = pd.read_csv(file_name, index_col=False)
# #         all_data.append(data)
# #
# #     # 检查是否找到了匹配的文件
# #     if all_data:
# #         # 合并所有数据
# #         combined_data = pd.concat(all_data, ignore_index=True)
# #         avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
# #         avg_success_rate_by_algo.to_csv(output_file, index=False)
# #         print(f"结果已保存至 {output_file}")
# #         return combined_data, avg_success_rate_by_algo
# #     else:
# #         print("未找到匹配的文件。")
# #
# #
# # def process_balance_files_and_save(file_pattern, output_file):
# #     # 存储所有数据的列表
# #     all_data = []
# #
# #     # 使用glob模块匹配指定文件名模式的文件
# #     for file_name in glob.glob(file_pattern):
# #         data = pd.read_csv(file_name, index_col=False)
# #         all_data.append(data)
# #
# #     # 检查是否找到了匹配的文件
# #     if all_data:
# #         # 合并所有数据
# #         combined_data = pd.concat(all_data, ignore_index=True)
# #
# #         avg_success_rate_by_algo = combined_data.groupby('algorithm')['zero_ratio'].mean().reset_index()
# #         avg_success_rate_by_algo.to_csv(output_file, index=False)
# #         print(f"结果已保存至 {output_file}")
# #         return combined_data, avg_success_rate_by_algo
# #     else:
# #         print("未找到匹配的文件。")
# #
# #
# # print(
# #     '^^^^^^^^^静态成功率可视化**********************************************************************************************')
# # print()
# # folder_from = './successrate'  # 替换为实际的文件夹路径
# # folder_to = './algo_final_result'
# # algo_list = ['en', 'my_bwm', 'enbwm', 'en_and_my', 'mix_bwm']
# # algo_cfn = 'en'
# # file_com_en = f'{folder_from}/results_analysis_with_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_en = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# # file_com_my_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_my_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# # file_com_enbwm = f'{folder_from}/results_analysis_with_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_enbwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实
# # file_com_en_and_my = f'{folder_from}/results_analysis_with_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_en_and_my = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实
# # file_com_mix_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_mix_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实
# # file_cfn = f'{folder_from}/results_analysis_with_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # output_cfn = f'{folder_to}/success_rate_sta_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# #
# # com_en, com_en_avg_df = process_files_and_save(file_com_en, output_com_en)
# # com_my_bwm, com_my_bwm_avg_df = process_files_and_save(file_com_my_bwm, output_com_my_bwm)
# # com_enbwm, com_enbwm_avg_df = process_files_and_save(file_com_enbwm, output_com_enbwm)
# # com_en_and_my, com_en_and_my_avg_df = process_files_and_save(file_com_en_and_my, output_com_en_and_my)
# # com_mix_bwm, com_mix_bwm_avg_df = process_files_and_save(file_com_mix_bwm, output_com_mix_bwm)
# # cfn, cfn_avg_df = process_files_and_save(file_cfn, output_cfn)
# #
# # algo_to_plot = 'topsis'
# # com_en_avg = com_en_avg_df.loc[com_en_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_my_bwm_avg = com_my_bwm_avg_df.loc[com_my_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_enbwm_avg = com_enbwm_avg_df.loc[com_enbwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_en_and_my_avg = com_en_and_my_avg_df.loc[com_en_and_my_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_mix_bwm_avg = com_mix_bwm_avg_df.loc[com_mix_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # cfn_avg = cfn_avg_df.loc[cfn_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # # 合并数据
# # merged = pd.concat([com_en, com_my_bwm, com_enbwm, com_en_and_my, com_mix_bwm, cfn], axis=1)
# # merged.columns = ['algo', 'success_rate_com_en', 'algo', 'success_rate_com_my_bwm', 'algo', 'success_rate_com_enbwm',
# #                   'algo', 'success_rate_com_en_and_my', 'algo', 'success_rate_com_mix_bwm', 'algo', 'success_rate_cfn']
# # merged_new = merged.loc[:, ~merged.columns.duplicated()]
# # # print(merged_new.head(10))
# # # 按算法分组
# # merged_g = merged_new.groupby('algo')
# # # print(merged_g.head(10))
# #
# # # 获取对应算法的数据
# # data_to_plot = merged_g.get_group(algo_to_plot)
# # fig, axes = plt.subplots(3, 1, figsize=(10, 12))
# # # 绘制折线图
# # # plt.figure(figsize=(10, 6))
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'],
# #              label=f'{algo_to_plot} - en', color='blue')
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'],
# #              label=f'{algo_to_plot} - my_bwm', color='orange')
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'],
# #              label=f'{algo_to_plot} - enbwm', color='green')
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'],
# #              label=f'{algo_to_plot} - en_and_my', color='black')
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'],
# #              label=f'{algo_to_plot} - mix_bwm', color='purple')
# # axes[0].plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'],
# #              label=f'{algo_to_plot} - CFN_en', linestyle=':', color='red')
# # # 在每个数据点上标出数据
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'], color='blue')
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'], color='orange')
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'], color='green')
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'], color='black')
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'], color='purple')
# # axes[0].scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'], color='red')
# # # 在图例中标出平均值（通过不可见点）
# # axes[0].scatter([], [], color='blue', label=f'Average EN: {com_en_avg:.2f}')
# # axes[0].scatter([], [], color='orange', label=f'Average Mybwm: {com_my_bwm_avg:.2f}')
# # axes[0].scatter([], [], color='green', label=f'Average Enbwm: {com_enbwm_avg:.2f}')
# # axes[0].scatter([], [], color='black', label=f'Average En_and_my: {com_en_and_my_avg:.2f}')
# # axes[0].scatter([], [], color='purple', label=f'Average Mix_bwm: {com_mix_bwm_avg:.2f}')
# # axes[0].scatter([], [], color='red', label=f'Average CFN: {cfn_avg:.2f}')
# # axes[0].set_xlabel('Number of Iterations', fontsize=6)
# #
# # # 设置y轴标签
# # axes[0].set_ylabel('Success Rate', fontsize=6)
# #
# # # 设置标题
# # axes[0].set_title(f'Success Rates for {algo_to_plot} Algorithm and Different Weight Type', fontsize=6)
# # axes[0].legend(loc='lower left', prop={'size': 3}, ncol=2, bbox_to_anchor=(0, 0))
# # axes[0].tick_params(axis='x', labelsize=6)  # 设置横坐标刻度字体大小为10
# #
# # # 调整纵坐标刻度的字体大小
# # axes[0].tick_params(axis='y', labelsize=6)
# # axes[0].grid(True)
# # # plt.show()
# #
# # print(
# #     '^^^^^^^^^动态成功率可视化**********************************************************************************************')
# # print()
# #
# # file_com_en_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_en_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # file_com_my_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_my_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # file_com_enbwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_enbwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # file_com_en_and_my_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_en_and_my_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # file_com_mix_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# # output_com_mix_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # file_cfn_dy = f'{folder_from}/task_success_rates_per_algo_with_res_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # output_cfn_dy = f'{folder_to}/success_rate_dy_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# #
# # algo_to_plot = 'topsis'
# #
# # com_en_dy, com_en_dy_avg_df = process_files_and_save(file_com_en_dy, output_com_en_dy)
# # com_my_bwm_dy, com_my_bwm_dy_avg_df = process_files_and_save(file_com_my_bwm_dy, output_com_my_bwm_dy)
# # com_enbwm_dy, com_enbwm_dy_avg_df = process_files_and_save(file_com_enbwm_dy, output_com_enbwm_dy)
# # com_en_and_my_dy, com_en_and_my_dy_avg_df = process_files_and_save(file_com_en_and_my_dy, output_com_en_and_my_dy)
# # com_mix_bwm_dy, com_mix_bwm_dy_avg_df = process_files_and_save(file_com_mix_bwm_dy, output_com_mix_bwm_dy)
# # cfn_dy, cfn_dy_avg_df = process_files_and_save(file_cfn_dy, output_cfn_dy)
# #
# # com_en_dy_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_my_bwm_dy_avg = com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_enbwm_dy_avg = com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_en_and_my_dy_avg = \
# #     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # com_mix_bwm_dy_avg = com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # cfn_dy_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# #
# # # 合并数据
# # merged_dy = pd.concat([com_en_dy, com_my_bwm_dy, com_enbwm_dy, com_en_and_my_dy, com_mix_bwm_dy, cfn_dy], axis=1)
# # merged_dy.columns = ['algo', 'success_rate_com_en_dy', 'algo', 'success_rate_com_my_bwm_dy', 'algo',
# #                      'success_rate_com_enbwm_dy', 'algo', 'success_rate_com_en_and_my_dy', 'algo',
# #                      'success_rate_com_mix_bwm_dy', 'algo', 'success_rate_cfn_en_dy']
# # merged_dy_new = merged_dy.loc[:, ~merged_dy.columns.duplicated()]
# #
# # # 按算法分组
# # merged_dy_g = merged_dy_new.groupby('algo')
# #
# # # 获取对应算法的数据
# # data_to_plot_dy = merged_dy_g.get_group(algo_to_plot)
# #
# # # 绘制折线图
# # # plt.figure(figsize=(10, 6))
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_en_dy'],
# #              label=f'{algo_to_plot} - com_en', color='blue')
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_my_bwm_dy'],
# #              label=f'{algo_to_plot} - com_my_bwm', color='orange')
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_enbwm_dy'],
# #              label=f'{algo_to_plot} - com_enbwm', color='green')
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_en_and_my_dy'],
# #              label=f'{algo_to_plot} - com_en_and_my', color='black')
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_mix_bwm_dy'],
# #              label=f'{algo_to_plot} - com_mix_bwm', color='purple')
# # axes[1].plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_cfn_en_dy'],
# #              label=f'{algo_to_plot} - cfn_en', linestyle=':', color='red')
# #
# # # 在每个数据点上标出数据
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_en_dy'], color='blue')
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_my_bwm_dy'], color='orange')
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_enbwm_dy'], color='green')
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_en_and_my_dy'], color='black')
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_mix_bwm_dy'], color='purple')
# # axes[1].scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_cfn_en_dy'], color='red')
# # # 在图例中标出平均值（通过不可见点）
# # axes[1].scatter([], [], color='blue', label=f'Average com_en: {com_en_dy_avg:.2f}')
# # axes[1].scatter([], [], color='orange', label=f'Average com_my_bwm: {com_my_bwm_dy_avg:.2f}')
# # axes[1].scatter([], [], color='green', label=f'Average com_enbwm: {com_enbwm_dy_avg:.2f}')
# # axes[1].scatter([], [], color='black', label=f'Average com_en_and_my: {com_en_and_my_dy_avg:.2f}')
# # axes[1].scatter([], [], color='purple', label=f'Average com_mix_bwm: {com_mix_bwm_dy_avg:.2f}')
# # axes[1].scatter([], [], color='red', label=f'Average cfn_en: {cfn_dy_avg:.2f}')
# #
# # axes[1].set_xlabel('Number of Iterations', fontsize=6)
# # axes[1].set_ylabel('Success Rate', fontsize=6)
# # axes[1].set_title(f'Dynamic Success Rates for {algo_to_plot} Algorithm and Different Weight Type', fontsize=6)
# # axes[1].legend(loc='lower left', prop={'size': 3}, ncol=2, bbox_to_anchor=(0, 0))
# # axes[1].tick_params(axis='x', labelsize=6)  # 设置横坐标刻度字体大小为10
# #
# # # 调整纵坐标刻度的字体大小
# # axes[1].tick_params(axis='y', labelsize=6)
# # axes[1].grid(True)
# # # plt.show()
# #
# # print(
# #     '^^^^^^^^^资源均衡率可视化**********************************************************************************************')
# # print()
# # balance_folder = './balance'
# #
# # com_en_balance = f'{balance_folder}/balance_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_com_en_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # com_my_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_com_my_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # com_enbwm_balance = f'{balance_folder}/balance_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_com_enbwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # com_en_and_my_balance = f'{balance_folder}/balance_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_com_en_and_my_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # com_mix_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_com_mix_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# # cfn_balance = f'{balance_folder}/balance_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# # output_cfn_balance = f'{folder_to}/avg_balance_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# #
# # com_en_ba, com_en_ba_avg_df = process_balance_files_and_save(com_en_balance, output_com_en_balance)
# # com_my_bwm_ba, com_my_bwm_ba_avg_df = process_balance_files_and_save(com_my_bwm_balance, output_com_my_bwm_balance)
# # com_enbwm_ba, com_enbwm_ba_avg_df = process_balance_files_and_save(com_enbwm_balance, output_com_enbwm_balance)
# # com_en_and_my_ba, com_en_and_my_ba_avg_df = process_balance_files_and_save(com_en_and_my_balance,
# #                                                                            output_com_en_and_my_balance)
# # com_mix_bwm_ba, com_mix_bwm_ba_avg_df = process_balance_files_and_save(com_mix_bwm_balance, output_com_mix_bwm_balance)
# # cfn_ba, cfn_ba_avg_df = process_balance_files_and_save(cfn_balance, output_cfn_balance)
# #
# # com_en_ba_avg = com_en_ba_avg_df.loc[com_en_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# # com_my_bwm_ba_avg = com_my_bwm_ba_avg_df.loc[com_my_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# # com_enbwm_ba_avg = com_enbwm_ba_avg_df.loc[com_enbwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# # com_en_and_my_ba_avg = \
# #     com_en_and_my_ba_avg_df.loc[com_en_and_my_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# # com_mix_bwm_ba_avg = com_mix_bwm_ba_avg_df.loc[com_mix_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[
# #     0]
# # cfn_ba_avg = cfn_ba_avg_df.loc[cfn_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# #
# # # 合并数据
# # merged_ba = pd.concat([com_en_ba, com_my_bwm_ba, com_enbwm_ba, com_en_and_my_ba, com_mix_bwm_ba, cfn_ba], axis=1)
# # merged_ba.columns = ['algo', 'com_en_ba', 'algo', 'com_my_bwm_ba', 'algo', 'com_enbwm_ba', 'algo', 'com_en_and_my_ba',
# #                      'algo', 'com_mix_bwm_ba', 'algo', 'cfn_ba']
# # merged_ba_new = merged_ba.loc[:, ~merged_ba.columns.duplicated()]
# #
# # # 按算法分组
# # merged_ba_g = merged_ba_new.groupby('algo')
# #
# # # 选择要绘制的算法
# # algo_to_plot = 'topsis'
# #
# # # 获取对应算法的数据
# # data_to_plot_ba = merged_ba_g.get_group(algo_to_plot)
# #
# # # 绘制折线图
# # # plt.figure(figsize=(10, 6))
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'],
# #              label=f'{algo_to_plot} - COM_en', color='blue')
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'],
# #              label=f'{algo_to_plot} - COM_my_bwm', color='orange')
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'],
# #              label=f'{algo_to_plot} - COM_enbwm', color='green')
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'],
# #              label=f'{algo_to_plot} - COM_en_and_my', color='black')
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'],
# #              label=f'{algo_to_plot} - COM_mix_bwm', color='purple')
# #
# # axes[2].plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'],
# #              label=f'{algo_to_plot} - CFN', linestyle=':', color='red')
# #
# # # 在每个数据点上标出数据
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'], color='blue')
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'], color='orange')
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'], color='green')
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'], color='black')
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'], color='purple')
# # axes[2].scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='red')
# # axes[2].scatter([], [], color='blue', label=f'Average com_en: {com_en_ba_avg:.2f}')
# # axes[2].scatter([], [], color='orange', label=f'Average com_my_bwm: {com_my_bwm_ba_avg:.2f}')
# # axes[2].scatter([], [], color='green', label=f'Average com_enbwm: {com_enbwm_ba_avg:.2f}')
# # axes[2].scatter([], [], color='black', label=f'Average com_en_and_my: {com_en_and_my_ba_avg:.2f}')
# # axes[2].scatter([], [], color='purple', label=f'Average com_mix_bwm: {com_mix_bwm_ba_avg:.2f}')
# # axes[2].scatter([], [], color='red', label=f'Average cfn: {cfn_ba_avg:.2f}')
# #
# # # 设置x轴标签
# # axes[2].set_xlabel('Number of Iterations', fontsize=6)
# #
# # # 设置y轴标签
# # axes[2].set_ylabel('Balance Rate', fontsize=6)
# # axes[2].set_ylim(0.1, 1)
# # # 设置标题
# # axes[2].set_title(f'Balance Rates for {algo_to_plot} Algorithm and Different Weight Type', fontsize=6)
# #
# # # 显示图例
# # axes[2].legend(loc='lower left', prop={'size': 3}, ncol=2, bbox_to_anchor=(0, 0))
# # axes[2].tick_params(axis='x', labelsize=6)  # 设置横坐标刻度字体大小为10
# #
# # # 调整纵坐标刻度的字体大小
# # axes[2].tick_params(axis='y', labelsize=6)
# # # 显示网格
# # axes[2].grid(True)
# #
# # # 显示图形
# # plt.tight_layout()
# # plt.show()
# # #
# # # import numpy as np
# # # import matplotlib.pyplot as plt
# # #
# # # lam = 5  # 平均到达率
# # # arrival_times = np.random.poisson(lam, 1000)  # 生成1000个任务到达时间
# # #
# # # plt.hist(arrival_times, bins=range(max(arrival_times)+1), density=True, alpha=0.75)
# # # plt.xlabel('Arrival Time')
# # # plt.ylabel('Probability')
# # # plt.title('Poisson Arrival Process')
# # # plt.show()
# # import simpy
# # import random
# # import numpy as np
# #
# #
# # # 定义任务类
# # class Task:
# #     def __init__(self, id, cpu, mem, disk, delay_requirement, process_time):
# #         self.id = id
# #         self.cpu = cpu
# #         self.mem = mem
# #         self.disk = disk
# #         self.delay_requirement = delay_requirement
# #         self.process_time = process_time
# #
# #
# # # 定义服务器类
# # class Server:
# #     def __init__(self, env, cpu_capacity, mem_capacity, disk_capacity):
# #         self.env = env
# #         self.cpu_capacity = cpu_capacity
# #         self.mem_capacity = mem_capacity
# #         self.disk_capacity = disk_capacity
# #         self.cpu = simpy.Resource(env, capacity=cpu_capacity)
# #         self.mem = simpy.Resource(env, capacity=mem_capacity)
# #         self.disk = simpy.Resource(env, capacity=disk_capacity)
# #
# #     def can_process(self, task):
# #         return (self.cpu.count + task.cpu <= self.cpu.capacity and
# #                 self.mem.count + task.mem <= self.mem.capacity and
# #                 self.disk.count + task.disk <= self.disk.capacity)
# #
# #
# # # 任务处理过程
# # def process_task(env, task, server, results):
# #     arrival_time = env.now
# #     print(f"Task {task.id} arrived at {arrival_time:.2f}")
# #
# #     with server.cpu.request() as cpu_req, server.mem.request() as mem_req, server.disk.request() as disk_req:
# #         yield cpu_req
# #         yield mem_req
# #         yield disk_req
# #
# #         if server.can_process(task):
# #             queue_entry_time = env.now
# #             print(
# #                 f"Task {task.id} entered queue at {queue_entry_time:.2f}, wait time: {queue_entry_time - arrival_time:.2f}")
# #             yield env.timeout(task.process_time)  # 使用任务的处理时间
# #             completion_time = env.now
# #             delay = completion_time - arrival_time
# #             print(f"Task {task.id} processed at {completion_time:.2f}, total delay: {delay:.2f}")
# #
# #             # 记录结果
# #             results.append({
# #                 'task_id': task.id,
# #                 'arrival_time': arrival_time,
# #                 'completion_time': completion_time,
# #                 'delay': delay,
# #                 'delay_requirement': task.delay_requirement,
# #                 'met_delay_requirement': delay <= task.delay_requirement
# #             })
# #
# #
# # # 任务生成过程
# # def generate_tasks(env, server, task_list, arrival_rate, results):
# #     for i, task in enumerate(task_list):
# #         yield env.timeout(np.random.poisson(arrival_rate))
# #         env.process(process_task(env, task, server, results))
# #
# #
# # # 主函数
# # if __name__ == "__main__":
# #     env = simpy.Environment()
# #     server = Server(env, cpu_capacity=4, mem_capacity=16, disk_capacity=100)
# #
# #     # 生成任务列表
# #     task_list = [
# #         Task(
# #             id=i,
# #             cpu=random.randint(1, 2),
# #             mem=random.randint(1, 4),
# #             disk=random.randint(1, 10),
# #             delay_requirement=random.uniform(5, 15),
# #             process_time=random.uniform(1, 5)  # 随机处理时间
# #         ) for i in range(100)
# #     ]
# #
# #     # 任务到达率
# #     arrival_rate = 0.2
# #
# #     # 结果记录
# #     results = []
# #
# #     # 开始模拟
# #     env.process(generate_tasks(env, server, task_list, arrival_rate, results))
# #     env.run(until=100)
# #
# #     # 统计满足时延要求的任务比例
# #     met_delay_requirements = [result['met_delay_requirement'] for result in results]
# #     met_delay_ratio = sum(met_delay_requirements) / len(met_delay_requirements)
# #     print(f"Tasks met delay requirements: {met_delay_ratio * 100:.2f}%")
# import matplotlib.pyplot as plt
# import numpy as np
#
# # Data
# balance_cfn = [10, 20, 30, 40, 50]
# balance_cfn_my = [15, 25, 35, 45, 55]
# balance_com = [12, 22, 32, 42, 52]
# balance_com_my = [17, 27, 37, 47, 57]
# rst_num = [10, 30, 50, 100, 150]  # Non-equidistant values
# width = 0.2
#
# # Create equal spacing for x-coordinates
# x_labels = np.linspace(0, len(rst_num) - 1, len(rst_num))
#
# # Plot bars with new x-coordinates
# for i in range(len(balance_cfn)):
#     plt.bar(x_labels[i] - width, balance_cfn[i], width, color='b', alpha=0.5)
#     plt.bar(x_labels[i] + width, balance_cfn_my[i], width, color='b', alpha=0.8)
#     plt.bar(x_labels[i], balance_com[i], width, color='orange', alpha=0.5)
#     plt.bar(x_labels[i] + 2 * width, balance_com_my[i], width, color='orange', alpha=0.8)
#
# # Annotate bars with new x-coordinates
# for i, txt in enumerate(balance_cfn):
#     plt.text(x_labels[i] - width, txt, f'{txt:.2f}', ha='center', va='bottom')
# for i, txt in enumerate(balance_com):
#     plt.text(x_labels[i], txt, f'{txt:.2f}', ha='center', va='bottom')
# for i, txt in enumerate(balance_cfn_my):
#     plt.text(x_labels[i] + width, txt, f'{txt:.2f}', ha='center', va='bottom')
# for i, txt in enumerate(balance_com_my):
#     plt.text(x_labels[i] + 2 * width, txt, f'{txt:.2f}', ha='center', va='bottom')
#
# # Set x-ticks with original non-equidistant values
# plt.xticks(x_labels, rst_num)
# plt.xlabel('Request Number')
# plt.ylabel('Balance')
# plt.title('Balance Comparison')
# plt.legend(['CFN', 'CFN_MY', 'COM', 'COM_MY'])
# plt.show()
# import matplotlib.pyplot as plt
# import numpy as np
#
# # Sample Data
# x_labels = np.array([10, 30, 50, 100, 150])  # Original x-axis values
# success_rate_cfn_dy = [0.8, 0.6, 0.75, 0.7, 0.65]
# success_rate_cfn_dy_my = [0.75, 0.65, 0.7, 0.6, 0.5]
# success_rate_com_dy = [0.7, 0.55, 0.6, 0.5, 0.45]
# success_rate_com_dy_my = [0.65, 0.5, 0.55, 0.45, 0.4]
#
# # Create equal spacing for x-coordinates
# x_labels_equal = np.linspace(0, len(x_labels) - 1, len(x_labels))
#
# plt.figure(figsize=(12, 8))
#
# # Plot the data
# plt.plot(x_labels_equal, success_rate_cfn_dy, marker='o', color='magenta', linestyle='--', label='Success Rate CFN')
# plt.plot(x_labels_equal, success_rate_cfn_dy_my, marker='s', color='cyan', linestyle='--', label='Success Rate CFN My')
# plt.plot(x_labels_equal, success_rate_com_dy, marker='o', color='orange', linestyle='-', label='Success Rate COM')
# plt.plot(x_labels_equal, success_rate_com_dy_my, marker='s', color='orange', linestyle='-', label='Success Rate COM My')
#
# # Set title and labels
# plt.title('Success Rate Comparison: CFN vs. COM')
# plt.xlabel('Request Number')
# plt.ylabel('Success Rate')
#
# # Set x-ticks and labels
# plt.xticks(x_labels_equal, x_labels)
#
# # Show horizontal grid lines only
# plt.grid(axis='y', linestyle='--', color='gray')
#
# # Add legend
# plt.legend()
#
# # Show the plot
# plt.show()
# from matplotlib import colorscolors.CSS4_COLORS
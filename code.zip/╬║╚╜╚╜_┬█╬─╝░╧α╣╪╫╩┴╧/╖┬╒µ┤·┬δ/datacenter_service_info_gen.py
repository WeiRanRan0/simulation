import os
import random
import pandas as pd
import json
from Parameter import Large_num, Medium_num, Edge_num, large_service_num, medium_service_num, edge_service_num,service_type_num

file_p = './service'
if not os.path.exists(file_p):
    os.makedirs(file_p)
random.seed(38)


class DataCenter:
    def __init__(self, name, server_num, server_ids):
        self.name = name
        self.server_num = server_num
        self.server_list = server_ids
        self.main_node = None


# class Service:
#     def __init__(self, data_center_name, service_type, c_delay, delay_level):
#         self.data_center_name = data_center_name
#         self.request_type = service_type
#         self.delay = c_delay
#         self.delay_level = delay_level
#
#
# def generate_services(data_center_name, num_services):
#     services = []
#     for _ in range(num_services):
#         service_type = random.randint(1, 50)
#         if 1 <= service_type <= 10:
#             delay = random.uniform(0.2, 2)
#             delay_level = 0
#         elif 11 <= service_type <= 40:
#             delay = random.uniform(3, 15)
#             delay_level = 1
#         else:
#             delay = random.uniform(15, 40)
#             delay_level = 2
#         services.append(Service(data_center_name, service_type, delay, delay_level))
#     return services
class Service:
    def __init__(self, data_center_name, service_type, c_delay, delay_level, success_rate, success_rate_level):
        self.data_center_name = data_center_name
        self.request_type = service_type
        self.delay = c_delay
        self.delay_level = delay_level
        self.success_rate = success_rate
        self.success_rate_level = success_rate_level


def generate_services(data_center_name, num_services):
    services = []
    for _ in range(num_services):
        service_type = random.randint(1, service_type_num)
        # 根据 service_type 确定 delay 和 delay_level
        if 1 <= service_type <= 0.25*service_type_num:
            delay = random.uniform(0.2, 2)
            delay_level = 0

            success_rate_level = 0

        elif 0.25*service_type_num +1 <= service_type <= 0.75*service_type_num:
            delay = random.uniform(3, 15)
            delay_level = 1
            if delay < 9:
                success_rate_level = 0
            else:
                success_rate_level = 1
        else:
            delay = random.uniform(15, 40)
            delay_level = 2
            if delay < 21:
                success_rate_level = 0
            elif delay < 27:
                success_rate_level = 1
            elif delay < 33:
                success_rate_level = 2
            else:
                success_rate_level = 3
        # 根据 success_rate_level 设定 success_rate
        if success_rate_level == 0:
            success_rate = random.uniform(95, 100)
        elif success_rate_level == 1:
            success_rate = random.uniform(90, 95)
        elif success_rate_level == 2:
            success_rate = random.uniform(85, 90)
        else:
            success_rate = random.uniform(80, 85)
        # if 1 <= service_type <= 10:
        #     delay = random.uniform(0.2, 2)
        #     delay_level = 0
        # elif 11 <= service_type <= 40:
        #     delay = random.uniform(3, 15)
        #     delay_level = 1
        # else:
        #     delay = random.uniform(15, 40)
        #     delay_level = 2
        services.append(Service(data_center_name, service_type, delay, delay_level, success_rate, success_rate_level))
    return services


def generate_data_center_services(data_centers, num_service_dict):
    all_requests = []

    # Generate requests for each data center according to the specified number of requests
    for center in data_centers:
        num_services = num_service_dict.get(center.name, 0)
        all_requests.extend(generate_services(center.name, num_services))

    # Convert requests to DataFrame
    def services_to_dataframe(services):
        return pd.DataFrame([{
            "Data_Center_Name": r.data_center_name,
            "services_Type": r.request_type,
            "Delay": r.delay,
            "Delay_level": r.delay_level,
            'Success_rate': r.success_rate,
            'Success_rate_level': r.success_rate_level
        } for r in services])

    all_services = services_to_dataframe(all_requests)
    return all_services


# Example usage:
large_centers = [DataCenter(f"Large{i + 1}", 40, []) for i in range(Large_num)]
medium_centers = [DataCenter(f"Medium{i + 1}", 20, []) for i in range(Medium_num)]
edge_centers = [DataCenter(f"Edge{i + 1}", 10, []) for i in range(Edge_num)]

all_centers = large_centers + medium_centers + edge_centers

file_path = './service_num_per_datacenter'
if not os.path.exists(file_path):
    os.makedirs(file_path)
json_file_path = os.path.join(
    file_path,
    f'num_service_per_datacenter_{large_service_num}_{medium_service_num}_{edge_service_num}.json'
)
if os.path.exists(json_file_path):
    # Read the JSON file
    with open(json_file_path, 'r') as json_file:
        num_services_dict = json.load(json_file)
    print("num_services_dict has been loaded from the file.")
else:
    print(f"File '{json_file_path}' does not exist.")

all_services_df = generate_data_center_services(all_centers, num_services_dict)
print(all_services_df.head(10))
csv_file_path = os.path.join(
    file_p,
    f'data_center_services_{large_service_num}_{medium_service_num}_{edge_service_num}.csv'
)

xlsx_file_path = os.path.join(
    file_p,
    f'data_center_services_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx'
)
# Save the DataFrame to CSV
all_services_df.to_csv(csv_file_path, index=False)

# Save the DataFrame to Excel
all_services_df.to_excel(xlsx_file_path, index=False)

print(f"DataFrame has been saved to '{csv_file_path}' and '{xlsx_file_path}'")

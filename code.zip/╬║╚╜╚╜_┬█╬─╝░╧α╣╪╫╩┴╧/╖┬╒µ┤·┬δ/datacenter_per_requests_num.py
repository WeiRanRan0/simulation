import json
import sys

from Parameter import Large_num, Medium_num, Edge_num, large_request_num, medium_request_num, edge_request_num
import random
import os

file_p = './request_num_per_datacenter'
if not os.path.exists(file_p):
    os.makedirs(file_p)
default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values


def create_requests_dict_random(large_val, medium_val, edge_val, num_large, num_medium, num_edge):
    range_offset = 5  # Define the range offset around the specific value
    requests_dict = {}

    for i in range(1, num_large + 1):
        requests_dict[f"Large{i}"] = random.randint(large_val - range_offset, large_val + range_offset)

    for i in range(1, num_medium + 1):
        requests_dict[f"Medium{i}"] = random.randint(medium_val - range_offset, medium_val + range_offset)

    for i in range(1, num_edge + 1):
        requests_dict[f"Edge{i}"] = random.randint(edge_val - range_offset, edge_val + range_offset)

    return requests_dict


# Generate dictionary with default values
num_requests_dict = create_requests_dict_random(large_request_num, medium_request_num, edge_request_num, Large_num,
                                                Medium_num, Edge_num)
json_file_path = os.path.join(file_p,
                              f'num_request_per_datacenter_{large_request_num}_{medium_request_num}_{edge_request_num}.json')

# Save the generated dictionary as a JSON file
with open(json_file_path, 'w') as json_file:
    json.dump(num_requests_dict, json_file, indent=4)
# Save the generated dictionary as a JSON file

print("num_requests_dict has been saved to 'num_request_per_datacenter.json'")

import sys

import pandas as pd
from Parameter import top_k, DOMAIN_INTERVAL, SERVICE_RECORD_NUM, REQUEST_NUM, large_request_num, medium_request_num, \
    edge_request_num, large_service_num, medium_service_num, edge_service_num

request_file_path = './request/'
scheduler_file_path = './scheduler/'
file_to_save = './match/'
default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values

rst = pd.read_csv(
    request_file_path + f'data_center_requests_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
svs = pd.read_csv(
    scheduler_file_path + f'schedule_result_srv6_{weight_type}_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
failed_rst = pd.DataFrame()
match_result_with_domain = pd.DataFrame()
rst_group_by_network_node = rst.groupby(['Data_Center_Name'])
# print(rst_group_by_network_node.head(10))
print('**************************************************')
print('SRV6 MATCH NUM IS ',{weight_type}, len(rst))
for node_num, requests in rst_group_by_network_node:
    # print('node_num:', node_num)
    for index, request in requests.iterrows():
        rst_sid = request['Request_Type']
        rst_delay_level = request['Delay_Level']
        rst_rate_level = request['Success_Rate_Level']
        # print('index:', index, 'rst_sid:', rst_sid, 'delay_level:', rst_delay_level)
        candidates = svs[(svs['services_Type'] == rst_sid) &
                         (svs['local_node'] == node_num)]
        # print('candidates', candidates)
        if not candidates.empty:

            for i in range(1):
                candidates_by_algo = candidates[candidates['algo'] == 'topsis']
                # print('in:candidates_by_algo')
                # print(candidates_by_algo, "\n")
                candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                node_by_algo_result = candidates_by_algo_sorted.head(1).sample(n=1)
                # print('in:node_by_algo_result')
                # print(node_by_algo_result, "\n")
                temp_row = pd.DataFrame(request).T
                node_by_algo_result.rename(
                    columns={'Data_Center_Name': 'rst_choice_Data_Center_Name',
                             'Delay': 'delay',
                             'Delay_level': 'delay_level'}, inplace=True)
                node_by_algo_result.reset_index(drop=True, inplace=True)
                temp_row.reset_index(drop=True, inplace=True)
                temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                match_result_with_domain = pd.concat(
                    [match_result_with_domain, temp_contact])
        else:
            failed_rst = pd.concat([failed_rst, pd.DataFrame(request).T])

match_result_with_domain.to_csv(file_to_save +
                                f'match_result_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv',
                                index=False)
match_result_with_domain.to_excel(file_to_save +
                                  f'match_result_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx',
                                  index=False)

failed_rst.to_csv(file_to_save +
                  f'failed_rst_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv',
                  index=False)
failed_rst.to_excel(file_to_save +
                    f'failed_rst_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx',
                    index=False)
print(
    f'match_with_srv6.py********{weight_type}{iter_num} end--------------------------------------------------------------------------------')

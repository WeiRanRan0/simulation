import json
import sys
import pandas as pd
from Parameter import large_request_num, medium_request_num, edge_request_num

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
folder_path = './resource/'
file_to_save = './successrate/'
default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values
# 读取 JSON 文件并解析数据
with open(
        folder_path + f'resource_utilizations_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.json',
        'r') as file:
    data = json.load(file)
try:
    failed_df = pd.read_csv(f'./match/failed_rst_with_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')
    failed_num = len(failed_df)
except pd.errors.EmptyDataError:
    failed_num = 0
print('failed num in match:', failed_num)
node_summary = {}

node_ids_set = set()  # 创建一个集合来存储不同的节点ID
# 遍历节点和算法


for algorithms, node_tsk in data.items():
    if algorithms not in node_summary:
        node_summary[algorithms] = {}

    for node_id, tasks_data in node_tsk.items():
        if node_id not in node_summary[algorithms]:
            node_summary[algorithms][node_id] = {}

        success_count = 0
        total_count = len(tasks_data)
        total_improvement = 0
        perfect_satisfaction_count = 0

        for entry in tasks_data:
            cpu_util = entry['cpu_utilization']
            mem_util = entry['mem_utilization']
            disk_util = entry['disk_utilization']

            # 根据不同的利用率阈值调整处理时间的乘数
            if cpu_util < 0.04 or mem_util < 0.04 or disk_util < 0.04:
                multiplier = 4
            elif cpu_util < 0.07 or mem_util < 0.07 or disk_util < 0.07:
                multiplier = 3
            elif cpu_util < 0.1 or mem_util < 0.1 or disk_util < 0.1:
                multiplier = 2
            else:
                multiplier = 1  # 默认不调整处理时间

            entry['process_time'] *= multiplier

            true_delay = entry['process_time'] + entry['link_condition']
            if true_delay <= entry['max_delay']:
                task_result = 1
                success_count += 1
            else:
                task_result = 0

            entry['result'] = task_result

            improvement = (entry['max_delay'] - true_delay) / entry['max_delay']
            total_improvement += improvement

            if true_delay < entry['rst_delay']:
                perfect_satisfaction_count += 1

        success_rate = (success_count-failed_num ) / total_count if total_count > 0 else 0
        average_improvement = total_improvement / total_count if total_count > 0 else 0
        perfect_satisfaction_rate = perfect_satisfaction_count / total_count if total_count > 0 else 0

        node_summary[algorithms][node_id] = {
            'Success Rate': success_rate,
            'Average Improvement': average_improvement,
            'Perfect Satisfaction Rate': perfect_satisfaction_rate
        }
summary_list = []

for algorithms, algorithms_data in node_summary.items():
    for node_id, node_data in algorithms_data.items():
        summary_list.append({
            'algorithms': algorithms,
            'node_id': node_id,
            'success_rate': node_data['Success Rate'],
            'average_improvement_rate': node_data['Average Improvement'],
            'perfect_satisfaction_rate': node_data['Perfect Satisfaction Rate']
        })

# Use json_normalize to create the DataFrame
results = pd.DataFrame(summary_list)

# print(results)

# 保存结果为CSV文件
results.to_csv(
    file_to_save + f'task_success_rates_per_node_with_res_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv')

results_all = {}

# 处理每个算法下的数据
for algo, nodes_data in data.items():
    success_count = 0
    total_count = 0
    results_all[algo] = {}
    total_improvement = 0
    perfect_satisfaction_count = 0
    for node, tasks in nodes_data.items():
        for task in tasks:
            # 根据资源利用率调整处理时间
            cpu_util = task['cpu_utilization']
            mem_util = task['mem_utilization']
            disk_util = task['disk_utilization']

            if cpu_util < 0.04 or mem_util < 0.04 or disk_util < 0.04:
                task['process_time'] *= 4
            elif cpu_util < 0.07 or mem_util < 0.07 or disk_util < 0.07:
                task['process_time'] *= 3
            elif cpu_util < 0.1 or mem_util < 0.1 or disk_util < 0.1:
                task['process_time'] *= 2

            # 计算比较值
            comparison_value = task['process_time'] + task['link_condition']

            # 判断任务是否成功
            if comparison_value > task['max_delay']:
                task_result = 0  # 任务失败
            else:
                task_result = 1  # 任务成功
                success_count += 1
            improvement = (task['max_delay'] - comparison_value) / task['max_delay']
            total_improvement += improvement

            if comparison_value < task['rst_delay']:
                perfect_satisfaction_count += 1

            # 记录任务总数
            total_count += 1
            # 记录任务总数

    # 计算成功率
    success_rate = (success_count-failed_num) / total_count if total_count > 0 else 0
    average_improvement = total_improvement / total_count if total_count > 0 else 0
    perfect_satisfaction_rate = perfect_satisfaction_count / total_count if total_count > 0 else 0

    results_all[algo] = {
        'Success Rate': success_rate,
        'Average Improvement': average_improvement,
        'Perfect Satisfaction Rate': perfect_satisfaction_rate
    }
    # success_rate = success_count / total_count if total_count > 0 else 0
    # results_all[algo] = success_rate
results_list = []

for algo, metrics in results_all.items():
    results_list.append({
        'algo': algo,
        'success_rate': metrics['Success Rate'],
        'average_improvement_rate': metrics['Average Improvement'],
        'perfect_satisfaction_rate': metrics['Perfect Satisfaction Rate']
    })

# Create DataFrame
results_all_df = pd.DataFrame(results_list)

# 打印结果
print(
    '**********SRV6 Success Rate With Resource****************************************************************************************')
print(results_all_df)

# 保存结果为CSV文件
results_all_df.to_csv(
    file_to_save + f'task_success_rates_per_algo_with_res_srv6_{weight_type}_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv',
    index=False)
print(
    f'satisfaction_rate_srv6_with_resource.py********{weight_type}{iter_num} end--------------------------------------------------------------------------------')

# 定义节点信息生成参数
import numpy as np

NETWORK_NODE_NUM = 25
SERVICE_RECORD_NUM = 2000
REQUEST_NUM = 500
CRITERIA_NUM = 7
REQUEST_SIZE = (REQUEST_NUM, CRITERIA_NUM)
DOMAIN_INTERVAL = 5
# SI = 2  # 资源种类，目前定为cpu和内存两种
FILE_NUM = 1300
NODE_RESOURCE = [(16 * 2, 16 * 8 * 2), (16 * 2 * 2, 16 * 8 * 2), (16 * 4 * 2, 16 * 4 * 8)]
# s_min_domain = [37, 80, 0.3, 0.3, 0.3 * 16 * 2, 0.3 * 16 * 8 * 2,
#                 0.0001]  # Only Relevant if SPOTIS method is selected. Default Value = 0.5
# s_max_domain = [405, 100, 0.99, 0.99, 0.99 * 16 * 4 * 2, 0.99 * 16 * 4 * 8,
#                 4.99]  # Only Relevant if SPOTIS method is selected
s_min = [0.19,  0.1, 0.3, 0.3, 100, 1.97, 2.82,
         0.00001]  # Only Relevant if SPOTIS method is selected. Default Value = 0.5
s_max = [40, 1, 1, 1, 5450, 58.2, 93.2, 40]  # Only Relevant if SPOTIS method is selected
# cpu_values = [32, 92]  # CPU 核心数可能取值
# mem_values = [64, 288]  # 内存总量可能取值（单位：GB）
# cpu_probabilities = [0.5, 0.5]  # CPU 核心数对应的概率
# mem_probabilities = [0.5, 0.5]  # 内存总量对应的概率de
top_k = 1
CLUSTER_NETWORK_CONNECT = [(0, 0), (1, 5), (2, 10), (3, 15), (4, 20), (5, 3), (6, 8), (7, 14), (8, 24), (9, 17)]
DELAY_INTERVALS = [(40, 100), (100, 200), (200, 300), (300, 405)]
RATE_INTERVALS = [(80, 85), (85, 90), (90, 95), (95, 100)]
CPU_INTERVALS = [(0.5, 1), (1, 2), (2, 4), (4, 6), (6, 8), (8, 10)]
MEM_INTERVALS = [(0, 4), (4, 8), (8, 12), (12, 16), (16, 20)]
mic = np.array([2, 5, 5, 5, 3, 3, 3, 1])
lic = np.array([4, 1, 1, 1, 3, 3, 3, 5])
strategy_coefficient = 1
Large_num = 3
Medium_num = 9
Edge_num = 45
service_type_num = 20

large_request_num = 180
medium_request_num = 180
edge_request_num = 180

large_service_num = 100
medium_service_num = 80
edge_service_num = 60
lam = 5
weight_type = 'en'
# iter_num = 1

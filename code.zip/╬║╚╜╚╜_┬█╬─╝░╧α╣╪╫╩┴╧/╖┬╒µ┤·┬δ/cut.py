# # import json
# #
# # num_requests_dict = {
# #     "Large1": 500,
# #     "Large2": 500,
# #     "Large3": 500,
# #     "Medium1": 200,
# #     "Medium2": 200,
# #     "Medium3": 200,
# #     "Medium4": 200,
# #     "Medium5": 200,
# #     "Medium6": 200,
# #     "Medium7": 200,
# #     "Medium8": 200,
# #     "Medium9": 200,
# #     "Edge1": 100,
# #     "Edge2": 100,
# #     "Edge3": 100,
# #     "Edge4": 100,
# #     "Edge5": 100,
# #     "Edge6": 100,
# #     "Edge7": 100,
# #     "Edge8": 100,
# #     "Edge9": 100,
# #     "Edge10": 100,
# #     "Edge11": 100,
# #     "Edge12": 100,
# #     "Edge13": 100,
# #     "Edge14": 100,
# #     "Edge15": 100,
# #     "Edge16": 100,
# #     "Edge17": 100,
# #     "Edge18": 100,
# #     "Edge19": 100,
# #     "Edge20": 100,
# #     "Edge21": 100,
# #     "Edge22": 100,
# #     "Edge23": 100,
# #     "Edge24": 100,
# #     "Edge25": 100,
# #     "Edge26": 100,
# #     "Edge27": 100,
# #     "Edge28": 100,
# #     "Edge29": 100,
# #     "Edge30": 100,
# #     "Edge31": 100,
# #     "Edge32": 100,
# #     "Edge33": 100,
# #     "Edge34": 100,
# #     "Edge35": 100,
# #     "Edge36": 100,
# #     "Edge37": 100,
# #     "Edge38": 100,
# #     "Edge39": 100,
# #     "Edge40": 100,
# #     "Edge41": 100,
# #     "Edge42": 100,
# #     "Edge43": 100,
# #     "Edge44": 100,
# #     "Edge45": 100,
# # }
# #
# # with open('num_requests_per_datacenter.json', 'w') as json_file:
# #     json.dump(num_requests_dict, json_file, indent=4)
# #
# # print("num_requests_dict has been saved to 'num_requests.json'")
# #
# # import sys
# #
# # import numpy as np
# # import pandas as pd
# # from pyDecision.algorithm import entropy_method, bw_method
# # #
# # # # 示例数据
# # # data = np.array([
# # #     [0.7, 0.5, 0.8],
# # #     [0.6, 0.4, 0.9],
# # #     [0.8, 0.7, 0.6],
# # # ])
# # #
# # # df = pd.DataFrame(data, columns=['指标1', '指标2', '指标3'])
# # # crt = ['max', 'max', 'max']
# # #
# # # # w = entropy_method(df, crt)
# # # # print("熵权法权重:", w)
# # #
# # # # 假设X是n个决策单元和m个指标的数据矩阵
# # # w = np.array([0.03786518, 0.17520748, 0.078543, 0.04108239, 0.25048796, 0.10346769,
# # #               0.14917754, 0.16416876])
# # #
# # # # 步骤2：确定最大值和最小值的权重
# # #
# # #
# # # print("权重：", w)
# # # print("MIC矩阵：", MIC)
# # # print("LIC矩阵：", LIC)
# # # bwm_weights = bw_method(MIC, LIC)
# # # print("bwm", bwm_weights)
# # # import sys
# # #
# # # default_values = ['en', 1]
# # # args = sys.argv[1:]
# # # provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
# # # provided_values.extend(default_values[len(provided_values):])
# # # weight_type, iter_num = provided_values
# # #
# # # # 打印解析后的参数
# # # print("Parsed Arguments:")
# # #
# # # print(f"weight_type: {weight_type}")
# # # print(f"iter_num: {iter_num}")
# # # import sys
# # #
# # # # 默认值
# # # default_weight_type = 'default'
# # # default_iter_num = 1
# # #
# # # # 获取命令行参数
# # # if len(sys.argv) > 1:
# # #     weight_type = sys.argv[1]
# # # else:
# # #     weight_type = default_weight_type
# # #
# # # if len(sys.argv) > 2:
# # #     iter_num = int(sys.argv[2])
# # # else:
# # #     iter_num = default_iter_num
# # #
# # # print("Parsed Arguments:")
# # # print(f"weight_type: {weight_type}")
# # # print(f"iter_num: {iter_num}")
# # # i = 10
# # # for j in range(i):
# # #     print(j)
# # # import argparse
# # #
# # # # 设置默认参数
# # # default_weight_type = 'en'
# # # default_iter_num = 1
# # #
# # # # 创建 ArgumentParser 对象
# # # parser = argparse.ArgumentParser(description='Process command line arguments')
# # #
# # # # 添加命令行参数
# # # parser.add_argument('iter_num', type=int, nargs='?', default=default_iter_num, help='Iteration number')
# # # parser.add_argument('--weight_type', type=str, default=default_weight_type, help='Weight type')
# # #
# # # # 解析命令行参数
# # # args = parser.parse_args()
# # #
# # # # 获取参数值
# # # iter_num = args.iter_num
# # # weight_type = args.weight_type
# # #
# # # # 打印参数值进行测试
# # # print(f'Weight Type: {weight_type}')
# # # print(f'Iteration Number: {iter_num}')
# # import pandas as pd
# #
# # # 假设这里有10个 DataFrame，用 df1 到 df10 表示
# # df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
# # df2 = pd.DataFrame({'A': [7, 8, 9], 'B': [10, 11, 12]})
# # df3 = pd.DataFrame({'A': [13, 14, 15], 'B': [16, 17, 18]})
# # # 假设 df4 到 df10 也是类似的 DataFrame
# #
# # # 将这些 DataFrame 存储在一个列表中
# # dataframes = [df1, df2, df3]  # 将 df4 到 df10 也添加到这个列表中
# #
# # # 使用 concat 函数进行垂直拼接
# # result = pd.concat(dataframes, ignore_index=True)
# #
# # # 打印拼接后的结果
# # print(result)
# import pandas as pd
#
# # 创建示例数据
# data1 = {
#     'A': [1, 2, 3],
#     'B': [4, 5, 6],
#     'C': [7, 8, 9]
# }
# data2 = {
#     'X': [0.1, 0.2, 0.3],
#     'Y': [0.4, 0.5, 0.6],
#     'Z': [0.7, 0.8, 0.9]
# }
#
# df1 = pd.DataFrame(data1)
# df2 = pd.DataFrame(data2)
#
# # 显示 df1 和 df2 的内容
# print("DataFrame 1:")
# print(df1)
# print("\nDataFrame 2:")
# print(df2)
#
# # 按行和列进行减法操作
# result = df1.sub(df2)
#
# # 显示相减后的结果
# print("\n相减后的结果:")
# print(result)
import pandas as pd
pd.read_csv('./algo_final_result/')
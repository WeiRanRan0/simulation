import pickle
import numpy as np
# from Parameter import mic, lic
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp

mic = np.array([2, 5, 5, 5, 3, 3, 3, 1])
lic = np.array([9, 1, 1, 1, 9, 9, 9, 5])
bwm_weights = bw_method(mic, lic, eps_penalty=1)
print(bwm_weights)
# with open('bwm_weights.pkl', 'wb') as file:
#     pickle.dump(bwm_weights, file)

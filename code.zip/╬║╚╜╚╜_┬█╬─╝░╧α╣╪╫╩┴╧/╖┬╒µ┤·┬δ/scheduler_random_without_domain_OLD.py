import pickle
import pandas as pd
import random
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import s_max, s_min, strategy_coefficient

# 读取信息,并根据域内分组,创建新的存放结果的pd
service_df = pd.read_csv('info_without_domain.csv')
service_grouped = service_df.groupby(['local_node', 'sid', 'delay_level', 'rate_level'])
schedule_result_df = pd.DataFrame()
algorithms = ['topsis', 'spotis']
custom_m = ['mtp']
default_algo = ['random']
all_algo = algorithms + custom_m
for name, group in service_grouped:
    # print(type(name))
    # print(name)
    # print(type(group))
    # print(group)
    # print(len(group))
    temp_result = group[
        ['network_node', 'local_node', 'node_name', 'domain', 'sid', 'delay_level', 'rate_level']].copy()
    temp_result['algo'] = default_algo[0]
    temp_result['cluster_rank_by_algo'] = random.sample(range(1, len(group) + 1), len(group))
    print(temp_result)
    schedule_result_df = pd.concat([schedule_result_df, temp_result])

schedule_result_df.to_csv('schedule_result_random_without_domain_OLD.csv', index=False)
schedule_result_df.to_excel('schedule_result_random_without_domain_OLD.xlsx', index=False)

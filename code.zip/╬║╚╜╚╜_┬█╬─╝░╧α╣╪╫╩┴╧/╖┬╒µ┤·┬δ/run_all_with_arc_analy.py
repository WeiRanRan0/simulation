import pandas as pd
import glob
from Parameter import large_request_num, medium_request_num, edge_request_num
import matplotlib.pyplot as plt
import numpy as np

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)

algo_com = 'en'
algo_cfn = 'en'


def process_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)
        avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


def process_dy_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)
        avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
        avg_improvement_rate_by_algo = combined_data.groupby('algo')['average_improvement_rate'].mean().reset_index()
        avg_perfect_satisfaction_rate_by_algo = combined_data.groupby('algo')[
            'perfect_satisfaction_rate'].mean().reset_index()
        original_data_list = []
        for algo in combined_data['algo'].unique():
            avg_success = avg_success_rate_by_algo.loc[avg_success_rate_by_algo['algo'] == algo, 'success_rate'].values[
                0]
            avg_improvement = avg_improvement_rate_by_algo.loc[
                avg_improvement_rate_by_algo['algo'] == algo, 'average_improvement_rate'].values[0]
            avg_perfect_satisfaction = avg_perfect_satisfaction_rate_by_algo.loc[
                avg_perfect_satisfaction_rate_by_algo['algo'] == algo, 'perfect_satisfaction_rate'].values[0]

            original_data_list.append({
                'algo': algo,
                'avg_success_rate': avg_success,
                'avg_improvement_rate': avg_improvement,
                'avg_perfect_satisfaction_rate': avg_perfect_satisfaction
            })

        original_data = pd.DataFrame(original_data_list)
        original_data.to_csv(output_file, index=False)

        print(f"结果已保存至 {output_file}")

        return combined_data, original_data
    else:
        print("未找到匹配的文件。")


def process_balance_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)

        avg_success_rate_by_algo = combined_data.groupby('algorithm')['zero_ratio'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


print(
    '^^^^^^^^^静态成功率可视化**********************************************************************************************')
print()
folder_from = './successrate'  # 替换为实际的文件夹路径
folder_to = './final_result'
# file_cfn = f'{folder_from}/results_analysis_with_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_cfn = f'{folder_to}/success_rate_sta_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# file_com = f'{folder_from}/results_analysis_with_com22_{algo_com}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com = f'{folder_to}/success_rate_sta_results_with_com22_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# file_dns = f'{folder_from}/results_analysis_with_dns_{algo_com}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_dns = f'{folder_to}/success_rate_sta_results_with_dns_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
#
# cfn, cfn_avg_df = process_files_and_save(file_cfn, output_cfn)
# com, com_avg_df = process_files_and_save(file_com, output_com)
# dns, dns_avg_df = process_files_and_save(file_dns, output_dns)
# # 提取 'topsis' 算法的平均值
# algo_to_plot = 'topsis'
# cfn_avg = cfn_avg_df.loc[cfn_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_avg = com_avg_df.loc[com_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# dns_avg = dns_avg_df.loc[dns_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # 合并数据
# merged = pd.concat([cfn, com, dns], axis=1)
# merged.columns = ['algo', 'success_rate_cfn', 'algo', 'success_rate_com', 'algo', 'success_rate_dns']
# merged_new = merged.loc[:, ~merged.columns.duplicated()]
#
# # 按算法分组
# merged_g = merged_new.groupby('algo')
#
# # 获取对应算法的数据
# data_to_plot = merged_g.get_group(algo_to_plot)
#
# # 绘制折线图
# plt.figure(figsize=(10, 6))
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'],
#          label=f'{algo_to_plot} - CFN')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com'],
#          label=f'{algo_to_plot} - COM')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_dns'],
#          label=f'{algo_to_plot} - dns')
# # 在每个数据点上标出数据
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'], color='blue')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com'], color='orange')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_dns'], color='green')
# # 在图例中标出平均值（通过不可见点）
# plt.scatter([], [], color='blue', label=f'Average CFN: {cfn_avg:.2f}')
# plt.scatter([], [], color='orange', label=f'Average COM: {com_avg:.2f}')
# plt.scatter([], [], color='green', label=f'Average dns: {dns_avg:.2f}')
# # 设置x轴标签
# plt.xlabel('Number of Iterations')
#
# # 设置y轴标签
# plt.ylabel('Success Rate')
#
# # 设置标题
# plt.title(f'Success Rates for {algo_to_plot} Algorithm')
# plt.legend(loc='lower right', prop={'size': 8})
# plt.grid(True)
#
# plt.show()

print(
    '^^^^^^^^^动态成功率可视化**********************************************************************************************')
print()

file_cfn_dy = f'{folder_from}/task_success_rates_per_algo_with_res_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_cfn_dy = f'{folder_to}/success_rate_dy_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
file_com_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_com}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输
file_dns_dy = f'{folder_from}/task_success_rates_per_algo_with_res_dns_{algo_com}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_dns_dy = f'{folder_to}/success_rate_dy_results_with_dns_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输
algo_to_plot = 'topsis'
cfn_dy, cfn_dy_avg_df = process_dy_files_and_save(file_cfn_dy, output_cfn_dy)
com_dy, com_dy_avg_df = process_dy_files_and_save(file_com_dy, output_com_dy)
dns_dy, dns_dy_avg_df = process_dy_files_and_save(file_dns_dy, output_dns_dy)
cfn_dy_avg_success_rate = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_success_rate'].values[0]
com_dy_avg_success_rate = com_dy_avg_df.loc[com_dy_avg_df['algo'] == algo_to_plot, 'avg_success_rate'].values[0]
dns_dy_avg_success_rate = dns_dy_avg_df.loc[dns_dy_avg_df['algo'] == algo_to_plot, 'avg_success_rate'].values[0]
cfn_dy_avg_improvement_rate = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
com_dy_avg_improvement_rate = com_dy_avg_df.loc[com_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
dns_dy_avg_improvement_rate = \
    dns_dy_avg_df.loc[dns_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
cfn_dy_avg_perfect_satisfaction_rate = \
    cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_satisfaction_rate'].values[0]
com_dy_avg_perfect_satisfaction_rate = \
    com_dy_avg_df.loc[com_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_satisfaction_rate'].values[0]
dns_dy_avg_perfect_satisfaction_rate = \
    dns_dy_avg_df.loc[dns_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_satisfaction_rate'].values[0]
cfn_algo_data = cfn_dy[cfn_dy['algo'] == algo_to_plot]
com_algo_data = com_dy[com_dy['algo'] == algo_to_plot]
dns_algo_data = dns_dy[dns_dy['algo'] == algo_to_plot]
# 绘制对比图
plt.figure(figsize=(12, 8))

# 成功率对比折线图
plt.subplot(2, 2, 1)
plt.plot(range(1, len(cfn_algo_data) + 1), cfn_algo_data['success_rate'], marker='o', linestyle='-', color='blue', label='CFN')
plt.plot(range(1, len(com_algo_data) + 1), com_algo_data['success_rate'], marker='o', linestyle='-', color='orange', label='COM')
plt.plot(range(1, len(dns_algo_data) + 1), dns_algo_data['success_rate'], marker='o', linestyle='-', color='green', label='dns')
plt.title('Dynamic Success Rate Comparison')
plt.xlabel('Iterations')
plt.ylabel('Success Rate')
plt.legend()

# 改进率对比折线图
plt.subplot(2, 2, 2)
plt.plot(range(1, len(cfn_algo_data) + 1), cfn_algo_data['average_improvement_rate'], marker='o', linestyle='-', color='blue',
         label='CFN')
plt.plot(range(1, len(com_algo_data) + 1), com_algo_data['average_improvement_rate'], marker='o', linestyle='-', color='orange',
         label='COM')
plt.plot(range(1, len(dns_algo_data) + 1), dns_algo_data['average_improvement_rate'], marker='o', linestyle='-', color='green',
         label='dns')
plt.title('Dynamic Improvement Rate Comparison')
plt.xlabel('Iterations')
plt.ylabel('Improvement Rate')
plt.legend()

# 满意率对比折线图
plt.subplot(2, 2, 3)
plt.plot(range(1, len(cfn_algo_data) + 1), cfn_algo_data['perfect_satisfaction_rate'], marker='o', linestyle='-', color='blue',
         label='CFN')
plt.plot(range(1, len(com_algo_data) + 1), com_algo_data['perfect_satisfaction_rate'], marker='o', linestyle='-', color='orange',
         label='COM')
plt.plot(range(1, len(dns_algo_data) + 1), dns_algo_data['perfect_satisfaction_rate'], marker='o', linestyle='-', color='green',
         label='dns')
plt.title('Dynamic Perfect Satisfaction Rate Comparison')
plt.xlabel('Iterations')
plt.ylabel('Perfect Satisfaction Rate')
plt.legend()

# 在图例中标注平均值
plt.subplot(2, 2, 4)
plt.scatter([], [], color='blue', label=f'Average CFN Success Rate: {cfn_dy_avg_success_rate:.2f}')
plt.scatter([], [], color='orange', label=f'Average COM Success Rate: {com_dy_avg_success_rate:.2f}')
plt.scatter([], [], color='green', label=f'Average dns Success Rate: {dns_dy_avg_success_rate:.2f}')
plt.scatter([], [], color='blue', label=f'Average CFN Improvement Rate: {cfn_dy_avg_improvement_rate:.2f}')
plt.scatter([], [], color='orange', label=f'Average COM Improvement Rate: {com_dy_avg_improvement_rate:.2f}')
plt.scatter([], [], color='green', label=f'Average dns Improvement Rate: {dns_dy_avg_improvement_rate:.2f}')
plt.scatter([], [], color='blue',
            label=f'Average CFN Perfect Satisfaction Rate: {cfn_dy_avg_perfect_satisfaction_rate:.2f}')
plt.scatter([], [], color='orange',
            label=f'Average COM Perfect Satisfaction Rate: {com_dy_avg_perfect_satisfaction_rate:.2f}')
plt.scatter([], [], color='green',
            label=f'Average dns Perfect Satisfaction Rate: {dns_dy_avg_perfect_satisfaction_rate:.2f}')
plt.axis('off')
plt.legend(loc='center', fontsize='large')

# 调整布局
plt.tight_layout()

# 显示图形
plt.show()

print(
    '^^^^^^^^^资源均衡率可视化**********************************************************************************************')
print()

balance_folder = './balance'
cfn_balance = f'{balance_folder}/balance_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
output_cfn_balance = f'{folder_to}/avg_balance_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
com_balance = f'{balance_folder}/balance_com22_{algo_com}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
output_com_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
dns_balance = f'{balance_folder}/balance_dns_{algo_com}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'  # 替换为实际的文件名模式
output_dns_balance = f'{folder_to}/avg_balance_results_with_dns_{algo_com}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
cfn_ba, cfn_ba_avg_df = process_balance_files_and_save(cfn_balance, output_cfn_balance)
com_ba, com_ba_avg_df = process_balance_files_and_save(com_balance, output_com_balance)
dns_ba, dns_ba_avg_df = process_balance_files_and_save(dns_balance, output_dns_balance)
cfn_ba_avg = cfn_ba_avg_df.loc[cfn_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
com_ba_avg = com_ba_avg_df.loc[com_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
dns_ba_avg = dns_ba_avg_df.loc[dns_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# 合并数据
merged_ba = pd.concat([cfn_ba, com_ba, dns_ba], axis=1)
merged_ba.columns = ['algo', 'cfn_ba', 'algo', 'com_ba', 'algo', 'dns_ba']
merged_ba_new = merged_ba.loc[:, ~merged_ba.columns.duplicated()]

# 按算法分组
merged_ba_g = merged_ba_new.groupby('algo')

# 选择要绘制的算法
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot_ba = merged_ba_g.get_group(algo_to_plot)

# 绘制折线图
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='blue',
         label=f'{algo_to_plot} - CFN')
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_ba'], color='orange',
         label=f'{algo_to_plot} - COM')
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['dns_ba'], color='green',
         label=f'{algo_to_plot} - dns')

# 在每个数据点上标出数据
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='blue')
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_ba'], color='orange')
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['dns_ba'], color='green')
plt.scatter([], [], color='blue', label=f'Average CFN: {cfn_ba_avg:.2f}')
plt.scatter([], [], color='orange', label=f'Average COM: {com_ba_avg:.2f}')
plt.scatter([], [], color='green', label=f'Average dns: {dns_ba_avg:.2f}')
# 设置x轴标签
plt.xlabel('Number of Iterations')

# 设置y轴标签
plt.ylabel('Balance Rate')

# 设置标题
plt.title(f'Balance Rates for {algo_to_plot} Algorithm')

# 显示图例
plt.legend(loc='lower right', prop={'size': 8})

# 显示网格
plt.grid(True)

# 显示图形
plt.show()

import pandas as pd
from Parameter import *
from function import *

with open('interval_probabilities1.pkl', 'rb') as file:
    delay_interval_probabilities = pickle.load(file)
with open('interval_probabilities2.pkl', 'rb') as file:
    rate_interval_probabilities = pickle.load(file)
with open('interval_probabilities3.pkl', 'rb') as file:
    cpu_interval_probabilities = pickle.load(file)
with open('interval_probabilities4.pkl', 'rb') as file:
    mem_interval_probabilities = pickle.load(file)


def generate_requests(num_tasks_per_node):
    num_requests = sum(num_tasks_per_node)
    requests = np.zeros((num_requests, REQUEST_SIZE[1] + 2))  # Include an extra column for node position
    index = 0  # Initialize the index
    for i, tasks in enumerate(num_tasks_per_node):
        for j in range(tasks):
            requests[index, 0] = random.randint(1, 10)  # rst_sid
            selected_time_interval = random.choices(DELAY_INTERVALS)[0]
            requests[index, 1] = random.uniform(selected_time_interval[0], selected_time_interval[1])  # rst_delay
            requests[index, 2] = delay_level(requests[index, 1])  # rst_delay_level
            selected_rate_interval = random.choices(RATE_INTERVALS)[0]
            requests[index, 3] = random.uniform(selected_rate_interval[0], selected_rate_interval[1])  # rst_rate
            requests[index, 4] = rate_level(requests[index, 3])  # rst_rate_level
            selected_cpu_interval = random.choices(CPU_INTERVALS)[0]
            requests[index, 5] = random.uniform(selected_cpu_interval[0], selected_cpu_interval[1])  # rst_cpu_need
            selected_mem_interval = random.choices(MEM_INTERVALS)[0]
            requests[index, 6] = random.uniform(selected_mem_interval[0], selected_mem_interval[1])  # rst_mem_need
            requests[index, 7] = i  # Node position
            requests[index, 8] = i // DOMAIN_INTERVAL  # Node position
            index += 1  # Increment the index for the next task
    return requests


def generate_request_num_per_node(num, s_values, default_value, enable_specified=False):
    temp = []
    for i in range(num):
        if enable_specified and i in s_values:
            temp.append(random.randint(s_values[i][0], s_values[i][1]))  # Use default range for ignored nodes
        else:
            temp.append(random.randint(default_value, default_value + 50))  # Default range for other nodes
    return temp


flag = True
specified_values = {0: (100, 150), 5: (200, 250), 10: (300, 350)}  # Specify values for nodes 0, 5, and 10
tasks_per_node = generate_request_num_per_node(NETWORK_NODE_NUM, specified_values, REQUEST_NUM)
print(tasks_per_node)
requests_data = generate_requests(tasks_per_node)

# Create a DataFrame from the requests data
requests_df = pd.DataFrame(requests_data, columns=['rst_sid', 'rst_delay', 'rst_delay_level', 'rst_rate',
                                                   'rst_rate_level', 'rst_cpu_need', 'rst_mem_need',
                                                   'node_position', 'domain'])

# Save the DataFrame as a CSV file
requests_df.to_csv(f'requests_data{REQUEST_NUM}_{flag}.csv', index=False)
requests_df.to_excel(f'requests_data{REQUEST_NUM}_{flag}.xlsx', index=False)

###############################################################################

# Required Libraries
import matplotlib.pyplot as plt
import numpy as np


###############################################################################

# Function: Rank
def my_ranking(flow):
    rank_xy = np.zeros((flow.shape[0], 2))
    for i in range(0, rank_xy.shape[0]):
        rank_xy[i, 0] = 0
        rank_xy[i, 1] = flow.shape[0] - i
    for i in range(0, rank_xy.shape[0]):
        plt.text(rank_xy[i, 0], rank_xy[i, 1], 'a' + str(int(flow[i, 0])), size=12, ha='center', va='center',
                 bbox=dict(boxstyle='round', ec=(0.0, 0.0, 0.0), fc=(0.8, 1.0, 0.8), ))
    for i in range(0, rank_xy.shape[0] - 1):
        plt.arrow(rank_xy[i, 0], rank_xy[i, 1], rank_xy[i + 1, 0] - rank_xy[i, 0], rank_xy[i + 1, 1] - rank_xy[i, 1],
                  head_width=0.01, head_length=0.2, overhang=0.0, color='black', linewidth=0.9,
                  length_includes_head=True)
    axes = plt.gca()
    axes.set_xlim([-1, +1])
    ymin = np.amin(rank_xy[:, 1])
    ymax = np.amax(rank_xy[:, 1])
    if ymin < ymax:
        axes.set_ylim([ymin, ymax])
    else:
        axes.set_ylim([ymin - 1, ymax + 1])
    plt.axis('off')
    plt.show()
    return


# Function: TOPSIS
def my_topsis_method(dataset, weights, criterion_type, min_col, graph=False, verbose=False):
    X = np.copy(dataset)
    w = np.copy(weights)
    std_ij = np.zeros_like(dataset, dtype=float)  # 数据归一化
    min_cols = np.copy(min_col)
    # print('mincol',min_cols)
    # print('data',X)
    # print('set',dataset)
    for i in range(dataset.shape[1]):
        if criterion_type[i] == 'max':
            # print('max', i)
            # print('min_colssi',min_cols[i])
            # print('dataseti', dataset[:, i])
            std_ij[:, i] = 1 - min_cols[i] / dataset[:, i]
            # print(std_ij[:,i])
        else:
            # print('min', i)
            # print('min_colssi', min_cols[i])
            # print('dataseti', dataset[:, i])
            std_ij[:, i] = min_cols[i] / dataset[:, i]
            # print(std_ij)
    # sum_cols = np.sum(X * X, axis=0)  # 修改数据归一化方式，变为最小值归一化，每个指标的最小值是知道的
    # sum_cols = sum_cols ** (1 / 2)
    # r_ij = X / sum_cols
    # print('std', std_ij)

    v_ij = std_ij * w
    # print('vij',v_ij)
    # Y = np.sum(v_ij, axis=1)
    # print('Y',Y)
    # flow = np.copy(Y)
    # print('flow', flow.shape)
    # flow = np.reshape(flow, (Y.shape[0], 1))
    # flow = np.insert(flow, 0, list(range(1, Y.shape[0] + 1)), axis=1)
    # print('reflow', flow.shape)
    # if verbose == True:
    #     for i in range(0, flow.shape[0]):
    #         print('a' + str(int(flow[i, 0])) + ': ' + str(round(flow[i, 1], 3)))
    # if graph == True:
    #     flow = flow[np.argsort(flow[:, 1])]
    #     flow = flow[::-1]
    #     my_ranking(flow)
    # return flow
    # print('weight', w)
    # print('v_ij', v_ij)
    p_ideal_A = np.zeros(X.shape[1])
    n_ideal_A = np.zeros(X.shape[1])

    for i in range(0, dataset.shape[1]):
        p_ideal_A[i] = np.max(v_ij[:, i])
        n_ideal_A[i] = np.min(v_ij[:, i])
    # print('p_idea',p_ideal_A)
    # print('n_idea',n_ideal_A)
    p_s_ij = (v_ij - p_ideal_A) ** 2
    p_s_ij = np.sum(p_s_ij, axis=1) ** (1 / 2)
    n_s_ij = (v_ij - n_ideal_A) ** 2
    n_s_ij = np.sum(n_s_ij, axis=1) ** (1 / 2)
    c_i = n_s_ij / (p_s_ij + n_s_ij)
    if verbose:
        for i in range(0, c_i.shape[0]):
            print('a' + str(i + 1) + ': ' + str(round(c_i[i], 2)))
    if graph:
        flow = np.copy(c_i)
        flow = np.reshape(flow, (c_i.shape[0], 1))
        flow = np.insert(flow, 0, list(range(1, c_i.shape[0] + 1)), axis=1)
        flow = flow[np.argsort(flow[:, 1])]
        flow = flow[::-1]
        my_ranking(flow)
    return c_i

###############################################################################

import pickle
import random

import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import s_max, s_min, strategy_coefficient, large_service_num,medium_service_num,edge_service_num

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
file_p = './datacenterinfo/'
file_to_save = './scheduler/'
service_df = pd.read_csv(file_p+f'all_data_centers_services_with_cfn_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
service_grouped = service_df.groupby(['local_node', 'services_Type'])
schedule_result_df = pd.DataFrame()
algorithms = ['topsis', 'spotis']
custom_m = ['mtp']
all_algo = algorithms + custom_m
default_algo = ['random']
for name, group in service_grouped:
    temp_result = group.copy()
    temp_result['algo'] = default_algo[0]
    temp_result['cluster_rank_by_algo'] = random.sample(range(1, len(group) + 1), len(group))
    print(temp_result)
    schedule_result_df = pd.concat([schedule_result_df, temp_result])

schedule_result_df.to_csv(file_to_save+f'schedule_result_with_random_{large_service_num}_{medium_service_num}_{edge_service_num}.csv', index=False)
schedule_result_df.to_excel(file_to_save+f'schedule_result_with_random_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx', index=False)

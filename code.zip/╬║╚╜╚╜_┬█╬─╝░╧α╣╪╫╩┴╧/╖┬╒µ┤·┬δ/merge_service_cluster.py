import pandas as pd
from Parameter import SERVICE_RECORD_NUM

# Load df1 from 'service_info.csv' and df2 from 'cluster.csv'
df1 = pd.read_csv(f'service_record_{SERVICE_RECORD_NUM}.csv')
df2 = pd.read_csv('cluster_record.csv')

# Merge df1 and df2 based on 'node_name' and 'network_node'
merged_df = pd.merge(df1, df2, on=['node_name', 'network_node'], how='inner')

# Reorder columns in the merged DataFrame
merged_df = merged_df[['sid', 'node_name', 'network_node', 'domain', 'delay', 'delay_level', 'rate', 'rate_level',
                       'cpu_all', 'mem_all', 'cpu_availability', 'mem_availability', 'cpu', 'mem']]

# Save the merged DataFrame to CSV
merged_df.to_csv(f'merged_data_{SERVICE_RECORD_NUM}.csv', index=False)

import os
import pandas as pd
from Parameter import SERVICE_RECORD_NUM,REQUEST_NUM

rst = pd.read_csv(f'requests_data{REQUEST_NUM}_True.csv')
svs = pd.read_csv(f'schedule_result_without_domain_{SERVICE_RECORD_NUM}.csv')
match_result_without_domain = pd.DataFrame()
failed_rst_without_domain = pd.DataFrame()
rst_group_by_network_node = rst.groupby(['node_position'])
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
folder_path = f'rst{REQUEST_NUM}_service{SERVICE_RECORD_NUM}/'
if not os.path.exists(folder_path):
    os.makedirs(folder_path)
for node_num, requests in rst_group_by_network_node:
    for index, request in requests.iterrows():
        rst_sid = request['rst_sid']
        candidates = svs[(svs['sid'] == rst_sid) &
                         (svs['local_node'] == node_num)]
        # print('original can without domain')
        # print(candidates, "\n")
        if not candidates.empty:
            for algo in candidates['algo'].unique():
                candidates_by_algo = candidates[candidates['algo'] == algo]
                # print('in:candidates_by_algo')
                # print(candidates_by_algo, "\n")
                candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                node_by_algo_result = candidates_by_algo_sorted.head(1).sample(n=1)
                temp_row = pd.DataFrame(request).T
                node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                node_by_algo_result.reset_index(drop=True, inplace=True)
                temp_row.reset_index(drop=True, inplace=True)
                # print(type(temp_row))
                # print(type(candidates_by_algo))
                # print('len_temp',len(temp_row))
                # print('candidates_by_algo', len(candidates_by_algo))
                temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                match_result_without_domain = pd.concat(
                    [match_result_without_domain, temp_contact])
                # print('in:node_by_algo_result')
                # print(node_by_algo_result, "\n")
                # print('in:match_result_with_domain')
                # print(match_result_without_domain, "\n")
        else:
            failed_rst_without_domain = pd.concat([failed_rst_without_domain, pd.DataFrame(request).T])
match_result_without_domain.to_csv(folder_path+f'match_result_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
match_result_without_domain.to_excel(folder_path+f'match_result_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)
failed_rst_without_domain.to_csv(folder_path+f'failed_rst_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
failed_rst_without_domain.to_excel(folder_path+f'failed_rst_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)

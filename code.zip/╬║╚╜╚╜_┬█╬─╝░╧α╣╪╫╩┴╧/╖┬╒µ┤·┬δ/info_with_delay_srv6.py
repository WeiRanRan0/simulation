import pandas as pd
from Parameter import Large_num, Medium_num, Edge_num, large_service_num, medium_service_num, edge_service_num

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
service_file_path = './service/'
# 读取两个pd 并进行拼接
# service_df = pd.read_csv('data_center_services.csv')
service_df = pd.read_csv(
    service_file_path + f'data_center_services_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
datacenter_delay = pd.read_csv('./datacenterinfo/datacenters_delay_info.csv')
datacenter_res = pd.read_csv('./datacenterinfo/data_centers_info.csv')
all_data_df = pd.DataFrame()

temp_merge = pd.merge(service_df, datacenter_res, left_on='Data_Center_Name', right_on='name')
large_df = temp_merge[temp_merge['type'] == 'Large']
medium_df = temp_merge[temp_merge['type'] == 'Medium']
edge_df = temp_merge[temp_merge['type'] == 'Edge']
# print(large_df.head(10))
for i in range(Large_num):
    current_center_name = f'Large{i + 1}'
    for index, row in large_df.iterrows():
        other_node = row.values[0]
        delay_to = datacenter_delay[
            (datacenter_delay['Node1'] == current_center_name) &
            (datacenter_delay['Node2'] == other_node)
            ]['Delay'].values
        delay_back = datacenter_delay[
            (datacenter_delay['Node1'] == other_node) &
            (datacenter_delay['Node2'] == current_center_name)
            ]['Delay'].values

        delay = delay_to + delay_back
        merged_df = pd.DataFrame(row).T
        merged_df['local_node'] = current_center_name
        merged_df['link_condition'] = delay[0]
        # print(merged_df['link_condition'])
        all_data_df = pd.concat([all_data_df, merged_df])

for i in range(Medium_num):
    current_center_name = f'Medium{i + 1}'
    for index, row in medium_df.iterrows():
        other_node = row.values[0]
        if datacenter_res[datacenter_res['name'] == current_center_name]['main_node'].values == \
                datacenter_res[datacenter_res['name'] == other_node]['main_node'].values:
            delay_to = datacenter_delay[
                (datacenter_delay['Node1'] == current_center_name) &
                (datacenter_delay['Node2'] == other_node)
                ]['Delay'].values
            delay_back = datacenter_delay[
                (datacenter_delay['Node1'] == other_node) &
                (datacenter_delay['Node2'] == current_center_name)
                ]['Delay'].values

            delay = delay_to + delay_back
            merged_df = pd.DataFrame(row).T
            merged_df['local_node'] = current_center_name
            merged_df['link_condition'] = delay[0]
            # print(merged_df['link_condition'])
            all_data_df = pd.concat([all_data_df, merged_df])
    # main_node = datacenter_res[datacenter_res['name'] == current_center_name]['main_node'].values
    # main_node_df = large_df[large_df['Data_Center_Name'] == main_node[0]]
    # for index, row in main_node_df.iterrows():
    #     other_node = row.values[0]
    #     delay_to = datacenter_delay[
    #         (datacenter_delay['Node1'] == current_center_name) &
    #         (datacenter_delay['Node2'] == other_node)
    #         ]['Delay'].values
    #     delay_back = datacenter_delay[
    #         (datacenter_delay['Node1'] == other_node) &
    #         (datacenter_delay['Node2'] == current_center_name)
    #         ]['Delay'].values
    #
    #     delay = delay_to + delay_back
    #     merged_df = pd.DataFrame(row).T
    #     merged_df['local_node'] = current_center_name
    #     merged_df['link_condition'] = delay[0]
    #     # print(merged_df['link_condition'])
    #     all_data_df = pd.concat([all_data_df, merged_df])
for i in range(Edge_num):
    current_center_name = f'Edge{i + 1}'
    for index, row in edge_df.iterrows():
        other_node = row.values[0]
        if datacenter_res[datacenter_res['name'] == current_center_name]['main_node'].values == \
                datacenter_res[datacenter_res['name'] == other_node]['main_node'].values:
            delay_to = datacenter_delay[
                (datacenter_delay['Node1'] == current_center_name) &
                (datacenter_delay['Node2'] == other_node)
                ]['Delay'].values
            delay_back = datacenter_delay[
                (datacenter_delay['Node1'] == other_node) &
                (datacenter_delay['Node2'] == current_center_name)
                ]['Delay'].values

            delay = delay_to + delay_back
            merged_df = pd.DataFrame(row).T
            merged_df['local_node'] = current_center_name
            merged_df['link_condition'] = delay[0]
            # print(merged_df['link_condition'])
            all_data_df = pd.concat([all_data_df, merged_df])
    # main_node = datacenter_res[datacenter_res['name'] == current_center_name]['main_node'].values
    # main_node_df = medium_df[medium_df['Data_Center_Name'] == main_node[0]]
    # for index, row in main_node_df.iterrows():
    #     other_node = row.values[0]
    #     delay_to = datacenter_delay[
    #         (datacenter_delay['Node1'] == current_center_name) &
    #         (datacenter_delay['Node2'] == other_node)
    #         ]['Delay'].values
    #     delay_back = datacenter_delay[
    #         (datacenter_delay['Node1'] == other_node) &
    #         (datacenter_delay['Node2'] == current_center_name)
    #         ]['Delay'].values
    #
    #     delay = delay_to + delay_back
    #     merged_df = pd.DataFrame(row).T
    #     merged_df['local_node'] = current_center_name
    #     merged_df['link_condition'] = delay[0]
    #     # print(merged_df['link_condition'])
    #     all_data_df = pd.concat([all_data_df, merged_df])

print(all_data_df.head(10))
all_data_df.to_csv(
    f'./datacenterinfo/all_data_centers_services_with_srv6_{large_service_num}_{medium_service_num}_{edge_service_num}.csv',
    index=False)
all_data_df.to_excel(
    f'./datacenterinfo/all_data_centers_services_with_srv6_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx',
    index=False)

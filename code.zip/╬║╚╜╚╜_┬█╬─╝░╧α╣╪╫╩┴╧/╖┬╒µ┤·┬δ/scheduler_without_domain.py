import pickle
import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import s_max, s_min, strategy_coefficient,SERVICE_RECORD_NUM

with open('bwm_weights.pkl', 'rb') as file:
    bwm_weight = pickle.load(file)
# 读取信息,并根据域内分组,创建新的存放结果的pd
service_df = pd.read_csv(f'info_without_domain_{SERVICE_RECORD_NUM}.csv')
service_grouped = service_df.groupby(['local_node', 'sid'])
schedule_result_df = pd.DataFrame()
algorithms = ['topsis', 'spotis']
custom_m = ['mtp']
all_algo = algorithms + custom_m
for name, group in service_grouped:
    # print(type(name))
    # print(name)
    # print(type(group))
    # print(group)
    # print(len(group))
    if len(group) == 1:
        for algo in all_algo:
            temp_result = group.copy()
            temp_result['algo'] = algo
            temp_result['cluster_rank_by_algo'] = 1
            schedule_result_df = pd.concat([schedule_result_df, temp_result])
    else:
        criteria_arr = group[
            ['delay', 'rate', 'cpu_availability', 'mem_availability', 'cpu', 'mem', 'link_condition']].values
        criteria_type = ['min', 'max', 'max', 'max', 'max', 'max', 'min']
        alternatives = group[['node_name']].values
        # print(type(alternatives))
        # print(alternatives)
        # print(alternatives.shape)
        # print(type(criteria_arr))
        # print(criteria_arr)
        en_weight = entropy_method(criteria_arr, criteria_type)
        print(en_weight, bwm_weight)
        my_ranks = my_topsis_method(criteria_arr, bwm_weight, criteria_type, s_min)
        # my_ranks_en = my_topsis_method(criteria_arr, en_weight, criteria_type, s_min)
        # print(type(my_ranks))
        # print(my_ranks)
        # print(my_ranks_en)
        custom_r = [my_ranks]
        values, ranks = compare_ranks_crisp(criteria_arr, en_weight, criteria_type, methods_list=algorithms,
                                            custom_methods=custom_m, custom_ranks=custom_r,
                                            strategy_coefficient=strategy_coefficient, s_min=s_min,
                                            s_max=s_max)
        # values.index = pd.Index(alternatives.flatten(), dtype='object')
        # ranks.index = pd.Index(alternatives.flatten(), dtype='object')
        # print(values)
        for method, rank_series in ranks.items():
            # print(rank_series.values)
            temp_result = group.copy()
            temp_result['algo'] = method
            temp_result['cluster_rank_by_algo'] = rank_series.values
            print(temp_result)
            schedule_result_df = pd.concat([schedule_result_df, temp_result])

schedule_result_df.to_csv(f'schedule_result_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
schedule_result_df.to_excel(f'schedule_result_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)

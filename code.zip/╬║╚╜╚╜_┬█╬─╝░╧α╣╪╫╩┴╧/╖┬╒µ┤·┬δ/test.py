import pandas as pd
import numpy as np

# 创建示例数据集
data1 = {
    'algo': ['A', 'A', 'B', 'B', 'C'],
    'success_rate': [0.8, 0.7, 0.9, 0.85, 0.78],
    'average_improvement_rate': [0.1, 0.15, 0.08, 0.1, 0.12],
    'perfect_satisfaction_rate': [0.9, 0.85, 0.88, 0.92, 0.85]
}

data2 = {
    'algo': ['B', 'C', 'A', 'B', 'C'],
    'success_rate': [0.75, 0.8, 0.85, 0.9, 0.76],
    'average_improvement_rate': [0.12, 0.1, 0.14, 0.09, 0.11],
    'perfect_satisfaction_rate': [0.87, 0.83, 0.91, 0.89, 0.82]
}

# 转换为 DataFrame
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

# 将数据集组合成一个列表
all_data = [df1, df2]

# 合并所有数据到一个 DataFrame
combined_data = pd.concat(all_data, ignore_index=True)

# 计算每个算法组的平均成功率、平均改进率和平均完美满意率
avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
avg_improvement_rate_by_algo = combined_data.groupby('algo')['average_improvement_rate'].mean().reset_index()
avg_perfect_satisfaction_rate_by_algo = combined_data.groupby('algo')['perfect_satisfaction_rate'].mean().reset_index()

# 创建一个新的 DataFrame，用平均值代替原来的数据
original_data = pd.DataFrame(columns=['algo', 'avg_success_rate', 'avg_improvement_rate', 'avg_perfect_satisfaction_rate'])

# 填充新 DataFrame
for algo in combined_data['algo'].unique():
    avg_success = avg_success_rate_by_algo.loc[avg_success_rate_by_algo['algo'] == algo, 'success_rate'].values[0]
    avg_improvement = avg_improvement_rate_by_algo.loc[avg_improvement_rate_by_algo['algo'] == algo, 'average_improvement_rate'].values[0]
    avg_perfect_satisfaction = avg_perfect_satisfaction_rate_by_algo.loc[avg_perfect_satisfaction_rate_by_algo['algo'] == algo, 'perfect_satisfaction_rate'].values[0]

    original_data = pd.concat([original_data, pd.DataFrame({
        'algo': [algo],
        'avg_success_rate': [avg_success],
        'avg_improvement_rate': [avg_improvement],
        'avg_perfect_satisfaction_rate': [avg_perfect_satisfaction],
    })], ignore_index=True)

# 打印结果
print("新的 DataFrame:")
print(original_data)

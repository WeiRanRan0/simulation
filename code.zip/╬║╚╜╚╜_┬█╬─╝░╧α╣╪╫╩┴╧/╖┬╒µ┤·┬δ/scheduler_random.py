# import pickle
# import pandas as pd
# import random
# from Parameter import SERVICE_RECORD_NUM
# import numpy as np
# from pyDecision.algorithm import bw_method, entropy_method
# from pyDecision.compare.compare import compare_ranks_crisp
# from mytopsis import *
# from Parameter import s_max, s_min, strategy_coefficient
#
# # 读取信息,并根据域内分组,创建新的存放结果的pd
# service_df = pd.read_csv(f'info_without_domain_{SERVICE_RECORD_NUM}.csv')
# service_grouped = service_df.groupby(['local_node', 'sid'])
# schedule_result_df = pd.DataFrame()
# algorithms = ['topsis']
# custom_m = ['mtp']
# default_algo = ['random']
# all_algo = algorithms + custom_m
# for name, group in service_grouped:
#     # print(type(name))
#     # print(name)
#     # print(type(group))
#     # print(group)
#     # print(len(group))
#     temp_result = group.copy()
#     temp_result['algo'] = default_algo[0]
#     temp_result['cluster_rank_by_algo'] = random.sample(range(1, len(group) + 1), len(group))
#     print(temp_result)
#     schedule_result_df = pd.concat([schedule_result_df, temp_result])
#
# schedule_result_df.to_csv(f'schedule_result_random_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
# schedule_result_df.to_excel(f'schedule_result_random_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)
import pickle
import sys
import random

import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import mic, lic, strategy_coefficient, large_service_num, medium_service_num, edge_service_num

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
file_p = './datacenterinfo/'
file_to_save = './scheduler/'


def select_weight(en_weights, bwm_weights):
    # 对主观权重进行排序并获取排序后的索引
    sorted_subjective_indices = sorted(range(len(en_weights)), key=lambda k: en_weights[k], reverse=True)
    # 对客观权重进行排序并获取排序后的索引
    sorted_objective_indices = sorted(range(len(bwm_weights)), key=lambda k: bwm_weights[k], reverse=True)

    # 比较排序后的前两名索引
    if sorted_subjective_indices[:2] == sorted_objective_indices[:2]:
        # 如果前两名索引相同，则选择客观权重
        return en_weights
    else:
        return bwm_weights


default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values

service_df = pd.read_csv(
    file_p + f'all_data_centers_services_with_cfn_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
service_grouped = service_df.groupby(['local_node', 'services_Type'])
schedule_result_df = pd.DataFrame()
s_max = list(service_df[[
    'Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity',
    'link_condition']].max())
s_min = list(service_df[[
    'Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity',
    'link_condition']].min())
with open('bwm_weights.pkl', 'rb') as file:
    bwm_weight_my = pickle.load(file)

algorithms = ['topsis']
custom_m = ['mtp']
all_algo = algorithms + custom_m
for name, group in service_grouped:
    # print(type(name))
    # print(name)
    # print(type(group))
    # print(group)
    # print(len(group))
    temp_result = group.copy()
    temp_result = temp_result.sort_values(by='link_condition')
    temp_result['algo'] = 'topsis'
    temp_result['cluster_rank_by_algo'] = temp_result['link_condition'].rank(method='first').astype(int)
    # print(temp_result.head(10))
    schedule_result_df = pd.concat([schedule_result_df, temp_result])
print('scheduler result', schedule_result_df.head(10))
# schedule_result_df.to_csv(f'schedule_result_random_without_domain_{SERVICE_RECORD_NUM}.csv', index=False)
# schedule_result_df.to_excel(f'schedule_result_random_without_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)
schedule_result_df.to_csv(
    file_to_save + f'schedule_result_dns_{weight_type}_{large_service_num}_{medium_service_num}_{edge_service_num}.csv',
    index=False)
schedule_result_df.to_excel(
    file_to_save + f'schedule_result_dns_{weight_type}_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx',
    index=False)
print('Scheduler dns with weight_type ', {weight_type}, 'is DONE')
# for name, group in service_grouped:
#     if len(group) == 1:
#         for algo in all_algo:
#             temp_result = group.copy()
#             temp_result['algo'] = algo
#             temp_result['cluster_rank_by_algo'] = 1
#             schedule_result_df = pd.concat([schedule_result_df, temp_result])
#     else:
#         criteria_arr = group[
#             ['Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity',
#              'link_condition']].values
#         criteria_type = ['min', 'max', 'max', 'max', 'max', 'max', 'max', 'min']
#         alternatives = group[['Data_Center_Name']].values
#         n = criteria_arr.shape[1]
#         selected_weight = np.ones(n) / n
#         if weight_type == 'en':
#             en_weight = entropy_method(criteria_arr, criteria_type)
#             selected_weight = en_weight
#         elif weight_type == 'my_bwm':
#             selected_weight = bwm_weight_my
#         # elif weight_type == 'enbwm':
#         #     en_weight = entropy_method(criteria_arr, criteria_type)
#         #     selected_weight = en_to_bwm_weight(en_weight)
#         # elif weight_type == 'en_and_my':
#         #     en_weight = entropy_method(criteria_arr, criteria_type)
#         #     selected_weight = 0.5 * (en_weight + bwm_weight_my)
#         # elif weight_type == 'mix_bwm':
#         #     en_weight = entropy_method(criteria_arr, criteria_type)
#         #     selected_weight = mix_mic_lic(en_weight, mic, lic)
#         elif weight_type == 'choice':
#             en_weight = entropy_method(criteria_arr, criteria_type)
#             selected_weight = select_weight(en_weight, bwm_weight_my)
#         # w_max = en_weight.max()
#         # w_min = en_weight.min()
#         #
#         # # 步骤3：生成MIC矩阵
#         # MIC = np.ceil(w_max / en_weight).clip(max=9).astype(int)
#         #
#         # # 步骤4：生成LIC矩阵
#         # LIC = np.ceil(en_weight / w_min).clip(max=9).astype(int)
#         # m = np.ceil((MIC + mic) / 2).astype(int)
#         # l = np.ceil((LIC + lic) / 2).astype(int)
#         # bwm_weight = bw_method(m, l)
#         # bwm_weight = (en_weight + bwm_weight_my)/2
#         # print(en_weight, bwm_weight_my)
#
#         my_ranks = my_topsis_method(criteria_arr, selected_weight, criteria_type, s_min)
#         custom_r = [my_ranks]
#         values, ranks = compare_ranks_crisp(criteria_arr, selected_weight, criteria_type, methods_list=algorithms,
#                                             custom_methods=custom_m, custom_ranks=custom_r,
#                                             strategy_coefficient=strategy_coefficient, s_min=s_min,
#                                             s_max=s_max)
#         for method, rank_series in ranks.items():
#             # print(rank_series.values)
#             temp_result = group.copy()
#             temp_result['algo'] = method
#             temp_result['cluster_rank_by_algo'] = rank_series.values
#             # print(temp_result)
#             schedule_result_df = pd.concat([schedule_result_df, temp_result])



from Parameter import *
from function import *
import pandas as pd


def generate_and_save_links_and_domains(num_nodes, INTERVAL):
    out_csv = 'node_delays_and_domains.csv'
    out_excel = 'node_delays_and_domains.xlsx'
    all_data = []

    for i in range(num_nodes):
        for j in range(num_nodes):
            delay = generate_link_btw_network_nodes(i, j)
            domain = generate_domain_btw_network_nodes(i, j, INTERVAL)
            all_data.append({'local_node': i, 'other_node': j, 'Delay': delay, 'Domain': domain})
    df_all = pd.DataFrame(all_data)
    df_all.to_csv(out_csv, index=False)
    df_all.to_excel(out_excel, index=False)


generate_and_save_links_and_domains(NETWORK_NODE_NUM, DOMAIN_INTERVAL)

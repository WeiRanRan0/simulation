import json
import random
import pandas as pd

# 定义DataCenter类
class DataCenter:
    def __init__(self, name, server_num, server_ids):
        self.name = name
        self.server_num = server_num
        self.server_list = server_ids
        self.main_node = None

# 定义Request类
class Request:
    def __init__(self, data_center_name, request_type, delay_requirement, delay_level, success_rate_requirement, success_rate_level):
        self.data_center_name = data_center_name
        self.request_type = request_type
        self.delay_requirement = delay_requirement
        self.delay_level = delay_level
        self.success_rate_requirement = success_rate_requirement
        self.success_rate_level = success_rate_level

# 读取请求数量配置
with open('num_requests.json', 'r') as json_file:
    num_requests_dict = json.load(json_file)

# 生成请求的逻辑
def generate_requests(data_centers, num_requests_dict):
    requests = []

    for center in data_centers:
        num_requests = num_requests_dict[center.name]
        for _ in range(num_requests):
            # 加权随机选择请求类型
            if center.name.startswith('Edge'):
                request_type = random.choices(range(1, 51), weights=[10]*10 + [5]*30 + [2]*10, k=1)[0]
            elif center.name.startswith('Medium'):
                request_type = random.choices(range(1, 51), weights=[2]*10 + [10]*30 + [5]*10, k=1)[0]
            else:  # Large data center
                request_type = random.choices(range(1, 51), weights=[2]*10 + [5]*30 + [10]*10, k=1)[0]

            # 根据请求类型设置时延和成功率
            if 1 <= request_type <= 10:
                delay_requirement = random.uniform(0, 10)
                delay_level = 0
                success_rate_requirement = random.uniform(95, 100)
                success_rate_level = 0
            elif 11 <= request_type <= 40:
                delay_requirement = random.uniform(10, 50)
                delay_level = 1 if random.uniform(90, 100) < 95 else 0
                success_rate_requirement = random.uniform(90, 100)
                success_rate_level = 1 if success_rate_requirement < 95 else 0
            else:  # 41 <= request_type <= 50
                delay_requirement = random.uniform(50, 100)
                delay_level = 3 if random.uniform(80, 100) < 85 else 2
                success_rate_requirement = random.uniform(80, 100)
                success_rate_level = 3 if success_rate_requirement < 85 else 2

            request = Request(center.name, request_type, delay_requirement, delay_level, success_rate_requirement, success_rate_level)
            requests.append(request)

    return requests

# 创建数据中心示例
Large_num = 3
Medium_num = 9
Edge_num = 45

random.seed(38)
server_event_usage_df = pd.read_excel('server_event_usage.xlsx')

large_centers = [DataCenter(f"Large{i + 1}", 40, server_event_usage_df.iloc[i * 40: (i + 1) * 40, 0].tolist()) for i in range(Large_num)]
medium_centers = [DataCenter(f"Medium{i + 1}", 20, server_event_usage_df.iloc[Large_num * 40 + i * 20: (i + 1) * 20, 0].tolist()) for i in range(Medium_num)]
edge_centers = [DataCenter(f"Edge{i + 1}", 10, server_event_usage_df.iloc[Large_num * 40 + Medium_num * 20 + i * 10: (i + 1) * 10, 0].tolist()) for i in range(Edge_num)]

all_centers = large_centers + medium_centers + edge_centers

# 生成请求
requests = generate_requests(all_centers, num_requests_dict)

# 将请求转换为DataFrame并保存为CSV
requests_df = pd.DataFrame([vars(req) for req in requests])
requests_df.columns = ['Data Center Name', 'Request Type', 'Delay Requirement', 'Delay Level', 'Success Rate Requirement', 'Success Rate Level']
requests_df.to_csv('requests.csv', index=False)

print(requests_df)

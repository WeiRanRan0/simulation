from function import *
from Parameter import *
import pandas as pd
import numpy as np
import random


class ServiceRecord:
    def __init__(self, sid: int, datafile, file_data_num: int, Cluster_Network: list):
        self.sid = sid
        self.node_name, self.network_node = random.choice(Cluster_Network)
        data_temp = pd.read_excel(datafile).iloc[:file_data_num, :]
        random_row_index = np.random.randint(0, file_data_num)  # 生成随机行索引
        random_row_data = data_temp.iloc[random_row_index]  # 获取随机行数据
        self.delay = random_row_data['time']
        self.delay_level = delay_level(self.delay)
        self.rate = random.randint(80, 100)
        self.rate_level = rate_level(self.rate)


def generate_and_save_service_file(num_records: int):
    output_file_csv = f'service_record_{num_records}.csv'  # Define the output CSV file name
    output_file_excel = f'service_record_{num_records}.xlsx'  # Define the output Excel file name
    existing_records = set()  # Used to store existing records (sid, delay_level, rate_level, node_name)
    data = []  # List to store data for DataFrame
    count = 0  # Counter for the number of generated records

    while count < num_records:
        # Generate a new record
        record = ServiceRecord(generate_sid(), 'data.xlsx', FILE_NUM, CLUSTER_NETWORK_CONNECT)
        key = (record.sid, record.delay, record.rate, record.node_name)

        # If the key already exists, skip the record
        if key in existing_records:
            continue

        # Otherwise, add the record to the existing records set and append its data to the list
        existing_records.add(key)
        data.append([record.sid, record.node_name, record.network_node, record.delay, record.delay_level,
                     record.rate, record.rate_level])
        count += 1

    # Create a DataFrame from the data list with specified columns
    df = pd.DataFrame(data, columns=['sid', 'node_name', 'network_node', 'delay', 'delay_level', 'rate', 'rate_level'])

    # Save the DataFrame as a CSV file
    df.to_csv(output_file_csv, index=False)
    df.to_excel(output_file_excel, index=False)


# Generate and save the DataFrame as a CSV file
generate_and_save_service_file(2000)


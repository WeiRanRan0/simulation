from datetime import datetime
import pandas as pd
from Parameter import top_k, DOMAIN_INTERVAL, SERVICE_RECORD_NUM, REQUEST_NUM
import numpy as np
from tabulate import tabulate
import random
import json
import os
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from queue import Queue, Empty
import threading

# 读取需求，先根据sid找出具有所有这个服务的域，然后再提取需求自己的域，优先从本域中选取，本域中没有，再去别的域找，最后都没有，失败
rst = pd.read_csv(f'requests_data{REQUEST_NUM}_True.csv')
svs = pd.read_csv(f'schedule_result_with_domain_{SERVICE_RECORD_NUM}.csv')
node_delay = pd.read_csv('node_delays_and_domains.csv')
match_result_with_domain = pd.DataFrame()
failed_rst = pd.DataFrame()
rst_group_by_network_node = rst.groupby(['node_position'])
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)
folder_path = f'rst{REQUEST_NUM}_service{SERVICE_RECORD_NUM}/'
if not os.path.exists(folder_path):
    os.makedirs(folder_path)

for node_num, requests in rst_group_by_network_node:
    for index, request in requests.iterrows():
        rst_sid = request['rst_sid']
        rst_domain = request['domain']
        rst_delay_level = request['rst_delay_level']
        rst_rate_level = request['rst_rate_level']
        candidates = svs[(svs['sid'] == rst_sid) &
                         (svs['domain'] == rst_domain) &
                         (svs['local_node'] == node_num) &
                         (svs['delay_level'] <= rst_delay_level)]
        # print('original can')
        # print(candidates, "\n")
        if not candidates.empty:
            max_delay_value = candidates['delay_level'].max()
            # print('in:compare', rst_delay_level, max_delay_value, "\n")
            select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                           (candidates['rate_level'] <= rst_rate_level)]
            if not select_candidates.empty:
                max_rate_value = select_candidates['rate_level'].max()
                select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                               (candidates['rate_level'] == max_rate_value)]
                # print('in:full match')
                # print(select_candidates, "\n")
            else:
                temp_candidates = candidates[(candidates['delay_level'] == max_delay_value)]
                min_rate_value = temp_candidates['rate_level'].min()
                select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                               (candidates['rate_level'] == min_rate_value)]
                # print('in:delay match but rate not')
                # print(select_candidates, "\n")
            for algo in select_candidates['algo'].unique():
                candidates_by_algo = select_candidates[select_candidates['algo'] == algo]
                # print('in:candidates_by_algo')
                # print(candidates_by_algo, "\n")
                candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                if len(candidates_by_algo_sorted) > 1:
                    node_by_algo_result = candidates_by_algo_sorted.head(top_k).sample(n=1)
                    # print('len node by algo',len(node_by_algo_result))
                    # print(node_by_algo_result)
                    temp_row = pd.DataFrame(request).T
                    node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                    node_by_algo_result.reset_index(drop=True, inplace=True)
                    temp_row.reset_index(drop=True, inplace=True)
                    temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                    # print('len',len(temp_contact))
                    # print(temp_contact)
                    match_result_with_domain = pd.concat(
                        [match_result_with_domain, temp_contact])
                else:
                    node_by_algo_result = candidates_by_algo_sorted
                    # print('in:node_by_algo_result')
                    # print(node_by_algo_result, "\n")
                    temp_row = pd.DataFrame(request).T
                    node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                    node_by_algo_result.reset_index(drop=True, inplace=True)
                    temp_row.reset_index(drop=True, inplace=True)
                    temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                    match_result_with_domain = pd.concat(
                        [match_result_with_domain, temp_contact])
                    # print('in:match_result_with_domain')
                    # print(match_result_with_domain, "\n")
        else:  # 放宽要求，看域内是否有该sid
            candidates = svs[(svs['sid'] == rst_sid) &
                             (svs['domain'] == rst_domain) &
                             (svs['local_node'] == node_num)]
            if not candidates.empty:  # 本域内有
                min_delay_value = candidates['delay_level'].min()
                select_candidates = candidates[(candidates['delay_level'] == min_delay_value)]
                min_rate_value = select_candidates['rate_level'].min()
                select_candidates = candidates[(candidates['delay_level'] == min_delay_value) &
                                               (candidates['rate_level'] == min_rate_value)]
                for algo in select_candidates['algo'].unique():
                    candidates_by_algo = select_candidates[select_candidates['algo'] == algo]
                    # print('in_relax:candidates_by_algo')
                    # print(candidates_by_algo, "\n")
                    candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                    if len(candidates_by_algo_sorted) > 1:
                        node_by_algo_result = candidates_by_algo_sorted.head(top_k).sample(n=1)
                        temp_row = pd.DataFrame(request).T
                        node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                        node_by_algo_result.reset_index(drop=True, inplace=True)
                        temp_row.reset_index(drop=True, inplace=True)
                        temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                        match_result_with_domain = pd.concat(
                            [match_result_with_domain, temp_contact])
                    else:
                        node_by_algo_result = candidates_by_algo_sorted.head(1).sample(n=1)
                        # print('in_relax:node_by_algo_result')
                        # print(node_by_algo_result, "\n")
                        temp_row = pd.DataFrame(request).T
                        node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                        node_by_algo_result.reset_index(drop=True, inplace=True)
                        temp_row.reset_index(drop=True, inplace=True)
                        temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                        match_result_with_domain = pd.concat(
                            [match_result_with_domain, temp_contact])

                        # print('in_relax:match_result_with_domain')
                        # print(match_result_with_domain, "\n")
            # 本域内没有sid，去别的域找
            else:
                candidates = svs[(svs['sid'] == rst_sid) &
                                 (svs['delay_level'] <= rst_delay_level)]
                # print('out_candidates')
                # print(candidates, "\n")
                if not candidates.empty:
                    domain_node = candidates['local_node'].unique()
                    delays_btw_domain = pd.DataFrame()
                    for other_nodes in domain_node:
                        temp_delay = node_delay[(node_delay['local_node'] == node_num) &
                                                (node_delay['other_node'] == other_nodes)]
                        delays_btw_domain = pd.concat([delays_btw_domain, temp_delay])
                    # print("out:delay")
                    # print(delays_btw_domain, "\n")
                    min_delay_index = delays_btw_domain['Delay'].idxmin()
                    # print("out:min_delay_index")
                    # print(min_delay_index, "\n")
                    min_delay_row = delays_btw_domain.loc[min_delay_index]
                    # print("out:min_delay_row")
                    # print(min_delay_row, "\n")
                    domain_choice = min_delay_row['other_node'] // DOMAIN_INTERVAL
                    # print('domain_choice')
                    # print(domain_choice)
                    domain_choice_candidates = candidates[(candidates['domain'] == domain_choice)]

                    max_delay_value = domain_choice_candidates['delay_level'].max()
                    # print('out:compare', rst_delay_level, max_delay_value, "\n")
                    select_candidates = domain_choice_candidates[
                        (domain_choice_candidates['delay_level'] == max_delay_value) &
                        (domain_choice_candidates['rate_level'] <= rst_rate_level)]
                    if not select_candidates.empty:
                        max_rate_value = select_candidates['rate_level'].max()
                        select_candidates = domain_choice_candidates[
                            (domain_choice_candidates['delay_level'] == max_delay_value) &
                            (domain_choice_candidates['rate_level'] == max_rate_value)]
                        # print('out:full match')
                        # print(select_candidates, "\n")
                    else:
                        temp_candidates = domain_choice_candidates[
                            (domain_choice_candidates['delay_level'] == max_delay_value)]
                        min_rate_value = temp_candidates['rate_level'].min()
                        select_candidates = domain_choice_candidates[
                            (domain_choice_candidates['delay_level'] == max_delay_value) &
                            (domain_choice_candidates['rate_level'] == min_rate_value)]
                        # print('out:delay match but rate not')
                        # print(select_candidates, "\n")
                    for algo in select_candidates['algo'].unique():
                        candidates_by_algo = select_candidates[select_candidates['algo'] == algo]
                        # print('out:candidates_by_algo')
                        # print(candidates_by_algo, "\n")
                        candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                        if len(candidates_by_algo_sorted) > 1:
                            node_by_algo_result = candidates_by_algo_sorted.head(top_k).sample(n=1)
                            temp_row = pd.DataFrame(request).T
                            node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                            node_by_algo_result.reset_index(drop=True, inplace=True)
                            temp_row.reset_index(drop=True, inplace=True)
                            temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                            match_result_with_domain = pd.concat(
                                [match_result_with_domain, temp_contact])
                        else:
                            node_by_algo_result = candidates_by_algo_sorted
                            print('out:node_by_algo_result')
                            print(node_by_algo_result, "\n")
                            temp_row = pd.DataFrame(request).T
                            node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                            node_by_algo_result.reset_index(drop=True, inplace=True)
                            temp_row.reset_index(drop=True, inplace=True)
                            temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                            match_result_with_domain = pd.concat(
                                [match_result_with_domain, temp_contact])
                            # print('out:match_result_with_domain')
                            # print(match_result_with_domain, "\n")
                else:  # 外域有，但是没有满足该时延等级的，继续放松要求
                    candidates = svs[(svs['sid'] == rst_sid)]
                    if not candidates.empty:
                        min_delay_value = candidates['delay_level'].min()
                        select_candidates = candidates[(candidates['delay_level'] == min_delay_value)]
                        min_rate_value = select_candidates['rate_level'].min()
                        select_candidates = candidates[(candidates['delay_level'] == min_delay_value) &
                                                       (candidates['rate_level'] == min_rate_value)]
                        for algo in select_candidates['algo'].unique():
                            candidates_by_algo = select_candidates[select_candidates['algo'] == algo]
                            # print('out_relax:candidates_by_algo')
                            # print(candidates_by_algo, "\n")
                            candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                            if len(candidates_by_algo_sorted) > 1:
                                node_by_algo_result = candidates_by_algo_sorted.head(top_k).sample(n=1)
                                temp_row = pd.DataFrame(request).T
                                node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                                node_by_algo_result.reset_index(drop=True, inplace=True)
                                temp_row.reset_index(drop=True, inplace=True)
                                temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                                match_result_with_domain = pd.concat(
                                    [match_result_with_domain, temp_contact])

                            else:
                                node_by_algo_result = candidates_by_algo_sorted
                                # print('out_relax:node_by_algo_result')
                                # print(node_by_algo_result, "\n")
                                temp_row = pd.DataFrame(request).T
                                node_by_algo_result.rename(columns={'domain': 'rst_choice_domain'}, inplace=True)
                                node_by_algo_result.reset_index(drop=True, inplace=True)
                                temp_row.reset_index(drop=True, inplace=True)
                                temp_contact = pd.concat([temp_row, node_by_algo_result], axis=1)
                                match_result_with_domain = pd.concat(
                                    [match_result_with_domain, temp_contact])

                                # print('out_relax:match_result_with_domain')
                                # print(match_result_with_domain, "\n")
                    else:
                        failed_rst = pd.concat([failed_rst, pd.DataFrame(request).T])

match_result_with_domain.to_csv(folder_path + f'match_result_with_domain_{SERVICE_RECORD_NUM}.csv', index=False)
match_result_with_domain.to_excel(folder_path + f'match_result_with_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)

failed_rst.to_csv(folder_path + f'failed_rst_with_domain_{SERVICE_RECORD_NUM}.csv', index=False)
failed_rst.to_excel(folder_path + f'failed_rst_with_domain_{SERVICE_RECORD_NUM}.xlsx', index=False)

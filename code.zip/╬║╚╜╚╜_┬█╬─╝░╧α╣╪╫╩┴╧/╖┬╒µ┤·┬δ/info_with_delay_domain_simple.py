import pickle
import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import Large_num, Medium_num, Edge_num, large_service_num,medium_service_num,edge_service_num

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

# 读取两个pd 并进行拼接
service_file_path = './service/'
service_df = pd.read_csv(service_file_path + f'data_center_services_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
datacenter_delay = pd.read_csv('datacenterinfo/datacenters_delay_info.csv')
datacenter_res = pd.read_csv('datacenterinfo/data_centers_info.csv')
all_data_df = pd.DataFrame()
for i in range(Large_num):
    # 当前大型数据中心的名字
    current_center_name = f'Large{i + 1}'

    # 获取当前数据中心的服务信息
    current_center_services = service_df[service_df['Data_Center_Name'] == current_center_name]
    delay = datacenter_delay[
        (datacenter_delay['Node1'] == current_center_name) &
        (datacenter_delay['Node2'] == current_center_name)
        ]['Delay'].values
    print(delay[0])
    current_center_services = current_center_services.assign(link_condition=delay[0], local_node=current_center_name)
    # 为当前大型数据中心添加其他大型数据中心的服务信息
    for j in range(Large_num):
        if i != j:
            other_center_name = f'Large{j + 1}'
            other_center_services = service_df[service_df['Data_Center_Name'] == other_center_name]

            # 添加时延信息
            delay = datacenter_delay[
                (datacenter_delay['Node1'] == current_center_name) &
                (datacenter_delay['Node2'] == other_center_name)
                ]['Delay'].values
            other_center_services = other_center_services.assign(link_condition=delay[0],
                                                                 local_node=current_center_name)

            # 合并服务信息
            all_data_df = pd.concat([all_data_df, other_center_services], ignore_index=True)

    # 将当前数据中心的服务信息添加到总 DataFrame 中
    all_data_df = pd.concat([all_data_df, current_center_services], ignore_index=True)
for i in range(Medium_num):
    # 当前大型数据中心的名字
    current_center_name = f'Medium{i + 1}'

    # 获取当前数据中心的服务信息
    current_center_services = service_df[service_df['Data_Center_Name'] == current_center_name]
    delay = datacenter_delay[
        (datacenter_delay['Node1'] == current_center_name) &
        (datacenter_delay['Node2'] == current_center_name)
        ]['Delay'].values
    print(delay[0])
    current_center_services = current_center_services.assign(link_condition=delay[0], local_node=current_center_name)
    # 为当前大型数据中心添加其他大型数据中心的服务信息
    for j in range(Medium_num):
        if i != j:
            other_center_name = f'Medium{j + 1}'
            other_center_services = service_df[service_df['Data_Center_Name'] == other_center_name]

            # 添加时延信息
            delay = datacenter_delay[
                (datacenter_delay['Node1'] == current_center_name) &
                (datacenter_delay['Node2'] == other_center_name)
                ]['Delay'].values
            other_center_services = other_center_services.assign(link_condition=delay[0],
                                                                 local_node=current_center_name)

            # 合并服务信息
            all_data_df = pd.concat([all_data_df, other_center_services], ignore_index=True)

    # 将当前数据中心的服务信息添加到总 DataFrame 中
    all_data_df = pd.concat([all_data_df, current_center_services], ignore_index=True)
for i in range(Edge_num):
    # 当前大型数据中心的名字
    current_center_name = f'Edge{i + 1}'

    # 获取当前数据中心的服务信息
    current_center_services = service_df[service_df['Data_Center_Name'] == current_center_name]
    delay = datacenter_delay[
        (datacenter_delay['Node1'] == current_center_name) &
        (datacenter_delay['Node2'] == current_center_name)
        ]['Delay'].values
    print(delay[0])
    current_center_services = current_center_services.assign(link_condition=delay[0], local_node=current_center_name)
    # 为当前大型数据中心添加其他大型数据中心的服务信息
    for j in range(Edge_num):
        if i != j:
            other_center_name = f'Edge{j + 1}'
            other_center_services = service_df[service_df['Data_Center_Name'] == other_center_name]

            # 添加时延信息
            delay = datacenter_delay[
                (datacenter_delay['Node1'] == current_center_name) &
                (datacenter_delay['Node2'] == other_center_name)
                ]['Delay'].values
            other_center_services = other_center_services.assign(link_condition=delay[0],
                                                                 local_node=current_center_name)

            # 合并服务信息
            all_data_df = pd.concat([all_data_df, other_center_services], ignore_index=True)

    # 将当前数据中心的服务信息添加到总 DataFrame 中
    all_data_df = pd.concat([all_data_df, current_center_services], ignore_index=True)
# 打印结果 DataFrame
print(all_data_df.head(10))
result_df = pd.merge(all_data_df, datacenter_res, left_on='Data_Center_Name', right_on='name')
# 将结果保存到 CSV 文件
print(result_df.head(10))
result_df.to_csv(
    f'./datacenterinfo/all_data_centers_services_with_simple_{large_service_num}_{medium_service_num}_{edge_service_num}.csv',
    index=False)
result_df.to_excel(
    f'./datacenterinfo/all_data_centers_services_with_simple_{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx',
    index=False)



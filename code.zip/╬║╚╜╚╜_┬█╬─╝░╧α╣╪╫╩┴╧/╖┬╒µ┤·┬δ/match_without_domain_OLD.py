import pandas as pd
from Parameter import top_k

rst = pd.read_csv('requests_data100_True.csv')
svs = pd.read_csv('schedule_result_without_domain.csv')
match_result_without_domain = pd.DataFrame()
failed_rst_without_domain = pd.DataFrame()
rst_group_by_network_node = rst.groupby(['node_position'])
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)

for node_num, requests in rst_group_by_network_node:
    for index, request in requests.iterrows():
        rst_sid = request['rst_sid']
        rst_delay_level = request['rst_delay_level']
        rst_rate_level = request['rst_rate_level']
        candidates = svs[(svs['sid'] == rst_sid) &
                         (svs['local_node'] == node_num) &
                         (svs['delay_level'] <= rst_delay_level)]
        # print('original can without domain')
        # print(candidates, "\n")
        if not candidates.empty:
            max_delay_value = candidates['delay_level'].max()
            # print('without_d_compare', rst_delay_level, max_delay_value, "\n")
            select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                           (candidates['rate_level'] <= rst_rate_level)]
            if not select_candidates.empty:
                max_rate_value = select_candidates['rate_level'].max()
                select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                               (candidates['rate_level'] == max_rate_value)]
                # print('without_d:full match')
                # print(select_candidates, "\n")
            else:
                temp_candidates = candidates[(candidates['delay_level'] == max_delay_value)]
                min_rate_value = temp_candidates['rate_level'].min()
                select_candidates = candidates[(candidates['delay_level'] == max_delay_value) &
                                               (candidates['rate_level'] == min_rate_value)]
                # print('without_d:delay match but rate not')
                # print(select_candidates, "\n")
            for algo in select_candidates['algo'].unique():
                candidates_by_algo = select_candidates[select_candidates['algo'] == algo]
                # print('in:candidates_by_algo')
                # print(candidates_by_algo, "\n")
                candidates_by_algo_sorted = candidates_by_algo.sort_values(by='cluster_rank_by_algo')
                if len(candidates_by_algo_sorted) > 1:
                    node_by_algo_result = candidates_by_algo_sorted.head(top_k).sample(n=1)
                    match_result_without_domain = pd.concat([match_result_without_domain, node_by_algo_result])
                else:
                    node_by_algo_result = candidates_by_algo_sorted
                    # print('in:node_by_algo_result')
                    # print(node_by_algo_result, "\n")
                    match_result_without_domain = pd.concat([match_result_without_domain, node_by_algo_result])
                    # print('in:match_result_with_domain')
                    # print(match_result_without_domain, "\n")
        else:
            failed_rst_without_domain = pd.concat([failed_rst_without_domain, pd.DataFrame(request).T])
match_result_without_domain.to_csv('match_result_without_domain_OLD.csv', index=False)
match_result_without_domain.to_excel('match_result_without_domain_OLD.xlsx', index=False)
failed_rst_without_domain.to_csv('failed_rst_without_domain_OLD.csv', index=False)
failed_rst_without_domain.to_excel('failed_rst_without_domain_OLD.xlsx', index=False)
import os

py_files_rst_gen = ['datacenter_per_requests_num.py',
                    'datacenter_request_info_gen.py']

py_files_com1_scheduler = [
    'match_with_delay_complicated.py',
    'satisfaction_rate_com1.py',
    'resource_analy_with_delay_domain_complicated1.py',
    'satisfaction_rate_com1_with_resource.py',
    'balance_analy_com1.py'
]

py_files_com2_scheduler = [
    'match_with_delay_complicated22.py',
    'satisfaction_rate_com22.py',
    'resource_analy_with_delay_domain_complicated22.py',
    'satisfaction_rate_com22_with_resource.py',
    'balance_analy_com22.py'
]
py_files_cfn_scheduler = [
    'match_with_cfn.py',
    'satisfaction_rate_cfn.py',
    'resource_analy_with_cfn.py',
    'satisfaction_rate_cfn_with_resource.py',
    'balance_analy_cfn.py'
]
py_files_srv6_scheduler = [
    'match_with_srv6.py',
    'resource_analy_with_srv6.py',
    'satisfaction_rate_srv6_with_resource.py',
    'balance_analy_srv6.py'
]
py_files_dns_scheduler = [
    'match_with_random.py',
    'resource_analy_with_random.py',
    'satisfaction_rate_dns_with_resource.py',
    'balance_analy_random.py'
]
num = 10
algo_list = ['my_bwm', 'en']
algo_cfn = 'en'
# for i in range(len(algo_list)):
# os.system(f"python scheduler_with_delay_complicated2.py {algo_list[i]}")
# os.system(f"python scheduler_with_delay_complicated.py {algo_list[i]}")
#
#
#
# os.system(f"python scheduler_with_cfn.py {algo_cfn}")

for i in range(num):
    for py_files in py_files_rst_gen:
        os.system(f"python {py_files} {algo_cfn} {i}")

    # for py_files in py_files_com2_scheduler:
    #     for j in range(len(algo_list)):
    #         os.system(f"python {py_files} {algo_list[j]} {i}")
    #
    # for py_files in py_files_com1_scheduler:
    #     for j in range(len(algo_list)):
    #         os.system(f"python {py_files} {algo_list[j]} {i}")
    #
    # for py_files in py_files_cfn_scheduler:
    #     os.system(f"python {py_files} {algo_cfn} {i}")
    # for py_files in py_files_dns_scheduler:
    #     for j in range(len(algo_list)):
    #         os.system(f"python {py_files} {algo_list[j]} {i}")
        # os.system(f"python {py_files} {algo_list[5]} {i}")
        # os.system(f"python {py_files} {algo_list[1]} {i}")

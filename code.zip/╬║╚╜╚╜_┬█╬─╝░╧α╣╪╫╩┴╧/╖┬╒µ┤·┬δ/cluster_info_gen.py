from function import *
from Parameter import *
import pandas as pd
import numpy as np
import random


class ClusterRecord:
    def __init__(self, Cluster_Network: tuple, Node_Resource_info: list):
        self.node_name, self.network_node = Cluster_Network
        self.cpu_all, self.mem_all = random.choice(Node_Resource_info)
        self.cpu_availability = hash_to_range("cpu_availability" + f"{self.node_name}", 0.3, 0.99)
        self.mem_availability = hash_to_range("mem_availability" + f"{self.node_name}", 0.3, 0.99)
        self.cpu = self.cpu_all * self.cpu_availability
        self.mem = self.mem_all * self.mem_availability
        self.domain = self.network_node // DOMAIN_INTERVAL


def generate_and_save_cluster_file(cn: list, nri: list):
    output_cluster_csv = f'cluster_record.csv'  # Define the output CSV file name
    output_cluster_excel = f'cluster_record.xlsx'  # Define the output Excel file nam
    data = []  # List to store data for DataFrame

    for item in cn:
        # Generate a new record
        record = ClusterRecord(item, nri)
        data.append([record.node_name, record.network_node,record.domain, record.cpu_all, record.mem_all, record.cpu_availability,
                     record.mem_availability, record.cpu, record.mem])

    # Create a DataFrame from the data list with specified columns
    df = pd.DataFrame(data, columns=['node_name', 'network_node','domain', 'cpu_all', 'mem_all', 'cpu_availability',
                                     'mem_availability', 'cpu', 'mem'])

    # Save the DataFrame as a CSV file
    df.to_csv(output_cluster_csv, index=False)
    df.to_excel(output_cluster_excel, index=False)


generate_and_save_cluster_file(CLUSTER_NETWORK_CONNECT, NODE_RESOURCE)

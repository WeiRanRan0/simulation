import pandas as pd
import random
from Parameter import Large_num, Medium_num, Edge_num


class DataCenter:
    def __init__(self, name, server_num, server_ids):
        self.name = name
        self.server_num = server_num
        self.server_list = server_ids
        self.main_node = None


delay_info = []
large_centers = [DataCenter(f"Large{i + 1}", 40, []) for i in range(Large_num)]
medium_centers = [DataCenter(f"Medium{i + 1}", 20, []) for i in range(Medium_num)]
edge_centers = [DataCenter(f"Edge{i + 1}", 10, []) for i in range(Edge_num)]
# 遍历所有大型数据中心
for i in range(len(large_centers)):
    for j in range(len(large_centers)):
        if i == j:
            delay = random.uniform(5, 20)  # 自己和自己的时延为0
        else:
            delay = random.uniform(5, 20)  # 与其他大型数据中心的时延为5-20
        delay_info.append({
            "Node1": large_centers[i].name,
            "Node2": large_centers[j].name,
            "Delay": delay
        })

for i, center1 in enumerate(medium_centers):
    for j, center2 in enumerate(medium_centers):
        if i == j:
            delay = random.uniform(1, 5)
        elif center1.main_node == center2.main_node:
            delay = random.uniform(1, 5)
        else:
            temp = [item['Delay'] for item in delay_info if item['Node1'] == center1.main_node and item[
                'Node2'] == center2.main_node]  # 不同主节点的时延可以是None或其他值，根据需要调整
            delay = temp[0]
            # print(type(delay))
        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay
        })

for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(edge_centers):
        if i == j:
            delay = random.uniform(0, 1)
        elif center1.main_node == center2.main_node:
            delay = random.uniform(0, 1)
        else:
            temp = [item['Delay'] for item in delay_info if
                    item['Node1'] == center1.main_node and item['Node2'] == center2.main_node]
            # print(type(temp))
            # print(temp[0])
            delay = temp[0]
        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay
        })

for center in medium_centers:
    delay_info.append({
        "Node1": center.name,
        "Node2": center.main_node,
        "Delay": random.uniform(5, 15)
    })
    # 反向延迟信息
    delay_info.append({
        "Node1": center.main_node,
        "Node2": center.name,
        "Delay": random.uniform(5, 15)
    })
for center in edge_centers:
    delay_info.append({
        "Node1": center.name,
        "Node2": center.main_node,
        "Delay": random.uniform(1, 5)
    })
    # 反向延迟信息
    delay_info.append({
        "Node1": center.main_node,
        "Node2": center.name,
        "Delay": random.uniform(1, 5)
    })

for i, center1 in enumerate(medium_centers):
    for j, center2 in enumerate(large_centers):
        if center1.main_node != center2.name:
            delay_value_to_l = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)
            delay_value_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)

            delay_info.append({
                "Node1": center1.name,
                "Node2": center2.name,
                "Delay": delay_value_to_main + delay_value_to_l
            })
            delay_value_in_l = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
            delay_value_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

            delay_info.append({
                "Node1": center2.name,
                "Node2": center1.name,
                "Delay": delay_value_in_l + delay_value_in_main
            })

for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(medium_centers):
        if center1.main_node != center2.name:
            delay_value_to_m = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)
            delay_value_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)

            delay_info.append({
                "Node1": center1.name,
                "Node2": center2.name,
                "Delay": delay_value_to_main + delay_value_to_m
            })
            delay_value_in_m = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
            delay_value_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

            delay_info.append({
                "Node1": center2.name,
                "Node2": center1.name,
                "Delay": delay_value_in_m + delay_value_in_main
            })
for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(large_centers):
        delay_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                             delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)
        delay_to_large = next(delay_dict["Delay"] for delay_dict in delay_info if
                              delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)

        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay_to_main + delay_to_large
        })
        delay_in_large = next(delay_dict["Delay"] for delay_dict in delay_info if
                              delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
        delay_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                             delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

        delay_info.append({
            "Node1": center2.name,
            "Node2": center1.name,
            "Delay": delay_in_main + delay_in_large
        })

# for i, center1 in enumerate(medium_centers):
#     for j, center2 in enumerate(large_centers):
#         if center1.main_node != center2.name:
#             delay_value_l = next(delay_dict["Delay"] for delay_dict in delay_info if
#                                  delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)
#             delay_value_m = next(delay_dict["Delay"] for delay_dict in delay_info if
#                                  delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center2.name)
#
#             delay_info.append({
#                 "Node1": center1.name,
#                 "Node2": center2.name,
#                 "Delay": delay_value_l + delay_value_m
#             })


delay_df = pd.DataFrame(delay_info)
delay_df.to_csv('./datacenterinfo/datacenters_delay_info.csv', index=False)
delay_df.to_excel('./datacenterinfo/datacenters_delay_info.xlsx', index=False)
print("大型数据中心间时延信息已保存到 datacenters_delay_info.csv 文件中")

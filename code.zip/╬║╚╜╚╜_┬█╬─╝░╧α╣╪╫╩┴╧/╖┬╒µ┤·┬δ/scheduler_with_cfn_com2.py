import pickle
import pandas as pd
import numpy as np
from pyDecision.algorithm import bw_method, entropy_method
from pyDecision.compare.compare import compare_ranks_crisp
from mytopsis import *
from Parameter import  strategy_coefficient, large_service_num,medium_service_num,edge_service_num

pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
file_p = './datacenterinfo/'
file_to_save = './scheduler/'
service_df = pd.read_csv(file_p + f'all_data_centers_services_with_com2_{large_service_num}_{medium_service_num}_{edge_service_num}.csv')
service_grouped = service_df.groupby(['local_node', 'services_Type'])
schedule_result_df = pd.DataFrame()
s_max = list(service_df[[
    'Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity', 'link_condition']].max())
s_min = list(service_df[[
    'Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity', 'link_condition']].min())
with open('bwm_weights.pkl', 'rb') as file:
    bwm_weight = pickle.load(file)
algorithms = ['topsis', 'spotis']
custom_m = ['mtp']
all_algo = algorithms + custom_m
for name, group in service_grouped:
    if len(group) == 1:
        for algo in all_algo:
            temp_result = group.copy()
            temp_result['algo'] = algo
            temp_result['cluster_rank_by_algo'] = 1
            schedule_result_df = pd.concat([schedule_result_df, temp_result])
    else:
        criteria_arr = group[
            ['Delay', 'cpu_utili', 'mem_utili', 'disk_utili', 'cpu_capacity', 'mem_capacity', 'disk_capacity',
             'link_condition']].values
        criteria_type = ['min', 'max', 'max', 'max', 'max', 'max', 'max', 'min']
        alternatives = group[['Data_Center_Name']].values
        en_weight = entropy_method(criteria_arr, criteria_type)
        print(en_weight, bwm_weight)
        my_ranks = my_topsis_method(criteria_arr, en_weight, criteria_type, s_min)
        custom_r = [my_ranks]
        values, ranks = compare_ranks_crisp(criteria_arr, en_weight, criteria_type, methods_list=algorithms,
                                            custom_methods=custom_m, custom_ranks=custom_r,
                                            strategy_coefficient=strategy_coefficient, s_min=s_min,
                                            s_max=s_max)
        for method, rank_series in ranks.items():
            # print(rank_series.values)
            temp_result = group.copy()
            temp_result['algo'] = method
            temp_result['cluster_rank_by_algo'] = rank_series.values
            # print(temp_result)
            schedule_result_df = pd.concat([schedule_result_df, temp_result])

schedule_result_df.to_csv(file_to_save+f'schedule_result_cfn_com2{large_service_num}_{medium_service_num}_{edge_service_num}.csv', index=False)
schedule_result_df.to_excel(file_to_save+f'schedule_result_cfn_com2{large_service_num}_{medium_service_num}_{edge_service_num}.xlsx', index=False)
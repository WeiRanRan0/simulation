import os

import pandas as pd

from Parameter import REQUEST_NUM, SERVICE_RECORD_NUM

folder_path = f'rst{REQUEST_NUM}_service{SERVICE_RECORD_NUM}/'

failed_rsts_with_domain = pd.read_csv(folder_path + f'failed_rst_with_domain_{SERVICE_RECORD_NUM}.csv')
failed_rsts_without_domain = pd.read_csv(folder_path + f'failed_rst_without_domain_{SERVICE_RECORD_NUM}.csv')
failed_rsts_random_without_domain = pd.read_csv(
    folder_path + f'failed_rst_random_without_domain_{SERVICE_RECORD_NUM}.csv')
rst = pd.read_csv(f'requests_data{REQUEST_NUM}_True.csv')

failed_rsts_with_domain_num = len(failed_rsts_with_domain)
failed_rsts_without_domain_num = len(failed_rsts_without_domain)
failed_rsts_random_without_domain_num = len(failed_rsts_random_without_domain)
rst_num = len(rst)



import random

import pandas as pd
from scipy import stats

from Parameter import Large_num, Medium_num, Edge_num
import itertools


class DataCenter:
    def __init__(self, name, server_num, server_ids, total_cpu, total_memory, total_disk, avg_cpu_utilization,
                 avg_memory_utilization, avg_disk_utilization, cpu_capacity, mem_capacity, disk_capacity):
        self.name = name
        self.server_num = server_num
        self.server_list = server_ids
        self.total_cpu = total_cpu
        self.total_memory = total_memory
        self.total_disk = total_disk
        self.cpu_utilization = avg_cpu_utilization
        self.memory_utilization = avg_memory_utilization
        self.disk_utilization = avg_disk_utilization
        self.cpu_capacity = cpu_capacity
        self.mem_capacity = mem_capacity
        self.disk_capacity = disk_capacity
        self.main_node = name  # 主节点属性，默认为 None


random.seed(38)
server_event_usage_df = pd.read_excel('server_event_usage.xlsx')
# shuffled_df = server_event_usage_df.sample(frac=1).reset_index(drop=True)
print(server_event_usage_df)

# 创建大型数据中心
large_centers = []
for i in range(Large_num):
    name = f"Large{i + 1}"
    server_num = random.randint(20, 40)  # 随机生成35到45之间的服务器数量
    server_ids = random.sample(server_event_usage_df['m_id'].tolist(), server_num)
    total_cpu = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'cpu_all'].sum()
    total_memory = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'mem_all'].sum()
    total_disk = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'disk_all'].sum()
    # cpu_utilization = stats.mode(server_event_usage_df.iloc[i * 40: (i + 1) * 40, 4])[0][0]  # 替换 'CPU使用率列名' 为实际列名
    # memory_utilization = stats.mode(server_event_usage_df.iloc[i * 40: (i + 1) * 40, 5])[0][0]  # 替换 '内存使用率列名' 为实际列名
    # disk_utilization = stats.mode(server_event_usage_df.iloc[i * 40: (i + 1) * 40, 6])[0][0]  # 替
    cpu_utilization = random.uniform(42, 100)  # 替换 'CPU使用率列名' 为实际列名
    memory_utilization = random.uniform(40, 100)  # 替换 '内存使用率列名' 为实际列名
    disk_utilization = random.uniform(40, 100)  # 替
    cpu_capacity = total_cpu * cpu_utilization / 100
    mem_capacity = total_memory * memory_utilization / 100
    disk_capacity = total_disk * disk_utilization / 100
    center = DataCenter(name, server_num, server_ids, total_cpu, total_memory, total_disk, cpu_utilization,
                        memory_utilization, disk_utilization, cpu_capacity, mem_capacity, disk_capacity)
    large_centers.append(center)
for center in large_centers:
    print(f"Data Center Name: {center.name}")
    print(f"Number of Servers: {center.server_num}")
    print(f"Server IDs: {center.server_list}")
    print()
#
# 创建中型数据中心
medium_centers = []
for i in range(Medium_num):
    name = f"Medium{i + 1}"
    server_num = random.randint(10, 25)
    server_ids = random.sample(server_event_usage_df['m_id'].tolist(), server_num)
    total_cpu = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'cpu_all'].sum()
    total_memory = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'mem_all'].sum()
    total_disk = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'disk_all'].sum()
    # cpu_utilization = \
    #     stats.mode(server_event_usage_df.iloc[Large_num * 40 + i * 20: Large_num * 40 + (i + 1) * 20, 4])[0][
    #         0]  # 替换 'CPU使用率列名' 为实际列名
    # memory_utilization = \
    #     stats.mode(server_event_usage_df.iloc[Large_num * 40 + i * 20: Large_num * 40 + (i + 1) * 20, 5])[0][
    #         0]  # 替换 '内存使用率列名' 为实际列名
    # disk_utilization = \
    #     stats.mode(server_event_usage_df.iloc[Large_num * 40 + i * 20: Large_num * 40 + (i + 1) * 20, 6])[0][0]  #
    cpu_utilization = random.uniform(50, 100)  # 替换 'CPU使用率列名' 为实际列名
    memory_utilization = random.uniform(30, 100)  # 替换 '内存使用率列名' 为实际列名
    disk_utilization = random.uniform(30, 100)  # 替
    cpu_capacity = total_cpu * cpu_utilization / 100
    mem_capacity = total_memory * memory_utilization / 100
    disk_capacity = total_disk * disk_utilization / 100
    center = DataCenter(name, server_num, server_ids, total_cpu, total_memory, total_disk, cpu_utilization,
                        memory_utilization, disk_utilization, cpu_capacity, mem_capacity, disk_capacity)
    medium_centers.append(center)
for center in medium_centers:
    print(f"Data Center Name: {center.name}")
    print(f"Number of Servers: {center.server_num}")
    print(f"Server IDs: {center.server_list}")
    print()
#
# 创建边缘数据中心
edge_centers = []
for i in range(Edge_num):
    name = f"Edge{i + 1}"
    server_num = random.randint(8, 14)
    server_ids = random.sample(server_event_usage_df['m_id'].tolist(), server_num)
    total_cpu = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'cpu_all'].sum()
    total_memory = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'mem_all'].sum()
    total_disk = server_event_usage_df.loc[server_event_usage_df['m_id'].isin(server_ids), 'disk_all'].sum()
    # cpu_utilization = stats.mode(server_event_usage_df.iloc[
    #                              Large_num * 40 + Medium_num * 20 + i * 10: Large_num * 40 + Medium_num * 20 + (
    #                                      i + 1) * 10, 4])[0][0]  # 替换 'CPU使用率列名' 为实际列名
    # memory_utilization = stats.mode(server_event_usage_df.iloc[
    #                                 Large_num * 40 + Medium_num * 20 + i * 10: Large_num * 40 + Medium_num * 20 + (
    #                                         i + 1) * 10, 5])[0][0]  # 替换 '内存使用率列名' 为实际列名
    # disk_utilization = stats.mode(server_event_usage_df.iloc[
    #                               Large_num * 40 + Medium_num * 20 + i * 10: Large_num * 40 + Medium_num * 20 + (
    #                                       i + 1) * 10, 6])[0][0]  #
    cpu_utilization = random.uniform(10, 100)  # 替换 'CPU使用率列名' 为实际列名
    memory_utilization = random.uniform(30, 100)  # 替换 '内存使用率列名' 为实际列名
    disk_utilization = random.uniform(30, 100)  # 替
    cpu_capacity = total_cpu * cpu_utilization / 100
    mem_capacity = total_memory * memory_utilization / 100
    disk_capacity = total_disk * disk_utilization / 100
    center = DataCenter(name, server_num, server_ids, total_cpu, total_memory, total_disk, cpu_utilization,
                        memory_utilization, disk_utilization, cpu_capacity, mem_capacity, disk_capacity)
    edge_centers.append(center)
for center in edge_centers:
    print(f"Data Center Name: {center.name}")
    print(f"Number of Servers: {center.server_num}")
    print(f"Server IDs: {center.server_list}")
    print()
#
# 随机设置主节点属性


for center in medium_centers:
    temp = random.choice(large_centers)
    center.main_node = temp.name  # 边缘数据中心随机选择一个中型数据中心作为主节点

for center in edge_centers:
    temp = random.choice(medium_centers)
    center.main_node = temp.name  # 边缘数据中心随机选择一个中型数据中心作为主节点
data_centers_info = []

# 添加大型数据中心信息
for center in large_centers:
    data_centers_info.append({
        'type': 'Large',
        'name': center.name,
        'num_of_server': center.server_num,
        'server_ids': center.server_list,
        'cpu_all': center.total_cpu,
        'mem_all': center.total_memory,
        'disk_all': center.total_disk,
        'cpu_utili': center.cpu_utilization,
        'mem_utili': center.memory_utilization,
        'disk_utili': center.disk_utilization,
        'cpu_capacity': center.cpu_capacity,
        'mem_capacity': center.mem_capacity,
        'disk_capacity': center.disk_capacity,
        'main_node': center.main_node
    })

# 添加中型数据中心信息
for center in medium_centers:
    data_centers_info.append({
        'type': 'Medium',
        'name': center.name,
        'num_of_server': center.server_num,
        'server_ids': center.server_list,
        'cpu_all': center.total_cpu,
        'mem_all': center.total_memory,
        'disk_all': center.total_disk,
        'cpu_utili': center.cpu_utilization,
        'mem_utili': center.memory_utilization,
        'disk_utili': center.disk_utilization,
        'cpu_capacity': center.cpu_capacity,
        'mem_capacity': center.mem_capacity,
        'disk_capacity': center.disk_capacity,
        'main_node': center.main_node
    })

# 添加边缘数据中心信息
for center in edge_centers:
    data_centers_info.append({
        'type': 'Edge',
        'name': center.name,
        'num_of_server': center.server_num,
        'server_ids': center.server_list,
        'cpu_all': center.total_cpu,
        'mem_all': center.total_memory,
        'disk_all': center.total_disk,
        'cpu_utili': center.cpu_utilization,
        'mem_utili': center.memory_utilization,
        'disk_utili': center.disk_utilization,
        'cpu_capacity': center.cpu_capacity,
        'mem_capacity': center.mem_capacity,
        'disk_capacity': center.disk_capacity,
        'main_node': center.main_node
    })
print(data_centers_info)
print(len(data_centers_info))
data_centers_df = pd.DataFrame(data_centers_info)
data_centers_df.to_csv('./datacenterinfo/data_centers_info.csv', index=False)
data_centers_df.to_excel('./datacenterinfo/data_centers_info.xlsx', index=False)

print("数据中心信息已保存到 ./datacenterinfo/data_centers_info.csv 文件中")  #

delay_info = []
for i in range(len(large_centers)):
    for j in range(len(large_centers)):
        if i == j:
            delay = random.uniform(5, 20)  # 自己和自己的时延为0
        else:
            delay = random.uniform(5, 20)  # 与其他大型数据中心的时延为5-20
        delay_info.append({
            "Node1": large_centers[i].name,
            "Node2": large_centers[j].name,
            "Delay": delay
        })

for i, center1 in enumerate(medium_centers):
    for j, center2 in enumerate(medium_centers):
        if i == j:
            delay = random.uniform(1, 5)
        elif center1.main_node == center2.main_node:
            delay = random.uniform(1, 5)
        else:
            temp = [item['Delay'] for item in delay_info if item['Node1'] == center1.main_node and item[
                'Node2'] == center2.main_node]  # 不同主节点的时延可以是None或其他值，根据需要调整
            delay = temp[0]
            # print(type(delay))
        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay
        })

for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(edge_centers):
        if i == j:
            delay = random.uniform(0, 1)
        elif center1.main_node == center2.main_node:
            delay = random.uniform(0, 1)
        else:
            temp = [item['Delay'] for item in delay_info if
                    item['Node1'] == center1.main_node and item['Node2'] == center2.main_node]
            # print(type(temp))
            # print(temp[0])
            delay = temp[0]
        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay
        })

for center in medium_centers:
    delay_info.append({
        "Node1": center.name,
        "Node2": center.main_node,
        "Delay": random.uniform(5, 15)
    })
    # 反向延迟信息
    delay_info.append({
        "Node1": center.main_node,
        "Node2": center.name,
        "Delay": random.uniform(5, 15)
    })
for center in edge_centers:
    delay_info.append({
        "Node1": center.name,
        "Node2": center.main_node,
        "Delay": random.uniform(1, 5)
    })
    # 反向延迟信息
    delay_info.append({
        "Node1": center.main_node,
        "Node2": center.name,
        "Delay": random.uniform(1, 5)
    })

for i, center1 in enumerate(medium_centers):
    for j, center2 in enumerate(large_centers):
        if center1.main_node != center2.name:
            delay_value_to_l = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)
            delay_value_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)

            delay_info.append({
                "Node1": center1.name,
                "Node2": center2.name,
                "Delay": delay_value_to_main + delay_value_to_l
            })
            delay_value_in_l = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
            delay_value_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

            delay_info.append({
                "Node1": center2.name,
                "Node2": center1.name,
                "Delay": delay_value_in_l + delay_value_in_main
            })

for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(medium_centers):
        if center1.main_node != center2.name:
            delay_value_to_m = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)
            delay_value_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)

            delay_info.append({
                "Node1": center1.name,
                "Node2": center2.name,
                "Delay": delay_value_to_main + delay_value_to_m
            })
            delay_value_in_m = next(delay_dict["Delay"] for delay_dict in delay_info if
                                    delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
            delay_value_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                                       delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

            delay_info.append({
                "Node1": center2.name,
                "Node2": center1.name,
                "Delay": delay_value_in_m + delay_value_in_main
            })
for i, center1 in enumerate(edge_centers):
    for j, center2 in enumerate(large_centers):
        delay_to_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                             delay_dict["Node1"] == center1.name and delay_dict["Node2"] == center1.main_node)
        delay_to_large = next(delay_dict["Delay"] for delay_dict in delay_info if
                              delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center2.name)

        delay_info.append({
            "Node1": center1.name,
            "Node2": center2.name,
            "Delay": delay_to_main + delay_to_large
        })
        delay_in_large = next(delay_dict["Delay"] for delay_dict in delay_info if
                              delay_dict["Node1"] == center2.name and delay_dict["Node2"] == center1.main_node)
        delay_in_main = next(delay_dict["Delay"] for delay_dict in delay_info if
                             delay_dict["Node1"] == center1.main_node and delay_dict["Node2"] == center1.name)

        delay_info.append({
            "Node1": center2.name,
            "Node2": center1.name,
            "Delay": delay_in_main + delay_in_large
        })
delay_df = pd.DataFrame(delay_info)
delay_df.to_csv('./datacenterinfo/datacenters_delay_info.csv', index=False)
delay_df.to_excel('./datacenterinfo/datacenters_delay_info.xlsx', index=False)
print("大型数据中心间时延信息已保存到 datacenters_delay_info.csv 文件中")

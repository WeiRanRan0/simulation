# import pandas as pd
# import glob
# from Parameter import large_request_num, medium_request_num, edge_request_num
# import matplotlib.pyplot as plt
# import numpy as np
# 
# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)
# pd.set_option('display.max_colwidth', 500)
# pd.set_option('display.expand_frame_repr', False)
# 
# 
# def plot_metric(data, metric, ylabel, title, avg_values):
#     plt.figure(figsize=(10, 6))
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_en_dy'],
#              label=f'{algo_to_plot} - com_en', color='blue')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_my_bwm_dy'],
#              label=f'{algo_to_plot} - com_my_bwm', color='orange')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_enbwm_dy'],
#              label=f'{algo_to_plot} - com_enbwm', color='green')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_en_and_my_dy'],
#              label=f'{algo_to_plot} - com_en_and_my', color='black')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_mix_bwm_dy'],
#              label=f'{algo_to_plot} - com_mix_bwm', color='purple')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_com_choice_dy'],
#              label=f'{algo_to_plot} - com_choice', color='pink')
#     plt.plot(range(1, len(data) + 1), data[f'{metric}_cfn_en_dy'],
#              label=f'{algo_to_plot} - cfn_en', linestyle=':', color='red')
# 
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_en_dy'], color='blue')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_my_bwm_dy'], color='orange')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_enbwm_dy'], color='green')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_en_and_my_dy'], color='black')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_mix_bwm_dy'], color='purple')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_choice_dy'], color='pink')
#     plt.scatter(range(1, len(data) + 1), data[f'{metric}_cfn_en_dy'], color='red')
# 
#     plt.scatter([], [], color='blue', label=f'Average com_en: {avg_values["com_en_avg"]:.2f}')
#     plt.scatter([], [], color='orange', label=f'Average com_my_bwm: {avg_values["com_my_bwm_avg"]:.2f}')
#     plt.scatter([], [], color='green', label=f'Average com_enbwm: {avg_values["com_enbwm_avg"]:.2f}')
#     plt.scatter([], [], color='black', label=f'Average com_en_and_my: {avg_values["com_en_and_my_avg"]:.2f}')
#     plt.scatter([], [], color='purple', label=f'Average com_mix_bwm: {avg_values["com_mix_bwm_avg"]:.2f}')
#     plt.scatter([], [], color='pink', label=f'Average com_choice: {avg_values["com_choice_avg"]:.2f}')
#     plt.scatter([], [], color='red', label=f'Average cfn: {avg_values["cfn_avg"]:.2f}')
# 
#     plt.xlabel('Number of Iterations')
#     plt.ylabel(ylabel)
#     plt.title(title)
#     plt.legend()
#     plt.grid(True)
#     plt.show()
# 
# 
# def process_files_and_save(file_pattern, output_file):
#     # 存储所有数据的列表
#     all_data = []
# 
#     # 使用glob模块匹配指定文件名模式的文件
#     for file_name in glob.glob(file_pattern):
#         data = pd.read_csv(file_name, index_col=False)
#         all_data.append(data)
# 
#     # 检查是否找到了匹配的文件
#     if all_data:
#         # 合并所有数据
#         combined_data = pd.concat(all_data, ignore_index=True)
#         avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
#         avg_success_rate_by_algo.to_csv(output_file, index=False)
#         print(f"结果已保存至 {output_file}")
#         return combined_data, avg_success_rate_by_algo
#     else:
#         print("未找到匹配的文件。")
# 
# 
# def process_dy_files_and_save(file_pattern, output_file):
#     # 存储所有数据的列表
#     all_data = []
# 
#     # 使用glob模块匹配指定文件名模式的文件
#     for file_name in glob.glob(file_pattern):
#         data = pd.read_csv(file_name, index_col=False)
#         all_data.append(data)
# 
#     # 检查是否找到了匹配的文件
#     if all_data:
#         # 合并所有数据
#         combined_data = pd.concat(all_data, ignore_index=True)
#         avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
#         avg_improvement_rate_by_algo = combined_data.groupby('algo')['average_improvement_rate'].mean().reset_index()
#         avg_perfect_rate_by_algo = combined_data.groupby('algo')['perfect_satisfaction_rate'].mean().reset_index()
# 
#         avg_combined = avg_success_rate_by_algo
#         avg_combined['avg_improvement_rate'] = avg_improvement_rate_by_algo['average_improvement_rate']
#         avg_combined['avg_perfect_rate'] = avg_perfect_rate_by_algo['perfect_satisfaction_rate']
# 
#         avg_combined.to_csv(output_file, index=False)
# 
#         print(f"结果已保存至 {output_file}")
# 
#         return combined_data, avg_combined
#     else:
#         print("未找到匹配的文件。")
# 
# 
# def process_balance_files_and_save(file_pattern, output_file):
#     # 存储所有数据的列表
#     all_data = []
# 
#     # 使用glob模块匹配指定文件名模式的文件
#     for file_name in glob.glob(file_pattern):
#         data = pd.read_csv(file_name, index_col=False)
#         all_data.append(data)
# 
#     # 检查是否找到了匹配的文件
#     if all_data:
#         # 合并所有数据
#         combined_data = pd.concat(all_data, ignore_index=True)
# 
#         avg_success_rate_by_algo = combined_data.groupby('algorithm')['zero_ratio'].mean().reset_index()
#         avg_success_rate_by_algo.to_csv(output_file, index=False)
#         print(f"结果已保存至 {output_file}")
#         return combined_data, avg_success_rate_by_algo
#     else:
#         print("未找到匹配的文件。")
# 
# 
# print(
#     '^^^^^^^^^静态成功率可视化**********************************************************************************************')
# print()
# folder_from = './successrate'
# folder_to = './algo_final_result'
# algo_list = ['en', 'my_bwm', 'enbwm', 'en_and_my', 'mix_bwm', 'choice']
# algo_cfn = 'en'
# file_com_en = f'{folder_from}/results_analysis_with_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_en = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_my_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_my_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_enbwm = f'{folder_from}/results_analysis_with_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_enbwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_en_and_my = f'{folder_from}/results_analysis_with_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_en_and_my = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_mix_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_mix_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_choice = f'{folder_from}/results_analysis_with_com22_{algo_list[5]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_choice = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[5]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_cfn = f'{folder_from}/results_analysis_with_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_cfn = f'{folder_to}/success_rate_sta_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# 
# com_en, com_en_avg_df = process_files_and_save(file_com_en, output_com_en)
# com_my_bwm, com_my_bwm_avg_df = process_files_and_save(file_com_my_bwm, output_com_my_bwm)
# com_enbwm, com_enbwm_avg_df = process_files_and_save(file_com_enbwm, output_com_enbwm)
# com_en_and_my, com_en_and_my_avg_df = process_files_and_save(file_com_en_and_my, output_com_en_and_my)
# com_mix_bwm, com_mix_bwm_avg_df = process_files_and_save(file_com_mix_bwm, output_com_mix_bwm)
# com_choice, com_choice_avg_df = process_files_and_save(file_com_choice, output_com_choice)
# cfn, cfn_avg_df = process_files_and_save(file_cfn, output_cfn)
# 
# algo_to_plot = 'topsis'
# com_en_avg = com_en_avg_df.loc[com_en_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_my_bwm_avg = com_my_bwm_avg_df.loc[com_my_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_enbwm_avg = com_enbwm_avg_df.loc[com_enbwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_en_and_my_avg = com_en_and_my_avg_df.loc[com_en_and_my_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_mix_bwm_avg = com_mix_bwm_avg_df.loc[com_mix_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_choice_avg = com_choice_avg_df.loc[com_choice_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# cfn_avg = cfn_avg_df.loc[cfn_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# # 合并数据
# merged = pd.concat([com_en, com_my_bwm, com_enbwm, com_en_and_my, com_mix_bwm, com_choice, cfn], axis=1)
# merged.columns = ['algo', 'success_rate_com_en', 'algo', 'success_rate_com_my_bwm', 'algo', 'success_rate_com_enbwm',
#                   'algo', 'success_rate_com_en_and_my', 'algo', 'success_rate_com_mix_bwm','algo', 'success_rate_com_choice', 'algo', 'success_rate_cfn']
# merged_new = merged.loc[:, ~merged.columns.duplicated()]
# # print(merged_new.head(10))
# # 按算法分组
# merged_g = merged_new.groupby('algo')
# # print(merged_g.head(10))
# 
# # 获取对应算法的数据
# data_to_plot = merged_g.get_group(algo_to_plot)
# 
# # 绘制折线图
# plt.figure(figsize=(10, 6))
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'],
#          label=f'{algo_to_plot} - en', color='blue')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'],
#          label=f'{algo_to_plot} - my_bwm', color='orange')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'],
#          label=f'{algo_to_plot} - enbwm', color='green')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'],
#          label=f'{algo_to_plot} - en_and_my', color='black')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'],
#          label=f'{algo_to_plot} - mix_bwm', color='purple')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_choice'],
#          label=f'{algo_to_plot} - mix_bwm', color='pink')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'],
#          label=f'{algo_to_plot} - CFN_en', linestyle=':', color='red')
# # 在每个数据点上标出数据
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'], color='blue')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'], color='orange')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'], color='green')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'], color='black')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'], color='purple')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_choice'], color='pink')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'], color='red')
# # 在图例中标出平均值（通过不可见点）
# plt.scatter([], [], color='blue', label=f'Average EN: {com_en_avg:.2f}')
# plt.scatter([], [], color='orange', label=f'Average Mybwm: {com_my_bwm_avg:.2f}')
# plt.scatter([], [], color='green', label=f'Average Enbwm: {com_enbwm_avg:.2f}')
# plt.scatter([], [], color='black', label=f'Average En_and_my: {com_en_and_my_avg:.2f}')
# plt.scatter([], [], color='purple', label=f'Average Mix_bwm: {com_mix_bwm_avg:.2f}')
# plt.scatter([], [], color='pink', label=f'Average Choice: {com_choice_avg:.2f}')
# plt.scatter([], [], color='red', label=f'Average CFN: {cfn_avg:.2f}')
# plt.xlabel('Number of Iterations')
# 
# # 设置y轴标签
# plt.ylabel('Success Rate')
# 
# # 设置标题
# plt.title(f'Success Rates for {algo_to_plot} Algorithm and Different Weight Type')
# plt.legend(loc='lower left', prop={'size': 6}, ncol=2, bbox_to_anchor=(0, 0))
# plt.grid(True)
# plt.show()
# 
# print(
#     '^^^^^^^^^动态成功率可视化**********************************************************************************************')
# print()
# 
# file_com_en_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_en_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_my_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_my_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_enbwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_enbwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_en_and_my_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_en_and_my_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_mix_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_mix_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_choice_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[5]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_choice_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[5]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_cfn_dy = f'{folder_from}/task_success_rates_per_algo_with_res_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_cfn_dy = f'{folder_to}/success_rate_dy_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
# 
# algo_to_plot = 'topsis'
# 
# com_en_dy, com_en_dy_avg_df = process_dy_files_and_save(file_com_en_dy, output_com_en_dy)
# com_my_bwm_dy, com_my_bwm_dy_avg_df = process_dy_files_and_save(file_com_my_bwm_dy, output_com_my_bwm_dy)
# com_enbwm_dy, com_enbwm_dy_avg_df = process_dy_files_and_save(file_com_enbwm_dy, output_com_enbwm_dy)
# com_en_and_my_dy, com_en_and_my_dy_avg_df = process_dy_files_and_save(file_com_en_and_my_dy, output_com_en_and_my_dy)
# com_mix_bwm_dy, com_mix_bwm_dy_avg_df = process_dy_files_and_save(file_com_mix_bwm_dy, output_com_mix_bwm_dy)
# com_choice_dy, com_choice_dy_avg_df = process_dy_files_and_save(file_com_choice_dy, output_com_choice_dy)
# cfn_dy, cfn_dy_avg_df = process_dy_files_and_save(file_cfn_dy, output_cfn_dy)
# # print(com_en_dy_avg_df)
# # print(com_my_bwm_dy_avg_df)
# # print(com_enbwm_dy_avg_df)
# # print(com_en_and_my_dy_avg_df)
# # print(com_mix_bwm_dy_avg_df)
# com_en_dy_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_my_bwm_dy_avg = com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_enbwm_dy_avg = com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_en_and_my_dy_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_mix_bwm_dy_avg = com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_choice_dy_avg = com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# cfn_dy_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# 
# com_en_dy_imp_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_my_bwm_dy_imp_avg = \
#     com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_enbwm_dy_imp_avg = \
#     com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_en_and_my_dy_imp_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_mix_bwm_dy_imp_avg = \
#     com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_choice_dy_imp_avg = \
#     com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# cfn_dy_imp_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# 
# com_en_dy_perf_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_my_bwm_dy_perf_avg = \
#     com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_enbwm_dy_perf_avg = com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[
#     0]
# com_en_and_my_dy_perf_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_mix_bwm_dy_perf_avg = \
#     com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_choice_dy_perf_avg = \
#     com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# cfn_dy_perf_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# 
# # 合并数据
# merged_dy = pd.concat([com_en_dy, com_my_bwm_dy, com_enbwm_dy, com_en_and_my_dy, com_mix_bwm_dy, com_choice_dy, cfn_dy], axis=1)
# print(merged_dy)
# merged_dy.columns = ['algo', 'success_rate_com_en_dy', 'average_improvement_rate_com_en_dy',
#                      'perfect_satisfaction_rate_com_en_dy',
#                      'algo', 'success_rate_com_my_bwm_dy', 'average_improvement_rate_com_my_bwm_dy',
#                      'perfect_satisfaction_rate_com_my_bwm_dy',
#                      'algo', 'success_rate_com_enbwm_dy', 'average_improvement_rate_com_enbwm_dy',
#                      'perfect_satisfaction_rate_com_enbwm_dy',
#                      'algo', 'success_rate_com_en_and_my_dy', 'average_improvement_rate_com_en_and_my_dy',
#                      'perfect_satisfaction_rate_com_en_and_my_dy',
#                      'algo', 'success_rate_com_mix_bwm_dy', 'average_improvement_rate_com_mix_bwm_dy',
#                      'perfect_satisfaction_rate_com_mix_bwm_dy',
#                      'algo', 'success_rate_com_choice_dy', 'average_improvement_rate_com_choice_dy',
#                      'perfect_satisfaction_rate_com_choice_dy',
#                      'algo', 'success_rate_cfn_en_dy', 'average_improvement_rate_cfn_en_dy',
#                      'perfect_satisfaction_rate_cfn_en_dy']
# merged_dy_new = merged_dy.loc[:, ~merged_dy.columns.duplicated()]
# 
# # 按算法分组
# merged_dy_g = merged_dy_new.groupby('algo')
# 
# # 获取对应算法的数据
# data_to_plot_dy = merged_dy_g.get_group(algo_to_plot)
# avg_values = {
#     "com_en_avg": com_en_dy_avg,
#     "com_my_bwm_avg": com_my_bwm_dy_avg,
#     "com_enbwm_avg": com_enbwm_dy_avg,
#     "com_en_and_my_avg": com_en_and_my_dy_avg,
#     "com_mix_bwm_avg": com_mix_bwm_dy_avg,
#     "com_choice_avg": com_choice_dy_avg,
#     "cfn_avg": cfn_dy_avg
# }
# plot_metric(data_to_plot_dy, 'success_rate', 'Success Rate', 'Success Rate Comparison', avg_values)
# 
# # 绘制平均改进率图
# avg_values_imp = {
#     "com_en_avg": com_en_dy_imp_avg,
#     "com_my_bwm_avg": com_my_bwm_dy_imp_avg,
#     "com_enbwm_avg": com_enbwm_dy_imp_avg,
#     "com_en_and_my_avg": com_en_and_my_dy_imp_avg,
#     "com_mix_bwm_avg": com_mix_bwm_dy_imp_avg,
#     "com_choice_avg": com_choice_dy_imp_avg,
#     "cfn_avg": cfn_dy_imp_avg
# }
# plot_metric(data_to_plot_dy, 'average_improvement_rate', 'Average Improvement Rate',
#             'Average Improvement Rate Comparison', avg_values_imp)
# 
# # 绘制完美满意率图
# avg_values_perf = {
#     "com_en_avg": com_en_dy_perf_avg,
#     "com_my_bwm_avg": com_my_bwm_dy_perf_avg,
#     "com_enbwm_avg": com_enbwm_dy_perf_avg,
#     "com_en_and_my_avg": com_en_and_my_dy_perf_avg,
#     "com_mix_bwm_avg": com_mix_bwm_dy_perf_avg,
#     "com_choice_avg": com_choice_dy_perf_avg,
#     "cfn_avg": cfn_dy_perf_avg
# }
# plot_metric(data_to_plot_dy, 'perfect_satisfaction_rate', 'Perfect Satisfaction Rate',
#             'Perfect Satisfaction Rate Comparison', avg_values_perf)
# 
# print(
#     '^^^^^^^^^资源均衡率可视化**********************************************************************************************')
# print()
# balance_folder = './balance'
# 
# com_en_balance = f'{balance_folder}/balance_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_en_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_my_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_my_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_enbwm_balance = f'{balance_folder}/balance_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_enbwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_en_and_my_balance = f'{balance_folder}/balance_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_en_and_my_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_mix_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_mix_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_choice_balance = f'{balance_folder}/balance_com22_{algo_list[5]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_choice_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[5]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# cfn_balance = f'{balance_folder}/balance_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_cfn_balance = f'{folder_to}/avg_balance_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# 
# com_en_ba, com_en_ba_avg_df = process_balance_files_and_save(com_en_balance, output_com_en_balance)
# com_my_bwm_ba, com_my_bwm_ba_avg_df = process_balance_files_and_save(com_my_bwm_balance, output_com_my_bwm_balance)
# com_enbwm_ba, com_enbwm_ba_avg_df = process_balance_files_and_save(com_enbwm_balance, output_com_enbwm_balance)
# com_en_and_my_ba, com_en_and_my_ba_avg_df = process_balance_files_and_save(com_en_and_my_balance,
#                                                                            output_com_en_and_my_balance)
# com_mix_bwm_ba, com_mix_bwm_ba_avg_df = process_balance_files_and_save(com_mix_bwm_balance, output_com_mix_bwm_balance)
# com_choice_ba, com_choice_ba_avg_df = process_balance_files_and_save(com_choice_balance, output_com_choice_balance)
# cfn_ba, cfn_ba_avg_df = process_balance_files_and_save(cfn_balance, output_cfn_balance)
# 
# com_en_ba_avg = com_en_ba_avg_df.loc[com_en_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_my_bwm_ba_avg = com_my_bwm_ba_avg_df.loc[com_my_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_enbwm_ba_avg = com_enbwm_ba_avg_df.loc[com_enbwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_en_and_my_ba_avg = \
#     com_en_and_my_ba_avg_df.loc[com_en_and_my_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_mix_bwm_ba_avg = com_mix_bwm_ba_avg_df.loc[com_mix_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[
#     0]
# com_choice_ba_avg = com_choice_ba_avg_df.loc[com_choice_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[
#     0]
# cfn_ba_avg = cfn_ba_avg_df.loc[cfn_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# 
# # 合并数据
# merged_ba = pd.concat([com_en_ba, com_my_bwm_ba, com_enbwm_ba, com_en_and_my_ba, com_mix_bwm_ba,com_choice_ba, cfn_ba], axis=1)
# merged_ba.columns = ['algo', 'com_en_ba', 'algo', 'com_my_bwm_ba', 'algo', 'com_enbwm_ba', 'algo', 'com_en_and_my_ba',
#                      'algo', 'com_mix_bwm_ba','algo', 'com_choice_ba', 'algo', 'cfn_ba']
# merged_ba_new = merged_ba.loc[:, ~merged_ba.columns.duplicated()]
# 
# # 按算法分组
# merged_ba_g = merged_ba_new.groupby('algo')
# 
# # 选择要绘制的算法
# algo_to_plot = 'topsis'
# 
# # 获取对应算法的数据
# data_to_plot_ba = merged_ba_g.get_group(algo_to_plot)
# 
# # 绘制折线图
# plt.figure(figsize=(10, 6))
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'],
#          label=f'{algo_to_plot} - COM_en', color='blue')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'],
#          label=f'{algo_to_plot} - COM_my_bwm', color='orange')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'],
#          label=f'{algo_to_plot} - COM_enbwm', color='green')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'],
#          label=f'{algo_to_plot} - COM_en_and_my', color='black')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'],
#          label=f'{algo_to_plot} - COM_mix_bwm', color='purple')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_choice_ba'],
#          label=f'{algo_to_plot} - COM_choice', color='pink')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'],
#          label=f'{algo_to_plot} - CFN', linestyle=':', color='red')
# 
# # 在每个数据点上标出数据
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'], color='blue')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'], color='orange')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'], color='green')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'], color='black')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'], color='purple')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_choice_ba'], color='pink')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='red')
# plt.scatter([], [], color='blue', label=f'Average com_en: {com_en_ba_avg:.2f}')
# plt.scatter([], [], color='orange', label=f'Average com_my_bwm: {com_my_bwm_ba_avg:.2f}')
# plt.scatter([], [], color='green', label=f'Average com_enbwm: {com_enbwm_ba_avg:.2f}')
# plt.scatter([], [], color='black', label=f'Average com_en_and_my: {com_en_and_my_ba_avg:.2f}')
# plt.scatter([], [], color='purple', label=f'Average com_mix_bwm: {com_mix_bwm_ba_avg:.2f}')
# plt.scatter([], [], color='pink', label=f'Average com_choice: {com_choice_ba_avg:.2f}')
# plt.scatter([], [], color='red', label=f'Average cfn: {cfn_ba_avg:.2f}')
# 
# # 设置x轴标签
# plt.xlabel('Number of Iterations')
# 
# # 设置y轴标签
# plt.ylabel('Balance Rate')
# 
# # 设置标题
# plt.title(f'Balance Rates for {algo_to_plot} Algorithm and Different Weight Type')
# 
# # 显示图例
# plt.legend(loc='lower left', prop={'size': 6}, ncol=2, bbox_to_anchor=(0, 0))
# 
# # 显示网格
# plt.grid(True)
# 
# # 显示图形
# 
# plt.show()
import pandas as pd
import glob
from Parameter import large_request_num, medium_request_num, edge_request_num
import matplotlib.pyplot as plt
import numpy as np

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)


def plot_metric(data, metric, ylabel, title, avg_values):
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(data) + 1), data[f'{metric}_com_en_dy'],
             label=f'{algo_to_plot} - com_en', color='blue')
    plt.plot(range(1, len(data) + 1), data[f'{metric}_com_my_bwm_dy'],
             label=f'{algo_to_plot} - com_my_bwm', color='orange')
    # plt.plot(range(1, len(data) + 1), data[f'{metric}_com_enbwm_dy'],
    #          label=f'{algo_to_plot} - com_enbwm', color='green')
    # plt.plot(range(1, len(data) + 1), data[f'{metric}_com_en_and_my_dy'],
    #          label=f'{algo_to_plot} - com_en_and_my', color='black')
    # plt.plot(range(1, len(data) + 1), data[f'{metric}_com_mix_bwm_dy'],
    #          label=f'{algo_to_plot} - com_mix_bwm', color='purple')
    # plt.plot(range(1, len(data) + 1), data[f'{metric}_com_choice_dy'],
    #          label=f'{algo_to_plot} - com_choice', color='pink')
    # plt.plot(range(1, len(data) + 1), data[f'{metric}_cfn_en_dy'],
    #          label=f'{algo_to_plot} - cfn_en', linestyle=':', color='red')

    plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_en_dy'], color='blue')
    plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_my_bwm_dy'], color='orange')
    # plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_enbwm_dy'], color='green')
    # plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_en_and_my_dy'], color='black')
    # plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_mix_bwm_dy'], color='purple')
    # plt.scatter(range(1, len(data) + 1), data[f'{metric}_com_choice_dy'], color='pink')
    # plt.scatter(range(1, len(data) + 1), data[f'{metric}_cfn_en_dy'], color='red')

    plt.scatter([], [], color='blue', label=f'Average com_en: {avg_values["com_en_avg"]:.2f}')
    plt.scatter([], [], color='orange', label=f'Average com_my_bwm: {avg_values["com_my_bwm_avg"]:.2f}')
    # plt.scatter([], [], color='green', label=f'Average com_enbwm: {avg_values["com_enbwm_avg"]:.2f}')
    # plt.scatter([], [], color='black', label=f'Average com_en_and_my: {avg_values["com_en_and_my_avg"]:.2f}')
    # plt.scatter([], [], color='purple', label=f'Average com_mix_bwm: {avg_values["com_mix_bwm_avg"]:.2f}')
    # plt.scatter([], [], color='pink', label=f'Average com_choice: {avg_values["com_choice_avg"]:.2f}')
    # plt.scatter([], [], color='red', label=f'Average cfn: {avg_values["cfn_avg"]:.2f}')

    plt.xlabel('Number of Iterations')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()


def process_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)
        avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


def process_dy_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)
        avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
        avg_improvement_rate_by_algo = combined_data.groupby('algo')['average_improvement_rate'].mean().reset_index()
        avg_perfect_rate_by_algo = combined_data.groupby('algo')['perfect_satisfaction_rate'].mean().reset_index()

        avg_combined = avg_success_rate_by_algo
        avg_combined['avg_improvement_rate'] = avg_improvement_rate_by_algo['average_improvement_rate']
        avg_combined['avg_perfect_rate'] = avg_perfect_rate_by_algo['perfect_satisfaction_rate']

        avg_combined.to_csv(output_file, index=False)

        print(f"结果已保存至 {output_file}")

        return combined_data, avg_combined
    else:
        print("未找到匹配的文件。")


def process_balance_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)

        avg_success_rate_by_algo = combined_data.groupby('algorithm')['zero_ratio'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


# print(
#     '^^^^^^^^^静态成功率可视化**********************************************************************************************')
# print()
folder_from = './successrate'
folder_to = './algo_final_result'
algo_list = ['en', 'my_bwm', 'choice']
algo_cfn = 'my_bwm'
# file_com_en = f'{folder_from}/results_analysis_with_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_en = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
file_com_my_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
output_com_my_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_enbwm = f'{folder_from}/results_analysis_with_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_enbwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_en_and_my = f'{folder_from}/results_analysis_with_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_en_and_my = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_mix_bwm = f'{folder_from}/results_analysis_with_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_com_mix_bwm = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
file_com_choice = f'{folder_from}/results_analysis_with_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
output_com_choice = f'{folder_to}/success_rate_sta_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_cfn = f'{folder_from}/results_analysis_with_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_cfn = f'{folder_to}/success_rate_sta_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'

# com_en, com_en_avg_df = process_files_and_save(file_com_en, output_com_en)
# com_my_bwm, com_my_bwm_avg_df = process_files_and_save(file_com_my_bwm, output_com_my_bwm)
# com_enbwm, com_enbwm_avg_df = process_files_and_save(file_com_enbwm, output_com_enbwm)
# com_en_and_my, com_en_and_my_avg_df = process_files_and_save(file_com_en_and_my, output_com_en_and_my)
# com_mix_bwm, com_mix_bwm_avg_df = process_files_and_save(file_com_mix_bwm, output_com_mix_bwm)
# com_choice, com_choice_avg_df = process_files_and_save(file_com_choice, output_com_choice)
# cfn, cfn_avg_df = process_files_and_save(file_cfn, output_cfn)

# algo_to_plot = 'topsis'
# com_en_avg = com_en_avg_df.loc[com_en_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_my_bwm_avg = com_my_bwm_avg_df.loc[com_my_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_enbwm_avg = com_enbwm_avg_df.loc[com_enbwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_en_and_my_avg = com_en_and_my_avg_df.loc[com_en_and_my_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_mix_bwm_avg = com_mix_bwm_avg_df.loc[com_mix_bwm_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_choice_avg = com_choice_avg_df.loc[com_choice_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# cfn_avg = cfn_avg_df.loc[cfn_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# 合并数据
# merged = pd.concat([com_en, com_my_bwm, com_enbwm, com_en_and_my, com_mix_bwm, com_choice, cfn], axis=1)
# merged = pd.concat([com_en, com_my_bwm, com_choice, cfn], axis=1)
# merged.columns = ['algo', 'success_rate_com_en', 'algo', 'success_rate_com_my_bwm', 'algo',
#                   'success_rate_com_choice', 'algo', 'success_rate_cfn']
# merged_new = merged.loc[:, ~merged.columns.duplicated()]
# # print(merged_new.head(10))
# # 按算法分组
# merged_g = merged_new.groupby('algo')
# # print(merged_g.head(10))
#
# # 获取对应算法的数据
# data_to_plot = merged_g.get_group(algo_to_plot)
#
# # 绘制折线图
# plt.figure(figsize=(10, 6))
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'],
#          label=f'{algo_to_plot} - en', color='blue')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'],
#          label=f'{algo_to_plot} - my_bwm', color='orange')
# # plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'],
# #          label=f'{algo_to_plot} - enbwm', color='green')
# # plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'],
# #          label=f'{algo_to_plot} - en_and_my', color='black')
# # plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'],
# #          label=f'{algo_to_plot} - mix_bwm', color='purple')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_choice'],
#          label=f'{algo_to_plot} - choice', color='pink')
# plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'],
#          label=f'{algo_to_plot} - CFN_en', linestyle=':', color='red')
# # 在每个数据点上标出数据
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en'], color='blue')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_my_bwm'], color='orange')
# # plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_enbwm'], color='green')
# # plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_en_and_my'], color='black')
# # plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_mix_bwm'], color='purple')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com_choice'], color='pink')
# plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'], color='red')
# # 在图例中标出平均值（通过不可见点）
# plt.scatter([], [], color='blue', label=f'Average EN: {com_en_avg:.2f}')
# plt.scatter([], [], color='orange', label=f'Average Mybwm: {com_my_bwm_avg:.2f}')
# # plt.scatter([], [], color='green', label=f'Average Enbwm: {com_enbwm_avg:.2f}')
# # plt.scatter([], [], color='black', label=f'Average En_and_my: {com_en_and_my_avg:.2f}')
# # plt.scatter([], [], color='purple', label=f'Average Mix_bwm: {com_mix_bwm_avg:.2f}')
# plt.scatter([], [], color='pink', label=f'Average Choice: {com_choice_avg:.2f}')
# plt.scatter([], [], color='red', label=f'Average CFN: {cfn_avg:.2f}')
# plt.xlabel('Number of Iterations')
#
# # 设置y轴标签
# plt.ylabel('Success Rate')
#
# # 设置标题
# plt.title(f'Success Rates for {algo_to_plot} Algorithm and Different Weight Type')
# plt.legend(loc='lower left', prop={'size': 6}, ncol=2, bbox_to_anchor=(0, 0))
# plt.grid(True)
# plt.show()

print(
    '^^^^^^^^^动态成功率可视化**********************************************************************************************')
print()

file_com_en_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com_en_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
file_com_my_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com_my_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_enbwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_enbwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_en_and_my_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_en_and_my_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_com_mix_bwm_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
# output_com_mix_bwm_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
file_com_choice_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com_choice_dy = f'{folder_to}/success_rate_dy_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# file_cfn_dy = f'{folder_from}/task_success_rates_per_algo_with_res_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# output_cfn_dy = f'{folder_to}/success_rate_dy_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径

algo_to_plot = 'topsis'

com_en_dy, com_en_dy_avg_df = process_dy_files_and_save(file_com_en_dy, output_com_en_dy)
com_my_bwm_dy, com_my_bwm_dy_avg_df = process_dy_files_and_save(file_com_my_bwm_dy, output_com_my_bwm_dy)
# com_enbwm_dy, com_enbwm_dy_avg_df = process_dy_files_and_save(file_com_enbwm_dy, output_com_enbwm_dy)
# com_en_and_my_dy, com_en_and_my_dy_avg_df = process_dy_files_and_save(file_com_en_and_my_dy, output_com_en_and_my_dy)
# com_mix_bwm_dy, com_mix_bwm_dy_avg_df = process_dy_files_and_save(file_com_mix_bwm_dy, output_com_mix_bwm_dy)
# com_choice_dy, com_choice_dy_avg_df = process_dy_files_and_save(file_com_choice_dy, output_com_choice_dy)
# cfn_dy, cfn_dy_avg_df = process_dy_files_and_save(file_cfn_dy, output_cfn_dy)
# print(com_en_dy_avg_df)
# print(com_my_bwm_dy_avg_df)
# print(com_enbwm_dy_avg_df)
# print(com_en_and_my_dy_avg_df)
# print(com_mix_bwm_dy_avg_df)
com_en_dy_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
com_my_bwm_dy_avg = com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_enbwm_dy_avg = com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_en_and_my_dy_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_mix_bwm_dy_avg = com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# com_choice_dy_avg = com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]
# cfn_dy_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'success_rate'].values[0]

com_en_dy_imp_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
com_my_bwm_dy_imp_avg = \
    com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_enbwm_dy_imp_avg = \
#     com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_en_and_my_dy_imp_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_mix_bwm_dy_imp_avg = \
#     com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# com_choice_dy_imp_avg = \
#     com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]
# cfn_dy_imp_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_improvement_rate'].values[0]

com_en_dy_perf_avg = com_en_dy_avg_df.loc[com_en_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
com_my_bwm_dy_perf_avg = \
    com_my_bwm_dy_avg_df.loc[com_my_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_enbwm_dy_perf_avg = com_enbwm_dy_avg_df.loc[com_enbwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[
#     0]
# com_en_and_my_dy_perf_avg = \
#     com_en_and_my_dy_avg_df.loc[com_en_and_my_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_mix_bwm_dy_perf_avg = \
#     com_mix_bwm_dy_avg_df.loc[com_mix_bwm_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# com_choice_dy_perf_avg = \
#     com_choice_dy_avg_df.loc[com_choice_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]
# cfn_dy_perf_avg = cfn_dy_avg_df.loc[cfn_dy_avg_df['algo'] == algo_to_plot, 'avg_perfect_rate'].values[0]

# 合并数据
# merged_dy = pd.concat([com_en_dy, com_my_bwm_dy, com_enbwm_dy, com_en_and_my_dy, com_mix_bwm_dy, com_choice_dy, cfn_dy],
#                       axis=1)
merged_dy = pd.concat([com_en_dy, com_my_bwm_dy], axis=1)
print(merged_dy)
merged_dy.columns = ['algo', 'success_rate_com_en_dy', 'average_improvement_rate_com_en_dy',
                     'perfect_satisfaction_rate_com_en_dy',
                     'algo', 'success_rate_com_my_bwm_dy', 'average_improvement_rate_com_my_bwm_dy',
                     'perfect_satisfaction_rate_com_my_bwm_dy'
                     # 'algo', 'success_rate_com_enbwm_dy', 'average_improvement_rate_com_enbwm_dy',
                     # 'perfect_satisfaction_rate_com_enbwm_dy',
                     # 'algo', 'success_rate_com_en_and_my_dy', 'average_improvement_rate_com_en_and_my_dy',
                     # 'perfect_satisfaction_rate_com_en_and_my_dy',
                     # 'algo', 'success_rate_com_mix_bwm_dy', 'average_improvement_rate_com_mix_bwm_dy',
                     # 'perfect_satisfaction_rate_com_mix_bwm_dy',
                     # 'algo', 'success_rate_com_choice_dy', 'average_improvement_rate_com_choice_dy',
                     # 'perfect_satisfaction_rate_com_choice_dy'
                     # 'algo', 'success_rate_cfn_en_dy', 'average_improvement_rate_cfn_en_dy',
                     # 'perfect_satisfaction_rate_cfn_en_dy'
                     ]
merged_dy_new = merged_dy.loc[:, ~merged_dy.columns.duplicated()]

# 按算法分组
merged_dy_g = merged_dy_new.groupby('algo')

# 获取对应算法的数据
data_to_plot_dy = merged_dy_g.get_group(algo_to_plot)
avg_values = {
    "com_en_avg": com_en_dy_avg,
    "com_my_bwm_avg": com_my_bwm_dy_avg
    # "com_enbwm_avg": com_enbwm_dy_avg,
    # "com_en_and_my_avg": com_en_and_my_dy_avg,
    # "com_mix_bwm_avg": com_mix_bwm_dy_avg,
    # "com_choice_avg": com_choice_dy_avg
    # "cfn_avg": cfn_dy_avg
}
plot_metric(data_to_plot_dy, 'success_rate', 'Success Rate', 'Success Rate Comparison', avg_values)

# 绘制平均改进率图
avg_values_imp = {
    "com_en_avg": com_en_dy_imp_avg,
    "com_my_bwm_avg": com_my_bwm_dy_imp_avg
    # "com_enbwm_avg": com_enbwm_dy_imp_avg,
    # "com_en_and_my_avg": com_en_and_my_dy_imp_avg,
    # "com_mix_bwm_avg": com_mix_bwm_dy_imp_avg,
    # "com_choice_avg": com_choice_dy_imp_avg,
    # "cfn_avg": cfn_dy_imp_avg
}
plot_metric(data_to_plot_dy, 'average_improvement_rate', 'Average Improvement Rate',
            'Average Improvement Rate Comparison', avg_values_imp)

# 绘制完美满意率图
avg_values_perf = {
    "com_en_avg": com_en_dy_perf_avg,
    "com_my_bwm_avg": com_my_bwm_dy_perf_avg
    # "com_enbwm_avg": com_enbwm_dy_perf_avg,
    # "com_en_and_my_avg": com_en_and_my_dy_perf_avg,
    # "com_mix_bwm_avg": com_mix_bwm_dy_perf_avg,
    # "com_choice_avg": com_choice_dy_perf_avg,
    # "cfn_avg": cfn_dy_perf_avg
}
plot_metric(data_to_plot_dy, 'perfect_satisfaction_rate', 'Perfect Satisfaction Rate',
            'Perfect Satisfaction Rate Comparison', avg_values_perf)

print(
    '^^^^^^^^^资源均衡率可视化**********************************************************************************************')
print()
balance_folder = './balance'

com_en_balance = f'{balance_folder}/balance_com22_{algo_list[0]}_[0-9]_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
output_com_en_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[0]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
com_my_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[1]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
output_com_my_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[1]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_enbwm_balance = f'{balance_folder}/balance_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_enbwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_en_and_my_balance = f'{balance_folder}/balance_com22_{algo_list[3]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_en_and_my_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[3]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# com_mix_bwm_balance = f'{balance_folder}/balance_com22_{algo_list[4]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_com_mix_bwm_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[4]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
com_choice_balance = f'{balance_folder}/balance_com22_{algo_list[2]}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
output_com_choice_balance = f'{folder_to}/avg_balance_results_with_com22_{algo_list[2]}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
# cfn_balance = f'{balance_folder}/balance_cfn_{algo_cfn}_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'
# output_cfn_balance = f'{folder_to}/avg_balance_results_with_cfn_{algo_cfn}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'

com_en_ba, com_en_ba_avg_df = process_balance_files_and_save(com_en_balance, output_com_en_balance)
com_my_bwm_ba, com_my_bwm_ba_avg_df = process_balance_files_and_save(com_my_bwm_balance, output_com_my_bwm_balance)
# com_enbwm_ba, com_enbwm_ba_avg_df = process_balance_files_and_save(com_enbwm_balance, output_com_enbwm_balance)
# com_en_and_my_ba, com_en_and_my_ba_avg_df = process_balance_files_and_save(com_en_and_my_balance,
#                                                                            output_com_en_and_my_balance)
# com_mix_bwm_ba, com_mix_bwm_ba_avg_df = process_balance_files_and_save(com_mix_bwm_balance, output_com_mix_bwm_balance)
# com_choice_ba, com_choice_ba_avg_df = process_balance_files_and_save(com_choice_balance, output_com_choice_balance)
# cfn_ba, cfn_ba_avg_df = process_balance_files_and_save(cfn_balance, output_cfn_balance)

com_en_ba_avg = com_en_ba_avg_df.loc[com_en_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
com_my_bwm_ba_avg = com_my_bwm_ba_avg_df.loc[com_my_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_enbwm_ba_avg = com_enbwm_ba_avg_df.loc[com_enbwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_en_and_my_ba_avg = \
#     com_en_and_my_ba_avg_df.loc[com_en_and_my_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]
# com_mix_bwm_ba_avg = com_mix_bwm_ba_avg_df.loc[com_mix_bwm_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[
#     0]
# com_choice_ba_avg = com_choice_ba_avg_df.loc[com_choice_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[
#     0]
# cfn_ba_avg = cfn_ba_avg_df.loc[cfn_ba_avg_df['algorithm'] == algo_to_plot, 'zero_ratio'].values[0]

# 合并数据
# merged_ba = pd.concat([com_en_ba, com_my_bwm_ba, com_enbwm_ba, com_en_and_my_ba, com_mix_bwm_ba, com_choice_ba, cfn_ba],
#                       axis=1)
merged_ba = pd.concat([com_en_ba, com_my_bwm_ba], axis=1)
merged_ba.columns = ['algo', 'com_en_ba', 'algo', 'com_my_bwm_ba']
# merged_ba.columns = ['algo', 'com_en_ba', 'algo', 'com_my_bwm_ba', 'algo', 'com_enbwm_ba', 'algo', 'com_en_and_my_ba',
#                      'algo', 'com_mix_bwm_ba', 'algo', 'com_choice_ba', 'algo', 'cfn_ba']
merged_ba_new = merged_ba.loc[:, ~merged_ba.columns.duplicated()]

# 按算法分组
merged_ba_g = merged_ba_new.groupby('algo')

# 选择要绘制的算法
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot_ba = merged_ba_g.get_group(algo_to_plot)

# 绘制折线图
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'],
         label=f'{algo_to_plot} - COM_en', color='blue')
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'],
         label=f'{algo_to_plot} - COM_my_bwm', color='orange')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'],
#          label=f'{algo_to_plot} - COM_enbwm', color='green')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'],
#          label=f'{algo_to_plot} - COM_en_and_my', color='black')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'],
#          label=f'{algo_to_plot} - COM_mix_bwm', color='purple')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_choice_ba'],
#          label=f'{algo_to_plot} - COM_choice', color='pink')
# plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'],
#          label=f'{algo_to_plot} - CFN', linestyle=':', color='red')

# 在每个数据点上标出数据
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_ba'], color='blue')
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_my_bwm_ba'], color='orange')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_enbwm_ba'], color='green')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_en_and_my_ba'], color='black')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_mix_bwm_ba'], color='purple')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_choice_ba'], color='pink')
# plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='red')
plt.scatter([], [], color='blue', label=f'Average com_en: {com_en_ba_avg:.2f}')
plt.scatter([], [], color='orange', label=f'Average com_my_bwm: {com_my_bwm_ba_avg:.2f}')
# plt.scatter([], [], color='green', label=f'Average com_enbwm: {com_enbwm_ba_avg:.4f}')
# plt.scatter([], [], color='black', label=f'Average com_en_and_my: {com_en_and_my_ba_avg:.4f}')
# plt.scatter([], [], color='purple', label=f'Average com_mix_bwm: {com_mix_bwm_ba_avg:.4f}')
# plt.scatter([], [], color='pink', label=f'Average com_choice: {com_choice_ba_avg:.2f}')
# plt.scatter([], [], color='red', label=f'Average cfn: {cfn_ba_avg:.2f}')

# 设置x轴标签
plt.xlabel('Number of Iterations')

# 设置y轴标签
plt.ylabel('Balance Rate')

# 设置标题
plt.title(f'Balance Rates for {algo_to_plot} Algorithm and Different Weight Type')

# 显示图例
plt.legend(loc='lower left', prop={'size': 6}, ncol=2, bbox_to_anchor=(0, 0))

# 显示网格
plt.grid(True)

# 显示图形

plt.show()

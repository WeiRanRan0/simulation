import pandas as pd
import glob
from Parameter import large_request_num, medium_request_num, edge_request_num
import matplotlib.pyplot as plt
import numpy as np

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', 500)
pd.set_option('display.expand_frame_repr', False)


def process_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)
        avg_success_rate_by_algo = combined_data.groupby('algo')['success_rate'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


def process_balance_files_and_save(file_pattern, output_file):
    # 存储所有数据的列表
    all_data = []

    # 使用glob模块匹配指定文件名模式的文件
    for file_name in glob.glob(file_pattern):
        data = pd.read_csv(file_name, index_col=False)
        all_data.append(data)

    # 检查是否找到了匹配的文件
    if all_data:
        # 合并所有数据
        combined_data = pd.concat(all_data, ignore_index=True)

        avg_success_rate_by_algo = combined_data.groupby('algorithm')['zero_ratio'].mean().reset_index()
        avg_success_rate_by_algo.to_csv(output_file, index=False)
        print(f"结果已保存至 {output_file}")
        return combined_data, avg_success_rate_by_algo
    else:
        print("未找到匹配的文件。")


print(
    '^^^^^^^^^静态成功率可视化**********************************************************************************************')
print()
folder_from = './successrate'  # 替换为实际的文件夹路径
folder_to = './final_result'
file_cfn = f'{folder_from}/results_analysis_with_cfn_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
file_com = f'{folder_from}/results_analysis_with_com22_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com = f'{folder_to}/success_rate_sta_results_with_com22_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
output_cfn = f'{folder_to}/success_rate_sta_results_with_cfn_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
file_com1 = f'{folder_from}/results_analysis_with_com1_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com1 = f'{folder_to}/success_rate_sta_results_with_com1_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
cfn, cfn_avg = process_files_and_save(file_cfn, output_cfn)
com, com_avg = process_files_and_save(file_com, output_com)
com1, com1_avg = process_files_and_save(file_com1, output_com1)
# print(cfn)
# print(com)
merged = pd.concat([cfn, com, com1], axis=1)
merged.columns = ['algo', 'success_rate_cfn', 'algo', 'success_rate_com', 'algo', 'success_rate_com1']
merged_new = merged.loc[:, ~merged.columns.duplicated()]
# print(merged.head(10))
print(merged_new.head(10))
merged_g = merged_new.groupby('algo')
# print(merged_g)
plt.figure(figsize=(10, 6))

# 选择要绘制的算法
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot = merged_g.get_group(algo_to_plot)

# 绘制折线图
plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'],
         label=f'{algo_to_plot} - CFN')  # 绘制CFN算法的折线图
plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com'],
         label=f'{algo_to_plot} - COM')  # 绘制COM算法的折线图
plt.plot(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com1'],
         label=f'{algo_to_plot} - COM1')  # 绘制COM算法的折线图
# 在每个数据点上标出数据
plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_cfn'], color='blue')  # 标出CFN算法的数据点
plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com'], color='orange')  # 标出COM算法的数据点
plt.scatter(range(1, len(data_to_plot) + 1), data_to_plot['success_rate_com1'], color='green')  # 标出COM算法的数据点

# 设置x轴标签
plt.xlabel('Data Count')

# 设置y轴标签
plt.ylabel('Success Rate')

# 设置标题
plt.title(f'Success Rates for {algo_to_plot} Algorithm')

# 设置横坐标和纵坐标的范围
# plt.ylim(0, 1)  # 纵坐标范围为0到1

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot = merged_g.get_group(algo_to_plot)

# 设置图形大小
plt.figure(figsize=(10, 6))

# 定义柱状图的宽度
bar_width = 0.2

# 定义每个柱的位置
x = np.arange(len(data_to_plot))

# 绘制CFN算法的柱状图
plt.bar(x - bar_width, data_to_plot['success_rate_cfn'], width=bar_width, label=f'{algo_to_plot} - CFN')

# 绘制COM算法的柱状图
plt.bar(x, data_to_plot['success_rate_com'], width=bar_width, label=f'{algo_to_plot} - COM', alpha=0.7)
plt.bar(x + bar_width, data_to_plot['success_rate_com1'], width=bar_width, label=f'{algo_to_plot} - COM1',
        alpha=0.7)
# 在每个柱状图上标出数据值
for i in range(len(data_to_plot)):
    plt.text(x[i] - bar_width, data_to_plot['success_rate_cfn'].iloc[i],
             round(data_to_plot['success_rate_cfn'].iloc[i], 3), ha='center', va='bottom')
    plt.text(x[i], data_to_plot['success_rate_com'].iloc[i],
             round(data_to_plot['success_rate_com'].iloc[i], 3), ha='center', va='bottom')
    plt.text(x[i] + bar_width, data_to_plot['success_rate_com1'].iloc[i],
             round(data_to_plot['success_rate_com1'].iloc[i], 3), ha='center', va='bottom')

# 设置x轴刻度
plt.xticks(x, range(1, len(data_to_plot) + 1))

# 设置x轴标签
plt.xlabel('Data Count')

# 设置y轴标签
plt.ylabel('Success Rate')

# 设置标题
plt.title(f'Success Rates for {algo_to_plot} Algorithm')

# 设置纵坐标的范围
plt.ylim(0, 1)

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()
merged_avg = pd.merge(cfn_avg, com_avg, on='algo', suffixes=('_cfn', '_com'))
merged_avg = pd.merge(merged_avg, com1_avg, on='algo')

print(merged_avg)
# 可视化比较
plt.figure(figsize=(10, 6))
plt.bar(merged_avg['algo'], merged_avg['success_rate_cfn'], width=0.4, label='CFN')
plt.bar(merged_avg['algo'], merged_avg['success_rate_com'], width=0.4, label='COM', alpha=0.7)
plt.bar(merged_avg['algo'], merged_avg['success_rate'], width=0.4, label='COM1', alpha=0.7)

# 设置图表标题和标签
plt.xlabel('Algorithm')
plt.ylabel('Average Success Rate')
plt.title('Comparison of Average Success Rate between CFN、COM and COM1')
plt.xticks(rotation=45)
plt.legend()

# 显示图表
plt.tight_layout()
plt.show()
print(
    '^^^^^^^^^动态成功率可视化**********************************************************************************************')
print()

file_cfn_dy = f'{folder_from}/task_success_rates_per_algo_with_res_cfn_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
file_com_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com22_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com_dy = f'{folder_to}/success_rate_dy_results_with_com22_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
output_cfn_dy = f'{folder_to}/success_rate_dy_results_with_cfn_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
file_com1_dy = f'{folder_from}/task_success_rates_per_algo_with_res_com1_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的文件名模式
output_com1_dy = f'{folder_to}/success_rate_dy_results_with_com1_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径

cfn_dy, cfn_dy_avg = process_files_and_save(file_cfn_dy, output_cfn_dy)
com_dy, com_dy_avg = process_files_and_save(file_com_dy, output_com_dy)
com1_dy, com1_dy_avg = process_files_and_save(file_com1_dy, output_com1_dy)
merged_dy = pd.concat([cfn_dy, com_dy, com1_dy], axis=1)
merged_dy.columns = ['algo', 'success_rate_cfn_dy', 'algo', 'success_rate_com_dy', 'algo', 'success_rate_com1_dy']
merged_dy_new = merged_dy.loc[:, ~merged_dy.columns.duplicated()]
# print(merged.head(10))
print(merged_new.head(10))
merged_dy_g = merged_dy_new.groupby('algo')
# print(merged_g)
plt.figure(figsize=(10, 6))

# 选择要绘制的算法
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot_dy = merged_dy_g.get_group(algo_to_plot)

# 绘制折线图
plt.plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_cfn_dy'],
         label=f'{algo_to_plot} - CFN')  # 绘制CFN算法的折线图
plt.plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_dy'],
         label=f'{algo_to_plot} - COM')  # 绘制COM算法的折线图
plt.plot(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com1_dy'],
         label=f'{algo_to_plot} - COM1')  # 绘制COM算法的折线图
# 在每个数据点上标出数据
plt.scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_cfn_dy'], color='blue')  # 标出CFN算法的数据点
plt.scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com_dy'], color='orange')  # 标出COM算法的数据点
plt.scatter(range(1, len(data_to_plot_dy) + 1), data_to_plot_dy['success_rate_com1_dy'], color='green')  # 标出COM算法的数据点

# 设置x轴标签
plt.xlabel('Data Count')

# 设置y轴标签
plt.ylabel('Success Rate')

# 设置标题
plt.title(f'DY Success Rates for {algo_to_plot} Algorithm')

# 设置横坐标和纵坐标的范围
# plt.ylim(0, 1)  # 纵坐标范围为0到1

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot_dy = merged_dy_g.get_group(algo_to_plot)

# 设置图形大小
plt.figure(figsize=(10, 6))

# 定义柱状图的宽度
bar_width = 0.2

# 定义每个柱的位置
x = np.arange(len(data_to_plot_dy))

# 绘制CFN算法的柱状图
plt.bar(x - bar_width, data_to_plot_dy['success_rate_cfn_dy'], width=bar_width, label=f'{algo_to_plot} - CFN')

# 绘制COM算法的柱状图
plt.bar(x, data_to_plot_dy['success_rate_com_dy'], width=bar_width, label=f'{algo_to_plot} - COM',
        alpha=0.7)
plt.bar(x + bar_width, data_to_plot_dy['success_rate_com1_dy'], width=bar_width, label=f'{algo_to_plot} - COM1',
        alpha=0.7)
# 在每个柱状图上标出数据值
for i in range(len(data_to_plot_dy)):
    plt.text(x[i] - bar_width, data_to_plot_dy['success_rate_cfn_dy'].iloc[i],
             round(data_to_plot_dy['success_rate_cfn_dy'].iloc[i], 3), ha='center', va='bottom')
    plt.text(x[i], data_to_plot_dy['success_rate_com_dy'].iloc[i],
             round(data_to_plot_dy['success_rate_com_dy'].iloc[i], 3), ha='center', va='bottom')
    plt.text(x[i] + bar_width, data_to_plot_dy['success_rate_com1_dy'].iloc[i],
             round(data_to_plot_dy['success_rate_com1_dy'].iloc[i], 3), ha='center', va='bottom')

# 设置x轴刻度
plt.xticks(x, range(1, len(data_to_plot_dy) + 1))

# 设置x轴标签
plt.xlabel('Data Count')

# 设置y轴标签
plt.ylabel('Success Rate')

# 设置标题
plt.title(f'DY Success Rates for {algo_to_plot} Algorithm')

# 设置纵坐标的范围
plt.ylim(0, 1)

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()
# merged_dy_avg = pd.merge(cfn_dy_avg, com_dy_avg, on='algo', suffixes=('_dy_cfn', '_dy_com'))
merged_dy_avg = pd.merge(cfn_dy_avg, com_dy_avg, on='algo', suffixes=('_dy_cfn', '_dy_com'))
merged_dy_avg = pd.merge(merged_dy_avg, com1_dy_avg, on='algo')
print(merged_dy_avg)
# 可视化比较
plt.figure(figsize=(10, 6))
plt.bar(merged_dy_avg['algo'], merged_dy_avg['success_rate_dy_cfn'], width=0.4, label='CFN_dy')
plt.bar(merged_dy_avg['algo'], merged_dy_avg['success_rate_dy_com'], width=0.4, label='COM_dy', alpha=0.7)
plt.bar(merged_dy_avg['algo'], merged_dy_avg['success_rate'], width=0.4, label='COM1_dy', alpha=0.7)
#   设置图表标题和标签
plt.xlabel('Algorithm')
plt.ylabel('Average DY Success Rate')
plt.title('Comparison of Average DY Success Rate between CFN、COM and COM1')
plt.xticks(rotation=45)
plt.legend()

# 显示图表
plt.tight_layout()
plt.show()

print(
    '^^^^^^^^^资源均衡率可视化**********************************************************************************************')
print()

balance_folder = './balance'
cfn_balance = f'{balance_folder}/balance_cfn_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'  # 替换为实际的文件名模式
com_balance = f'{balance_folder}/balance_com22_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'  # 替换为实际的文件名模式
output_com_balance = f'{folder_to}/avg_balance_results_with_com22_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
output_cfn_balance = f'{folder_to}/avg_balance_results_with_cfn_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径
com1_balance = f'{balance_folder}/balance_com1_en_*_{large_request_num}_{medium_request_num}_{edge_request_num}_node_all.csv'  # 替换为实际的文件名模式
output_com1_balance = f'{folder_to}/avg_balance_results_with_com1_en_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'  # 替换为实际的输出文件路径

cfn_ba, cfn_ba_avg = process_balance_files_and_save(cfn_balance, output_cfn_balance)
# print(cfn_ba,cfn_ba_avg)
com_ba, com_ba_avg = process_balance_files_and_save(com_balance, output_com_balance)
com1_ba, com1_ba_avg = process_balance_files_and_save(com1_balance, output_com1_balance)
merged_ba = pd.concat([cfn_ba, com_ba, com1_ba], axis=1)
merged_ba.columns = ['algo', 'cfn_ba', 'algo', 'com_ba', 'algo', 'com1_ba']
merged_ba_new = merged_ba.loc[:, ~merged_ba.columns.duplicated()]

merged_ba_g = merged_ba_new.groupby('algo')
# print(merged_g)
plt.figure(figsize=(10, 6))

# 选择要绘制的算法
algo_to_plot = 'topsis'

# 获取对应算法的数据
data_to_plot_ba = merged_ba_g.get_group(algo_to_plot)

# 绘制折线图
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'],
         label=f'{algo_to_plot} - CFN')  # 绘制CFN算法的折线图
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_ba'],
         label=f'{algo_to_plot} - COM')  # 绘制COM算法的折线图
plt.plot(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com1_ba'],
         label=f'{algo_to_plot} - COM1')  # 绘制COM算法的折线图
# 在每个数据点上标出数据
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['cfn_ba'], color='blue')  # 标出CFN算法的数据点
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com_ba'], color='orange')  # 标出COM算法的数据点
plt.scatter(range(1, len(data_to_plot_ba) + 1), data_to_plot_ba['com1_ba'], color='green')  # 标出COM算法的数据点
# 设置x轴标签
plt.xlabel('Data Count')

# 设置y轴标签
plt.ylabel('Balance Rate')

# 设置标题
plt.title(f'Balance Rates for {algo_to_plot} Algorithm')

# 设置横坐标和纵坐标的范围
# plt.ylim(0, 1)  # 纵坐标范围为0到1

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()
merged_ba_avg = pd.merge(cfn_ba_avg, com_ba_avg, on='algorithm', suffixes=('_ba_cfn', '_ba_com'))
merged_ba_avg = pd.merge(merged_ba_avg, com1_ba_avg, on='algorithm')
print(merged_ba_avg)
# 可视化比较
bar_width = 0.2

# 定义每个柱的位置
x = np.arange(len(merged_ba_avg['algorithm']))

# 设置图形大小
plt.figure(figsize=(10, 6))

# 绘制CFN_ba的柱状图
plt.bar(x - bar_width, merged_ba_avg['zero_ratio_ba_cfn'], width=bar_width, label='CFN_ba')

# 绘制COM_ba的柱状图
plt.bar(x, merged_ba_avg['zero_ratio_ba_com'], width=bar_width, label='COM_ba', alpha=0.7)
plt.bar(x + bar_width, merged_ba_avg['zero_ratio'], width=bar_width, label='COM1_ba', alpha=0.7)
# 设置x轴刻度
plt.xticks(x, merged_ba_avg['algorithm'])

# 设置x轴标签
plt.xlabel('Algorithm')

# 设置y轴标签
plt.ylabel('Zero Ratio')

# 设置标题
plt.title('Zero Ratio for Different Algorithms')

# 显示图例
plt.legend()

# 显示网格
plt.grid(True)

# 显示图形
plt.show()

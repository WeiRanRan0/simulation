import argparse
import os
import random
import sys

import pandas as pd
import json
from Parameter import Large_num, Medium_num, Edge_num, large_request_num, medium_request_num, edge_request_num,service_type_num
import numpy as np


class DataCenter:
    def __init__(self, name, server_num, server_ids):
        self.name = name
        self.server_num = server_num
        self.server_list = server_ids
        self.main_node = None


class Request:
    def __init__(self, data_center_name, request_type, delay, delay_level, success_rate, success_rate_level, cpu_need,
                 mem_need, disk_need):
        self.data_center_name = data_center_name
        self.request_type = request_type
        self.delay = delay
        self.delay_level = delay_level
        self.success_rate = success_rate
        self.success_rate_level = success_rate_level
        self.cpu_need = cpu_need
        self.mem_need = mem_need
        self.disk_need = disk_need


def generate_random_usage(mean, std, min_val, max_val, size=1):
    random_values = np.random.normal(mean, std, size)
    random_values = np.clip(random_values, min_val, max_val)
    return random_values


def generate_requests(data_center_name, num_requests, file_df, usage_json):
    requests = []
    for _ in range(num_requests):
        request_type = random.choices(
            population=[i for i in range(1, service_type_num)],
            weights=[0.2 if 1 <= i <= 0.25*service_type_num else 0.5 if 0.25*service_type_num +1 <= i <= 0.75*service_type_num else 0.3 for i in range(1, service_type_num)],
            k=1
        )[0]
        # request_type = random.randint(1, 20)
        if 1 <= request_type <= 0.25*service_type_num:
            delay = random.uniform(1, 10)
            delay_level = 0
            success_rate = random.uniform(95, 100)
            success_rate_level = 0
            # if delay <= 2.5:
            #     success_rate = random.uniform(95, 100)
            #     success_rate_level = 0
            # elif delay <= 5:
            #     success_rate = random.uniform(90, 95)
            #     success_rate_level = 1
            # elif delay <= 7.5:
            #     success_rate = random.uniform(85, 90)
            #     success_rate_level = 2
            # else:
            #     success_rate = random.uniform(80, 85)
            #     success_rate_level = 3
        elif 0.25*service_type_num + 1 <= request_type <= 0.75*service_type_num:
            delay = random.uniform(10, 50)
            delay_level = 1
            if delay <= 30:
                success_rate = random.uniform(95, 100)
                success_rate_level = 0
            # elif delay <= 9:
            #     success_rate = random.uniform(90, 95)
            #     success_rate_level = 1
            # elif delay <= 12:
            #     success_rate = random.uniform(85, 90)
            #     success_rate_level = 2
            else:
                success_rate = random.uniform(90, 95)
                success_rate_level = 1
        else:
            delay = random.uniform(50, 110)
            delay_level = 2
            if delay <= 65:
                success_rate = random.uniform(95, 100)
                success_rate_level = 0
            elif delay <= 80:
                success_rate = random.uniform(90, 95)
                success_rate_level = 1
            elif delay <= 95:
                success_rate = random.uniform(85, 90)
                success_rate_level = 2
            else:
                success_rate = random.uniform(80, 85)
                success_rate_level = 3

        cpu_usage_mean = usage_json['cpu_usage_mean']
        cpu_usage_std = usage_json['cpu_usage_std']
        cpu_usage_max = usage_json['cpu_usage_max']
        cpu_usage_min = usage_json['cpu_usage_min']

        mem_usage_mean = usage_json['mem_usage_mean']
        mem_usage_std = usage_json['mem_usage_std']
        mem_usage_max = usage_json['mem_usage_max']
        mem_usage_min = usage_json['mem_usage_min']

        disk_usage_mean = usage_json['disk_usage_mean']
        disk_usage_std = usage_json['disk_usage_std']
        disk_usage_max = usage_json['disk_usage_max']
        disk_usage_min = usage_json['disk_usage_min']
        random_row = file_df.sample(n=1)
        selected_columns = ['cpu_need', 'mem_need', 'disk_need']
        # print(random_row[selected_columns].values[0])
        cpu_need, mem_need, disk_need = random_row[selected_columns].values[0]
        cpu_need *= generate_random_usage(cpu_usage_mean, cpu_usage_std, cpu_usage_min, cpu_usage_max)[0]
        mem_need *= generate_random_usage(mem_usage_mean, mem_usage_std, mem_usage_min, mem_usage_max)[0]
        disk_need *= generate_random_usage(disk_usage_mean, disk_usage_std, disk_usage_min, disk_usage_max)[0]
        # print(cpu_need, mem_need, disk_need)
        requests.append(
            Request(data_center_name, request_type, delay, delay_level, success_rate, success_rate_level, cpu_need,
                    mem_need, disk_need))
    return requests


def generate_data_center_requests(data_centers, num_requests_dict, file_df, usage_json):
    all_requests = []

    # Generate requests for each data center according to the specified number of requests
    for center in data_centers:
        num_requests = num_requests_dict.get(center.name, 0)
        all_requests.extend(generate_requests(center.name, num_requests, file_df, usage_json))

    # Convert requests to DataFrame
    def requests_to_dataframe(requests):
        return pd.DataFrame([{
            "Data_Center_Name": r.data_center_name,
            "Request_Type": r.request_type,
            "Delay": r.delay,
            "Delay_Level": r.delay_level,
            "Success_Rate": r.success_rate,
            "Success_Rate_Level": r.success_rate_level,
            "cpu_need": r.cpu_need,
            "mem_need": r.mem_need,
            "disk_need": r.disk_need
        } for r in requests])

    all_requests = requests_to_dataframe(all_requests)
    return all_requests
    # Save to CSV


# Example usage:
large_centers = [DataCenter(f"Large{i + 1}", 40, []) for i in range(Large_num)]
medium_centers = [DataCenter(f"Medium{i + 1}", 20, []) for i in range(Medium_num)]
edge_centers = [DataCenter(f"Edge{i + 1}", 10, []) for i in range(Edge_num)]

all_centers = large_centers + medium_centers + edge_centers
file_p = './request'
if not os.path.exists(file_p):
    os.makedirs(file_p)
# random.seed(38)

default_values = ['en', 1]
args = sys.argv[1:]
provided_values = args[:len(default_values)]  # 只保留提供的参数数量与默认值相同的部分
provided_values.extend(default_values[len(provided_values):])
weight_type, iter_num = provided_values

# Dictionary specifying the number of requests for each data center
file_path = './request_num_per_datacenter'
if not os.path.exists(file_path):
    os.makedirs(file_path)
json_file_path = os.path.join(
    file_path,
    f'num_request_per_datacenter_{large_request_num}_{medium_request_num}_{edge_request_num}.json'
)
if os.path.exists(json_file_path):
    # Read the JSON file
    with open(json_file_path, 'r') as json_file:
        num_requests_dict = json.load(json_file)
    print("num_requests_dict has been loaded from the file.")
else:
    print(f"File '{json_file_path}' does not exist.")

container_event = pd.read_csv('container_event.csv')
with open('data_usage_stats.json', 'r') as f:
    loaded_usage_stats = json.load(f)
all_requests_df = generate_data_center_requests(all_centers, num_requests_dict, container_event, loaded_usage_stats)
# print(all_requests_df.head(10))
csv_file_path = os.path.join(
    file_p,
    f'data_center_requests_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.csv'
)

xlsx_file_path = os.path.join(
    file_p,
    f'data_center_requests_{iter_num}_{large_request_num}_{medium_request_num}_{edge_request_num}.xlsx'
)
# Save the DataFrame to CSV
all_requests_df.to_csv(csv_file_path, index=False)

# Save the DataFrame to Excel
all_requests_df.to_excel(xlsx_file_path, index=False)

print(f"DataFrame has been saved to '{csv_file_path}' and '{xlsx_file_path}'")
print(f'datacenter_request_info_gen.py********{iter_num} end')
